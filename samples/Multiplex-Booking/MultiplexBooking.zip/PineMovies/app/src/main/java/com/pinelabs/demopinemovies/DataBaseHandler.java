package com.pinelabs.demopinemovies;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;

public class DataBaseHandler extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "PineMovie.db";
    private static final String TABLE1 = "Movies";
    private static final String TABLE2 = "Movie_Booked";
    private static final String TABLE3 = "Theaters";
    private static final String TABLE4 = "User";

    public static final String COLUMN_2 = "NAME";
    public static final String COLUMN_3 = "NUMBER";
    public static final String COLUMN_4 = "PASSWORD";

    public DataBaseHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table " + TABLE1 + "(NAME VARCHAR, MOVIE_ID INTEGER PRIMARY KEY AUTOINCREMENT, RATINGS INTEGER, THEATER INTEGER, PRICE INTEGER,URL VARCHAR,FOREIGN KEY(THEATER) REFERENCES Theaters(THEATRE))");
        db.execSQL("create table " + TABLE2 + "(BOOKINGID INTEGER PRIMARY KEY AUTOINCREMENT,MOVIE_ID INTEGER,TIMINGS TIME,THEATRES INTEGER,PRICE INTEGER,SHOW_DATE DATE,SEATS_NO  VARCHAR,FOREIGN KEY(MOVIE_ID) REFERENCES Movies(MOVIE_ID))");

        db.execSQL("create table " + TABLE3 + "(THEATRE INTEGER PRIMARY KEY AUTOINCREMENT, NUMBEROFSEATS INTEGER,COLUMNS INTEGER , EMPTYCOLUMN INTEGER)");
        db.execSQL("CREATE TABLE " + TABLE4 + "(NAME TEXT not null, NUMBER INTEGER PRIMARY KEY NOT NULL, PASSWORD TEXT NOT NULL)");

        db.execSQL("insert into " + TABLE3 + "(THEATRE, NUMBEROFSEATS,COLUMNS) VALUES ('1','25','5')");
        db.execSQL("insert into " + TABLE3 + "(THEATRE, NUMBEROFSEATS, COLUMNS) VALUES ('2','38','6')");
        db.execSQL("insert into " + TABLE3 + "(THEATRE, NUMBEROFSEATS, COLUMNS) VALUES ('3','25','5')");


        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Avengers','5','2','140','https://www.youtube.com/embed/eOrNdBpGMv8')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Iron Man','4','1','200','https://www.youtube.com/embed/8hYlB38asDY')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Avengers End Game','3','3','200','https://www.youtube.com/embed/TcMBFSGVi1c')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Kanchanjangha','4','2','140','https://www.youtube.com/embed/vK0H0X7ROxk')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Raees','4','1','100','https://www.youtube.com/embed/J7_1MU3gDk0')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Sarkar','4','2','140','https://www.youtube.com/embed/x2k-IxVHApQ')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('Mission Impossible','4','3','100','https://www.youtube.com/embed/EDGYVFZxsXQ')");
        db.execSQL("insert into " + TABLE1 + " (NAME,RATINGS,THEATER,PRICE,URL)" + "VALUES" + "('MI Ghost Protocol','4','2','140','https://www.youtube.com/embed/XiHiW4N7-bo')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        //onCreate(sqLiteDatabase);
    }

    //add the registration data into the database
    public boolean addItem(String name, Long num, String pswrd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues item = new ContentValues();
        item.put("NAME", name);
        item.put("NUMBER", num);
        item.put("PASSWORD", pswrd);
        return db.insert("User", null, item) != -1;
    }

    //add the registration data into the data base if entered phone number doesn't exist already exist
    public HashMap<String, String> returnSingleItem(Long num) {
        try {
            HashMap<String, String> new_items_added = new HashMap<>();
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = null;
            cursor = db.query(TABLE4, new String[]{COLUMN_2,COLUMN_3, COLUMN_4}, "NUMBER=?", new String[]{Long.toString(num)}, null, null, null);

            if (((cursor != null) && (cursor.getCount() > 0))) {
                while (cursor.moveToNext()) {
                    new_items_added.put("NAME", cursor.getString(cursor.getColumnIndex(COLUMN_2)));
                    new_items_added.put("NUMBER", cursor.getString(cursor.getColumnIndex(COLUMN_3)));
                    new_items_added.put("PASSWORD", cursor.getString(cursor.getColumnIndex(COLUMN_4)));
                }
                cursor.close();
                db.close();
            } else {
                return null;
            }

            return new_items_added;
        }catch (SQLiteException e) {
            return null;
        }
    }

    //Verify the password from the database corresponding the entered phone number
    public String loginSuccess(Long num)
    {
        try {
            String password =null;
            Long num1=num;
            String number;
            number=num1.toString();

            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.query(TABLE4, new String[]{COLUMN_4}, "NUMBER=?", new String[]{number}, null, null, null);

            if (((cursor != null) && (cursor.getCount() > 0)))
            {
                while (cursor.moveToNext())
                {
                    password = cursor.getString(cursor.getColumnIndex(COLUMN_4));
                }
                cursor.close();
                db.close();
                return password;
            }
            else {
                return null;
            }
        }
        catch (SQLiteException e) {
            return null;
        }
    }

    //insert movie booking details in table Movie_booked
    public boolean insertMovieBooked(int id, String Seats, int theatre, String time, String date, int price) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues content = new ContentValues();

        content.put("MOVIE_ID", id);
        content.put("TIMINGS", time);
        content.put("THEATRES", theatre);
        content.put("SHOW_DATE", date);
        content.put("PRICE", price);
        content.put("SEATS_NO", Seats);

        long result = db.insert(TABLE2, null, content);

        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getMaxBooking(SQLiteDatabase db) {
        Cursor cursor;

        String sql = "Select max(BOOKINGID) from " + TABLE2;
        cursor = db.rawQuery(sql, null);

        return cursor;
    }

    public Cursor getTheaterInfo(SQLiteDatabase db, String theatre){
        Cursor cursor;

        String sql = "SELECT NUMBEROFSEATS, COLUMNS" +
                " FROM Theaters" +
                " WHERE THEATRE = ?";

        cursor = db.rawQuery(sql,new String[]{theatre});
        return cursor;
    }

    public Cursor getSeats(SQLiteDatabase db, int Theatre, String date, String time, int movie_id) {
        Cursor cursor;

        String sql = "select SEATS_NO from " + TABLE2 + " where MOVIE_ID = ? and THEATRES = ? and TIMINGS = ? AND SHOW_DATE = ?";
        cursor = db.rawQuery(sql, new String[]{Integer.toString(movie_id), Integer.toString(Theatre), time, date});

        return cursor;
    }

    public Cursor getMovieDetails(SQLiteDatabase db, String movie_id) {
        Cursor cursor;

        String sql = "select NAME, RATINGS, THEATER , PRICE, URL FROM Movies where MOVIE_ID = ?";
        cursor = db.rawQuery(sql, new String[]{movie_id});

        return cursor;
    }

    public Cursor getMovieAllName(SQLiteDatabase db){
        Cursor cursor;

        String sql = "select NAME from "+TABLE1;
        cursor = db.rawQuery(sql, null);

        return cursor;
    }
}