package com.pinelabs.demopinemovies.helper;

public interface PreferenceConstants {
    String USER_ID_PREF_KEY = "USER_ID_PREF_KEY";
}
