package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.pinelabs.demopinemovies.beans.Movie;

public class BookingConfirmation extends AppCompatActivity{

    TextView tv_movieName, tv_theater, tv_bookingId, tv_seatBooked, tv_totalAmount, tv_date;
    ImageView imageView;
    Button homeButton;
    Movie movie;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_confirmation);
        getSupportActionBar().hide();

        tv_movieName = findViewById(R.id.MovieName1);
        tv_theater = findViewById(R.id.theatrescreen);
        tv_bookingId = findViewById(R.id.bookingid);
        tv_seatBooked = findViewById(R.id.seats_booked);
        tv_totalAmount = findViewById(R.id.totalamount);
        tv_date = findViewById(R.id.datetime);
        imageView = findViewById(R.id.imageView3);
        homeButton = findViewById(R.id.homeButton);

        movie = (Movie) getIntent().getSerializableExtra("Movie");

        int bookingId = movie.getBookingId();
        String date = movie.getDate();
        String movieName = movie.getMovieName();

        int theater = movie.getTheater();
        int totalAmount = movie.getTotalPrice();
        int url = movie.getDirectoryUrl();

        tv_bookingId.setText(Integer.toString(bookingId));
        tv_date.setText(date +"  "+ movie.getTime());
        tv_movieName.setText(movieName);
        tv_theater.setText(Integer.toString(theater));
        tv_totalAmount.setText("₹ "+totalAmount);
        imageView.setImageResource(url);
        tv_seatBooked.setText(movie.getSeatSelectedFromMovieClass());

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent home = new Intent(BookingConfirmation.this, MainActivity.class);
                startActivity(home);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent setIntent = new Intent(BookingConfirmation.this,MainActivity.class);
        startActivity(setIntent);
        finish();
    }
}
