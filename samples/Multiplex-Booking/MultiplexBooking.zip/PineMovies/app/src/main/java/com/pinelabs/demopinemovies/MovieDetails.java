package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.pinelabs.demopinemovies.beans.Movie;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MovieDetails extends AppCompatActivity {

    private TextView today, tomorrow, dayAfterTomorrow, showDate, showSlot;
    private Button bookSelectedMovie, todayTime10to1, todayTime1to4,todayTime4to7,todayTime7to10;

    private WebView ytMovieClip;

    private List<String> dateArr = new ArrayList<>();
    private String currDate, chosenDate;
    private String []timeSlot = {"10:00", "13:00", "16:00", "19:00"};
    private int MAX_NUM_DAY = 3, INCR_BY_ONE=1, TODAY = 0, TOMORROW = 1, DAY_AFTER_TOMORROW = 2;
    private String url = null;
    public static String chosenSlot="";

    private Movie movie;

    public Context getContext(){
        return getApplicationContext();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        getSupportActionBar().hide();

        InitializeViews();

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        currDate = df.format(calendar.getTime());

        try {
            calendar.setTime(df.parse(currDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        dateArr.add(currDate);

        for(int index=1 ; index < MAX_NUM_DAY ; index++) {
            calendar.add(Calendar.DATE,INCR_BY_ONE);
            dateArr.add(df.format(calendar.getTime()));
        }

        today.setText(dateArr.get(TODAY));
        tomorrow.setText(dateArr.get(TOMORROW));
        dayAfterTomorrow.setText(dateArr.get(DAY_AFTER_TOMORROW));

        //To hide slots of current date that are expired as per current time
        hideExpiredSlotsButton();

        //receiving movie object from previous activity
        movie = (Movie) getIntent().getSerializableExtra("Movie");

        url = movie.getURL();

        ytMovieClip.setWebViewClient(new WebViewClient());
        ytMovieClip.getSettings().setJavaScriptEnabled(true);
        ytMovieClip.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        ytMovieClip.loadData(loadURL(url), "text/html", "utf-8");

        bookSelectedMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast message for pressing button without selecting a slot
                if(chosenSlot.equals("")) {
                    Toast.makeText(getApplicationContext(), R.string.CHOOSE_SLOT, Toast.LENGTH_SHORT).show();
                }

                else{
                        movie.setTime(chosenSlot);
                        movie.setDate(chosenDate);

                        Intent intent = new Intent(MovieDetails.this, SeatSelection.class);
                        intent.putExtra("Movie", movie);

                        chosenSlot="";

                        startActivity(intent);
                }
            }
        });
    }

    public void setDateAndSlot(View view){

        switch (view.getId()) {
            case R.id.todayTime10To1:
                chosenDate = dateArr.get(TODAY);
                chosenSlot = "10:00AM";
                break;

            case R.id.todayTime1To4:
                chosenDate = dateArr.get(TODAY);
                chosenSlot = "01:00PM";
                break;

            case R.id.todayTime4To7:
                chosenDate = dateArr.get(TODAY);
                chosenSlot = "04:00PM";
                break;

            case R.id.todayTime7to10:
                chosenDate = dateArr.get(TODAY);
                chosenSlot = "07:00PM";
                break;

            case R.id.tomTime10To1:
                chosenDate = dateArr.get(TOMORROW);
                chosenSlot = "10:00AM";
                break;

            case R.id.tomTime1To4:
                chosenDate = dateArr.get(TOMORROW);
                chosenSlot = "01:00PM";
                break;

            case R.id.tomTime4To7:
                chosenDate = dateArr.get(TOMORROW);
                chosenSlot = "04:00PM";
                break;

            case R.id.tomTime7to10:
                chosenDate = dateArr.get(TOMORROW);
                chosenSlot = "07:00PM";
                break;

            case R.id.datTime10To1:
                chosenDate = dateArr.get(DAY_AFTER_TOMORROW);
                chosenSlot = "10:00AM";
                break;

            case R.id.datTime1To4:
                chosenDate = dateArr.get(DAY_AFTER_TOMORROW);
                chosenSlot = "01:00PM";
                break;

            case R.id.datTime4To7:
                chosenDate = dateArr.get(DAY_AFTER_TOMORROW);
                chosenSlot = "04:00PM";
                break;

            case R.id.datTime7to10:
                chosenDate = dateArr.get(DAY_AFTER_TOMORROW);
                chosenSlot = "07:00PM";
                break;
        }

        showDate.setText(chosenDate+", ");
        showSlot.setText(chosenSlot);
    }

    //to reset the chosen slot so to prevent using previously chosen slot
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        chosenSlot="";
    }

    private String loadURL(String URL){
        return "<html><body style='margin:0;padding:0;'><iframe width=\"353\" height=\"250\" src=\""+URL+"\"frameborder=\"0\"" +
                " allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>";
    }

    private void InitializeViews(){
        today = findViewById(R.id.today);
        tomorrow = findViewById(R.id.tomorrow);
        dayAfterTomorrow = findViewById(R.id.dayAfterTomorrow);

        todayTime10to1 = findViewById(R.id.todayTime10To1);
        todayTime1to4 = findViewById(R.id.todayTime1To4);
        todayTime4to7 = findViewById(R.id.todayTime4To7);
        todayTime7to10 = findViewById(R.id.todayTime7to10);
        bookSelectedMovie =findViewById(R.id.bookSelectedMovie);

        ytMovieClip = findViewById(R.id.ytMovieClip);

        showDate = findViewById(R.id.showDate);
        showSlot = findViewById(R.id.showSlot);
    }

    private void hideExpiredSlotsButton(){
        todayTime10to1.setTag(timeSlot[0]);
        todayTime1to4.setTag(timeSlot[1]);
        todayTime4to7.setTag(timeSlot[2]);
        todayTime7to10.setTag(timeSlot[3]);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Date today = new Date();

        //Booking can be done beyond half an hour of starting of the show
        today.setTime(System.currentTimeMillis() - (30 * 60 * 1000));

        String currentTime = sdf.format(today);

        if (currentTime.compareTo((String) todayTime7to10.getTag()) > 0){
            todayTime10to1.setEnabled(false);
            todayTime10to1.setVisibility(View.GONE);
            todayTime1to4.setEnabled(false);
            todayTime1to4.setVisibility(View.GONE);
            todayTime4to7.setEnabled(false);
            todayTime4to7.setVisibility(View.GONE);
            todayTime7to10.setEnabled(false);
            todayTime7to10.setVisibility(View.GONE);
        }
        else if (currentTime.compareTo((String) todayTime4to7.getTag()) > 0){
            todayTime10to1.setEnabled(false);
            todayTime10to1.setVisibility(View.GONE);
            todayTime1to4.setEnabled(false);
            todayTime1to4.setVisibility(View.GONE);
            todayTime4to7.setEnabled(false);
            todayTime4to7.setVisibility(View.GONE);
        }
        else if (currentTime.compareTo((String) todayTime1to4.getTag()) > 0){
            todayTime10to1.setEnabled(false);
            todayTime10to1.setVisibility(View.GONE);
            todayTime1to4.setEnabled(false);
            todayTime1to4.setVisibility(View.GONE);
        }
        else if (currentTime.compareTo((String) todayTime10to1.getTag()) > 0){
            todayTime10to1.setEnabled(false);
            todayTime10to1.setVisibility(View.GONE);
        }
    }
}