package com.pinelabs.demopinemovies.adapter;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.pinelabs.demopinemovies.DataBaseHandler;
import com.pinelabs.demopinemovies.R;
import com.pinelabs.demopinemovies.ThisApplication;
import com.pinelabs.demopinemovies.beans.Movie;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MovieSeatAdapter extends BaseAdapter {

    private  List<Integer> drawableUrls;
    private Movie movie;
    private List<Integer> seatNumber = new ArrayList<>();
    private List<String> seatBookedArr = new ArrayList<>();
    private String seatBooked = "";
    private DataBaseHandler db;
    private SQLiteDatabase sql;
    Button button;
    Context context;

    public MovieSeatAdapter(Context context, List<Integer> drawableUrl, Movie movie,Button button){

        this.context = context;
        this.drawableUrls = drawableUrl;
        this.movie = movie;

        db = new DataBaseHandler(ThisApplication.getAppContext());
        sql = db.getReadableDatabase();

        //To get booked seat
        Cursor cursor;
        cursor = db.getSeats(sql,movie.getTheater(),movie.getDate(),movie.getTime(),movie.getMovieId());

        while (cursor.moveToNext()){
            seatBooked = cursor.getString(0);
        }

        if (!seatBooked.equals(""))
            seatBookedArr = Arrays.asList(seatBooked.split(","));

        this.button = button;
    }

    @Override
    public int getCount() {
        return drawableUrls.size();
    }

    @Override
    public Object getItem(int i) {
        return drawableUrls.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int iIndex, View convertView, ViewGroup parent) {

        final int pos = iIndex;

        //Adding the GridView to it's parent layout
        if(convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.list_item_seat,null);
        }

        final TextView textView = convertView.findViewById(R.id.seatnumber);

        final ImageView imageView = convertView.findViewById(R.id.img_seat);

        //Changing seat image in case of already booked seats
        if(seatBookedArr.size() > 0)
            for(int jIndex=0;jIndex<seatBookedArr.size();jIndex++)
                if (iIndex == Integer.parseInt(seatBookedArr.get(jIndex)) - 1) {
                    textView.setText("-1");
                    imageView.setImageResource(R.drawable.booked);
                }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //to select seat(s)
                if(Integer.parseInt(textView.getText().toString()) == 0){
                    seatNumber.add(pos+1);
                    setSeatNumber();
                    textView.setText(Integer.toString(numberOfSeats()));

                    imageView.setImageResource(R.drawable.selected);
                }

                //remove selection of seat(s)
                else if(Integer.parseInt(textView.getText().toString()) > 0){

                    imageView.setImageResource(R.drawable.available);
                    textView.setText("0");
                    final int index = seatNumber.indexOf(pos+1);

                    seatNumber.remove(index);
                    setSeatNumber();
                }

                //showing toast for already booked seat
                else{
                    int tempPos = pos + 1;
                    Toast.makeText(context,context.getString(R.string.SORRY)+" "+tempPos+" "+context.getString(R.string.SEAT_BOOKED),Toast.LENGTH_SHORT).show();
                }
            }
        });

        return convertView;
    }

    //list of selected seats
    public String setSeatNumber(){

        String seats = "";
        int totalNumberOfSeats;

        for (int index=0; index<numberOfSeats(); index++) {
            seats += Integer.toString(seatNumber.get(index));
            if(index != seatNumber.size() - 1){
                seats += ",";
            }
        }

        movie.setSeatSelected(seats);

        totalNumberOfSeats = numberOfSeats();

        if(totalNumberOfSeats == 0){
            button.setText(R.string.ONE_SEAT_ATLEAST);
        }
        else if(totalNumberOfSeats == 1)
            button.setText("Book "+totalNumberOfSeats+" seat");
        else
            button.setText("Book "+totalNumberOfSeats+" seats");

        movie.setTotalSeats(totalNumberOfSeats);
        return seats;
    }

    public int numberOfSeats(){
        return seatNumber.size();
    }
}