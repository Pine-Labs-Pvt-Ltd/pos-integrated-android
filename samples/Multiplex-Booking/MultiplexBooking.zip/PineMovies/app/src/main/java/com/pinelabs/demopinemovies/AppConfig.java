package com.pinelabs.demopinemovies;

public class AppConfig {
    public static final String REQUEST_KEY = "MASTERAPPREQUEST";
    public static final String RESPONSE_KEY = "MASTERAPPRESPONSE";

    public static final String PINE_ACTION = "com.pinelabs.masterapp.SERVER";
    public static final String PINE_PACKAGE = "com.pinelabs.masterapp";

    public static final int ITEM_RV = 0;
    public static final int MORE_RV = 1;
    public static final int POSITION_FROM_LAST = 1;
}
