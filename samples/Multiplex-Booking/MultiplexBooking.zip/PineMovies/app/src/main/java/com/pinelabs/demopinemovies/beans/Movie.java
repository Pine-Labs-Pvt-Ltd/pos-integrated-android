package com.pinelabs.demopinemovies.beans;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.pinelabs.demopinemovies.DataBaseHandler;

import java.io.Serializable;

public class Movie implements Serializable {

    private int movieId;
    private String movieName;
    private int theater;
    private int price;
    private int totalPrice;
    private String URL;
    private int bookingId;
    private int rating;
    private int totalSeats;
    private String seatBooked;
    private int directoryUrl;
    private String seatSelected;

    private String date,time;

    //Constructor to initialize necessary details of the movie chosen in main activity
    public Movie(int movieId, DataBaseHandler db, SQLiteDatabase sql){

        this.movieId = movieId;

        Cursor cursor = db.getMovieDetails(sql,Integer.toString(movieId));

        while (cursor.moveToNext()){
            this.movieName = cursor.getString(0);
            setRating(cursor.getInt(1));
            setTheater(cursor.getInt(2));
            setPrice(cursor.getInt(3));
            setURL(cursor.getString(4));
        }
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getDirectoryUrl() {
        return directoryUrl;
    }

    public void setDirectoryUrl(int directoryUrl) {
        this.directoryUrl = directoryUrl;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setSeatSelected(String seatSelected) {
        this.seatSelected = seatSelected;
    }

    public String getSeatSelectedFromMovieClass(){
        return seatSelected;
    }

    public String getSeatBooked(DataBaseHandler db, SQLiteDatabase sql) {
        Cursor cursor;

        cursor = db.getSeats(sql,getTheater(),getDate(),getTime(), movieId);
        while (cursor.moveToNext()){
            seatBooked = cursor.getString(0);
        }

        return seatBooked;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getURL() {
        return URL;
    }

    public void setTheater(int theater) {
        this.theater = theater;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getMovieId() {
        return movieId;
    }

    public String getMovieName() {
        return movieName;
    }

    public int getTheater() {
        return theater;
    }

    public int getPrice() {
        return price;
    }
}