package com.pinelabs.demopinemovies.helper;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.pinelabs.demopinemovies.ThisApplication;

public class PreferenceHelper {

    private static PreferenceHelper sInstance;
    private final SharedPreferences mPreferences;
    private float distance;
    private PreferenceHelper() {
        mPreferences = PreferenceManager.getDefaultSharedPreferences(ThisApplication.getAppContext());
    }

    public static PreferenceHelper getInstance() {
        if (sInstance == null)
            sInstance = new PreferenceHelper();
        return sInstance;
    }

    /********
     * USER ID
     **********/
    public String getUserID() {
        return mPreferences.getString(PreferenceConstants.USER_ID_PREF_KEY, "");
    }

    public void saveUserID(String userID) {
        mPreferences.edit().putString(PreferenceConstants.USER_ID_PREF_KEY, userID).apply();
    }

    public boolean isLoggedIn() {
        return !TextUtils.isEmpty(getUserID());
    }

    public void logout() {
        mPreferences.edit().clear().commit();
    }
}

