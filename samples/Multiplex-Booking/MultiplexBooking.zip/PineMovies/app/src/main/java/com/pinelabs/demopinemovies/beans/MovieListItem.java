package com.pinelabs.demopinemovies.beans;

import android.content.Context;

public class MovieListItem {

    private String name;
    private int url;
    private int id;

    public int getId() {
        return id;
    }

    public MovieListItem(int id, String name, int url, Context context) {
        this.name = name;
        this.url = url;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getUrl() {
        return url;
    }

    public void setName(String name) {
        this.name = name;
    }
}
