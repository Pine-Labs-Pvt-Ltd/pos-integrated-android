package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.pinelabs.demopinemovies.beans.Movie;
import com.pinelabs.demopinemovies.enums.PaymentModeEnum;

public class PayNow extends AppCompatActivity implements ServiceImplementation.MyAppCallBack{

    private Button cashMode, debitCardMode, creditCardMode, upiMode, bharatQR;
    private ServiceImplementation serviceImplementation;
    long amount = 0;
    private int maximum = 0;
    private Movie movie;

    DataBaseHandler db;
    SQLiteDatabase sql;

    private int theater;
    private String seatsForBooking,dateForBooking,timeForBooking;
    private int movieId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_now);
        getSupportActionBar().hide();

        cashMode = findViewById(R.id.cashMode);
        debitCardMode = findViewById(R.id.debitCardMode);
        creditCardMode = findViewById(R.id.creditCardMode);
        upiMode = findViewById(R.id.upiMode);
        bharatQR = findViewById(R.id.bharatQR);

        movie = (Movie) getIntent().getSerializableExtra("Movie");

        amount = movie.getTotalPrice();
        String tempAmount = amount + "00";
        amount = Long.valueOf(tempAmount);

        theater = movie.getTheater();
        seatsForBooking = movie.getSeatSelectedFromMovieClass();
        movieId = movie.getMovieId();
        dateForBooking = movie.getDate();
        timeForBooking = movie.getTime();
        /*emailId = movie.getEmailId();
        phoneNumber = movie.getPhoneNum();*/

        serviceImplementation = ServiceImplementation.getInstance();

        db = new DataBaseHandler(getApplicationContext());
        sql = db.getWritableDatabase();

        String seatFromDb = movie.getSeatBooked(db,sql);

        if(seatFromDb != null)
            seatsForBooking +=","+ seatFromDb;

        serviceImplementation.connect(PayNow.this);

        cashMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Cursor max = db.getMaxBooking(sql);
                if (max != null && max.getCount() > 0) {
                    while (max.moveToNext()) {
                        maximum = max.getInt(0);
                    }
                }
                if (db.insertMovieBooked(movieId, seatsForBooking, theater, timeForBooking, dateForBooking, (int)amount)) {

                    Intent intent;
                    intent = new Intent(PayNow.this, BookingConfirmation.class);
                    movie.setBookingId(maximum+1);
                    intent.putExtra("Movie",movie);
                    startActivity(intent);

                } else {
                    Toast.makeText(getApplicationContext(), R.string.ERROR_BOOKING, Toast.LENGTH_LONG).show();
                }
            }
        });

        //Starting simulator app for payment modes other than cash mode
        debitCardMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.SaleD.getRequest();

                callMyAppService(headerRequest);
            }
        });

        creditCardMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.SaleD.getRequest();
                callMyAppService(headerRequest);
            }
        });

        upiMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.UPI.getRequest();

                callMyAppService(headerRequest);
            }
        });

        bharatQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.Bharat_QR.getRequest();
                callMyAppService(headerRequest);
            }
        });
    }

    private void callMyAppService(final HeaderRequest<DoTransactionRequest> headerRequest){

        DoTransactionRequest request = headerRequest.getDetail();

        if(request==null)
            Toast.makeText(getApplicationContext(),R.string.INTERNAL_ERROR, Toast.LENGTH_SHORT).show();
        else{
            request.setBillingRefNo(getString(R.string.BILL_NUM));
            request.setPaymentAmount(amount);
            serviceImplementation.callMyAppService(headerRequest);
        }}

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,R.string.CONNECT,Toast.LENGTH_LONG).show();
    }

    @Override
    public void connectAgain() {
        Toast.makeText(this,R.string.RECONNECT,Toast.LENGTH_SHORT).show();
    }

    // inserting/not-inserting record to database based on response received from simulator app and to start new
    // activity in this app
    @Override
    public void sendResult(DetailResponse detailResponse) {
        if (detailResponse != null)
        {
            if (detailResponse.getResponse().isSuccess())
            {

                Cursor max = db.getMaxBooking(sql);
                if (max != null && max.getCount() > 0) {
                    while (max.moveToNext()) {
                        maximum = max.getInt(0);
                    }
                }
                if (db.insertMovieBooked(movieId, seatsForBooking, theater, timeForBooking, dateForBooking, (int)amount)) {

                    Intent intent;
                    intent = new Intent(PayNow.this, BookingConfirmation.class);

                    movie.setBookingId(maximum+1);

                    intent.putExtra("Movie",movie);
                    startActivity(intent);

                } else {
                    Toast.makeText(getApplicationContext(), R.string.ERROR_BOOKING, Toast.LENGTH_LONG).show();
                }

            }
            else {
                   startActivity(new Intent(PayNow.this, BookingFailed.class));
            }
        }
    }

    @Override
    public void showWaitingDialog() {

    }
}