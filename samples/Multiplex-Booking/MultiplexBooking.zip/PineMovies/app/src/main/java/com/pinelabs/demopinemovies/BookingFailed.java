package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.pinelabs.demopinemovies.beans.Movie;

public class BookingFailed extends AppCompatActivity {

    Button backHome;
    Movie movie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_failed);
        getSupportActionBar().hide();

        backHome = findViewById(R.id.backHome);

        movie = (Movie) getIntent().getSerializableExtra("Movie");

        backHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BookingFailed.this, MainActivity.class));
                finish();
            }
        });
    }
}
