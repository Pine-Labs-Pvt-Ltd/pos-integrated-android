package com.pinelabs.demopinemovies.enums;

import com.pinelabs.demopinemovies.DoTransactionRequest;
import com.pinelabs.demopinemovies.HeaderRequest;

public enum PaymentModeEnum {

    SaleD("debitCard", new DoTransactionRequest(4001L)),
    UPI("UPI", new DoTransactionRequest(5120L)),
    Bharat_QR("Bharat QR", new DoTransactionRequest(5123L));

    private final String name;
    private HeaderRequest<DoTransactionRequest> request;

    PaymentModeEnum(String s, DoTransactionRequest doTransactionRequest) {
        this.name = s;
        request = new HeaderRequest<>("1001");
        request.setDetail(doTransactionRequest);
    }

    public HeaderRequest<DoTransactionRequest> getRequest() {
        return request;
    }

    public String getName(){
        return name;
    }
}
