package com.pinelabs.demopinemovies;

import com.google.gson.annotations.SerializedName;

public class HeaderRequest<T> {

    @SerializedName("Header")
    private Header Header;
    @SerializedName("Detail")
    private T Detail;

    public HeaderRequest(String methodId) {
        this.Header = new Header("bbacbfb768884af4a7397567c338180a", methodId, "userId", "1.0");
    }

    public Header getHeader() {
        return Header;
    }

    public void setHeader(Header header) {
        Header = header;
    }

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    @Override
    public String toString() {
        return GsonUtils.fromJsonToString(this);
    }
}
