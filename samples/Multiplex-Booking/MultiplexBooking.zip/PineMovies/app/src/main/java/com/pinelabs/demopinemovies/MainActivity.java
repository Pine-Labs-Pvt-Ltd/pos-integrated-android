package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.pinelabs.demopinemovies.beans.MovieListItem;
import com.pinelabs.demopinemovies.beans.Movie;
import com.pinelabs.demopinemovies.helper.PreferenceHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MovieAdapter.onSelectImageListener{

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    List<MovieListItem> movieListItems;
    Context context;
    Button logout;
    DataBaseHandler db;

    SQLiteDatabase sql;

    private int FIRST_MOVIE=1;

    HashMap<String ,String> item;
    DataBaseHandler mainDb;
    TextView tv_userName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        tv_userName = findViewById(R.id.username);
        logout = findViewById(R.id.logout);
        recyclerView = findViewById(R.id.recyclerview1);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        movieListItems = new ArrayList<MovieListItem>();

        context = getApplicationContext();

        db = new DataBaseHandler(getApplicationContext());
        sql = db.getReadableDatabase();

        Cursor cursor = db.getMovieAllName(sql);

        int movieId = FIRST_MOVIE;

        int url;
        mainDb = new DataBaseHandler(this);

        String userNumber =  PreferenceHelper.getInstance().getUserID();

        item = mainDb.returnSingleItem(Long.parseLong(userNumber));

        String userName =  item.get("NAME");
        tv_userName.setText("Hi "+userName);

        //setting the images of each movies in the CardView
        while (cursor.moveToNext()){
            String movieName = cursor.getString(0);
            String movieNameCopy = movieName;

            movieName = movieName.replaceAll("\\s","").toLowerCase();

            url = getResources().getIdentifier(movieName, "drawable", getPackageName());

            MovieListItem movieListItem = new MovieListItem(movieId,movieNameCopy,url,context);
            movieId++;
            movieListItems.add(movieListItem);
        }

        //adding the CardViews to the recycler view
        adapter = new MovieAdapter(movieListItems,this,this);
        recyclerView.setAdapter(adapter);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                builder.setMessage(R.string.alert_logout_msg);
                builder.setNegativeButton(R.string.no, null);
                builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(MainActivity.this, Login.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        PreferenceHelper.getInstance().logout();
                       // UIUtils.makeToast(RateChart.this, getString(R.string.msg_logout));
                        Toast.makeText(MainActivity.this,getString(R.string.msg_logout),Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                builder.show();
            }
        });
    }

    //Moving to next activity on choosing movie
    public void onSelectedImage(int pos, String movieName){

        Intent intent = new Intent(this,MovieDetails.class);

        Movie movie = new Movie(pos, db, sql);

        movieName = movieName.replaceAll("\\s","").toLowerCase();

        int url = getResources().getIdentifier(movieName, "drawable", getPackageName());

        movie.setDirectoryUrl(url);

        //passing movie object to next activity
        intent.putExtra("Movie", movie);
        startActivity(intent);
    }
}