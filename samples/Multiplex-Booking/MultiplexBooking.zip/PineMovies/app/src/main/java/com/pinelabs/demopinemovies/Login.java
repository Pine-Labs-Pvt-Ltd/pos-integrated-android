package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.pinelabs.demopinemovies.helper.PreferenceHelper;


public class Login extends AppCompatActivity {

    Button login;
    Button register;
    EditText number_login;
    EditText password_login;
    private CheckBox saveLoginCheckBox;

    DataBaseHandler mainDb;

    private AwesomeValidation awesomeValidation;

    private Boolean saveLogin;
    String username;
    String password;

    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        register = findViewById(R.id.register);
        number_login = findViewById(R.id.login_phone);
        password_login = findViewById(R.id.login_password);
        login = findViewById(R.id.login);
        saveLoginCheckBox = findViewById(R.id.saveLoginCheckBox);

        mainDb = new DataBaseHandler(this);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(this, R.id.login_phone, "^[2-9]{2}[0-9]{8}$", R.string.mobileerror);

        loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();

        saveLogin = loginPreferences.getBoolean("saveLogin", false);

        if (saveLogin == true) {
            number_login.setText(loginPreferences.getString("username", ""));
            password_login.setText(loginPreferences.getString("password", ""));
            saveLoginCheckBox.setChecked(true);
        }
        // Capture login button clicks

        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                //check Regex validation on Phone number
                username = number_login.getText().toString();
                password = password_login.getText().toString();

                if (saveLoginCheckBox.isChecked()) {
                    loginPrefsEditor.putBoolean("saveLogin", true);
                    loginPrefsEditor.putString("username", username);
                    loginPrefsEditor.putString("password", password);
                    loginPrefsEditor.commit();
                } else {
                    loginPrefsEditor.clear();
                    loginPrefsEditor.commit();
                }

                if(awesomeValidation.validate())
                    login(Long.parseLong(number_login.getText().toString()), password_login.getText().toString());
            }
        });

        // Capture register button clicks
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                Intent registerIntent = new Intent(Login.this,
                        RegisterActivity.class);
                startActivity(registerIntent);
            }
        });
    }

    public void login(Long num,String pass)
    {
        String tempPass;
        String mUserID = number_login.getText().toString().trim();
        tempPass = mainDb.loginSuccess(num);

        if(tempPass != null) {
            try {
                if(AESHelper.encrypt("123", pass).equals(tempPass)) {

                    PreferenceHelper.getInstance().saveUserID(mUserID);
                    //Starting movie selection activity
                    Intent loginIntent = new Intent(Login.this, MainActivity.class);
                    startActivity(loginIntent);
                    finish();

                }else {
                    //display login credential error toast
                    Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.INVALID_CREDENTIAL), Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else {
           Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.INVALID_CREDENTIAL), Toast.LENGTH_SHORT).show();
        }
    }
}