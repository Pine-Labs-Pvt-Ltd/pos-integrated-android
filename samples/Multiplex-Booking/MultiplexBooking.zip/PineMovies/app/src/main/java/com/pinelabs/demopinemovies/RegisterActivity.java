package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.pinelabs.demopinemovies.helper.PreferenceHelper;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    Button register_final;
    DataBaseHandler mainDb;
    HashMap<String ,String> item;
    int passLen;
    private AwesomeValidation awesomeValidation;
    EditText name_register,number_register,password_register,confirmPassword_register;

    //Function to encrypt the entered password
    public String encryption(String strNormalText){
        String seedValue = "123";
        String normalTextEnc="";

        try {
                normalTextEnc = AESHelper.encrypt(seedValue, strNormalText);
                String test  = AESHelper.decrypt(seedValue,normalTextEnc);
                Log.i("Surbhi","NormalTexr - "+strNormalText+"encrypted: -"+normalTextEnc+"dycripted:- "+test);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return normalTextEnc;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        name_register = findViewById(R.id.name);
        number_register = findViewById(R.id.phone_number);
        password_register = findViewById(R.id.password);
        confirmPassword_register = findViewById(R.id.confirmPassword);

        register_final = findViewById(R.id.register_final);
        mainDb = new DataBaseHandler(RegisterActivity.this);
        awesomeValidation.addValidation(this, R.id.name, "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$", R.string.nameerror);
        awesomeValidation.addValidation(this, R.id.phone_number, "^[2-9]{2}[0-9]{8}$", R.string.mobileerror);

        // Capture button clicks
        register_final.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                //check Regex validation on Name and Phone Number
                if (awesomeValidation.validate()){

                    String mUserID = name_register.getText().toString().trim();
                    passLen = password_register.getText().length();

                    //Check Password length
                    if (passLen > 7) {

                        //check whether entered password in both text fields are same or not
                        if (password_register.getText().toString().equals(confirmPassword_register.getText().toString())) {
                            try {
                                item = mainDb.returnSingleItem(Long.parseLong(number_register.getText().toString()));
                            }
                            catch (Exception e)
                            {
                                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                            }
                            if (item == null) {
                                boolean flag;
                                //encrypt the password to be stored in database
                                String temp=""+encryption(password_register.getText().toString());
                                flag = mainDb.addItem(name_register.getText().toString(),Long.parseLong(number_register.getText().toString()), temp);

                                if (flag) {
                                    //save phone number in string format
                                    PreferenceHelper.getInstance().saveUserID(mUserID);
                                    Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.REGISTRATION_SUCCESS), Toast.LENGTH_LONG).show();

                                    Intent registerIntent = new Intent(RegisterActivity.this, Login.class);
                                    startActivity(registerIntent);

                                    registerIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    finish();//redirect to login page
                                } else{
                                    //message display : please enter details correctly
                                        Toast toast = Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.ENTER_CORRECT_DETAILS), Toast.LENGTH_SHORT);
                                        toast.setMargin(50, 50);
                                        toast.show();
                                }
                            } else {
                                //Display toast in case already registered details entered
                                Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.ALREADY_EXISTS), Toast.LENGTH_SHORT).show();//Display message already registered
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.UNMATCHED_PASSWORD), Toast.LENGTH_LONG).show();
                        }
                    }
                    else {
                        Toast.makeText(getApplicationContext(), getApplicationContext().getString(R.string.MIN_EIGHT_CHARS), Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}