package com.pinelabs.demopinemovies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.demopinemovies.beans.MovieListItem;

import java.util.List;

public class MovieAdapter  extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {
    List<MovieListItem> movieListItems;

    private int url;
    Context context;
    private onSelectImageListener mListener;

    public MovieAdapter(List<MovieListItem> movieListItems, Context context, onSelectImageListener listener){
        this.movieListItems = movieListItems;
        this.context = context;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View viewHolder = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.movielist,parent,false);
        return new ViewHolder(viewHolder);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieListItem movieListItem = movieListItems.get(position);
        holder.textView.setText(movieListItem.getName());
        url = movieListItem.getUrl();
        holder.imageButton.setImageResource(url);
        holder.id = movieListItem.getId();
    }

    @Override
    public int getItemCount() {
        return  movieListItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageButton imageButton;
        TextView textView;
        int id;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageButton = itemView.findViewById(R.id.movieImage);
            textView = itemView.findViewById(R.id.movieNames);

            //Clickable image in the CardView
            imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mListener != null){
                        mListener.onSelectedImage(getAdapterPosition() + 1,textView.getText().toString());
                    }
                }
            });
        }
    }

    interface onSelectImageListener{
        void onSelectedImage(int pos,String movieName);
    }
}
