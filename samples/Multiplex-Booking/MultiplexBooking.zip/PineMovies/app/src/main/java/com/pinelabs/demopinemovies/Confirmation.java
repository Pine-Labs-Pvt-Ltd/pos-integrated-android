package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.pinelabs.demopinemovies.beans.Movie;

import java.util.regex.Pattern;

public class Confirmation extends AppCompatActivity {

    Movie movie;

    private int totalSeats,totalPrice,oneSeatPrice, PHONE_NUM_LENGTH=10;
    private ImageView imageView;
    private String movieName;
    private String seatSelected;
    private TextView tv_movieName,tv_seats,tv_theater,price,tv_date,tv_time;


    private Button pay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);
        getSupportActionBar().hide();

        imageView = findViewById(R.id.imageView3);
        tv_movieName = findViewById(R.id.textView116);
        tv_seats = findViewById(R.id.noofseats);
        tv_theater = findViewById(R.id.theascr);
        price = findViewById(R.id.price);
        tv_date = findViewById(R.id.date);
        tv_time = findViewById(R.id.time);
        pay = findViewById(R.id.pay);

        movie = (Movie) getIntent().getSerializableExtra("Movie");

        totalSeats = movie.getTotalSeats();
        oneSeatPrice = movie.getPrice();
        movieName = movie.getMovieName();
        totalPrice = totalSeats * oneSeatPrice;

        movie.setTotalPrice(totalPrice);

        int url = movie.getDirectoryUrl();
        imageView.setImageResource(url);

        seatSelected = movie.getSeatSelectedFromMovieClass();

        if (seatSelected != null && seatSelected.length() > 0 && seatSelected.charAt(seatSelected.length() - 1) == ',') {
            seatSelected = seatSelected.substring(0, seatSelected.length() - 1);
        }


        //Making movie name Bold
        SpannableString styledString = new SpannableString(movieName);
        styledString.setSpan(new StyleSpan(Typeface.BOLD), 0, movieName.length(), 0);

        tv_movieName.setText(styledString);
        tv_time.setText(movie.getTime());
        tv_date.setText(movie.getDate());
        tv_theater.setText(""+movie.getTheater());
        tv_seats.setText(movie.getSeatSelectedFromMovieClass());
        price.setText("₹ "+totalPrice);

        //starting payment modes activity
        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    Intent intent = new Intent(Confirmation.this,PayNow.class);
                    intent.putExtra("Movie",movie);
                    startActivity(intent);

            }
        });
    }


}