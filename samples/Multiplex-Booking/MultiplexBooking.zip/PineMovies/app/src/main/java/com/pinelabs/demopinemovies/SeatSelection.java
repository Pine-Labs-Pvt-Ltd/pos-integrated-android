package com.pinelabs.demopinemovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import com.pinelabs.demopinemovies.adapter.MovieSeatAdapter;
import com.pinelabs.demopinemovies.beans.Movie;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SeatSelection extends AppCompatActivity {

    private Button buttonSeatSelected;

    Set<Integer> listOfSeat;

    private int numberOfColumns,numberOfSeats;
    private  int theater, NO_SEAT_SELECTED=0;

    private List<Integer> items;

    DataBaseHandler db;
    SQLiteDatabase sql;

    Movie movie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_selection);
        getSupportActionBar().hide();

        listOfSeat = new HashSet<>();
        buttonSeatSelected = findViewById(R.id.button_seat_selected);

        movie = (Movie) getIntent().getSerializableExtra("Movie");
        theater = movie.getTheater();

        db = new DataBaseHandler(getApplicationContext());
        sql = db.getReadableDatabase();

        Cursor cursor = db.getTheaterInfo(sql,Integer.toString(theater));

        while(cursor.moveToNext()){
            numberOfSeats = cursor.getInt(0);
            numberOfColumns = cursor.getInt(1);
        }

        items = new ArrayList<>();
        for (int index=0; index<numberOfSeats; index++) {
            items.add(R.drawable.available);
        }

        GridView gridView =  findViewById(R.id.seat_items);
        gridView.setNumColumns(numberOfColumns);

        final MovieSeatAdapter adapter = new MovieSeatAdapter(SeatSelection.this, items,movie,buttonSeatSelected);

        gridView.setAdapter(adapter);

        buttonSeatSelected.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               int num = movie.getTotalSeats();

               //Moving to next activity if seat(s) is/are chosen
               if (num > NO_SEAT_SELECTED){
                   Intent intent = new Intent(SeatSelection.this,Confirmation.class);
                   intent.putExtra("Movie", movie);
                   startActivity(intent);
               }
               else {
                   Toast.makeText(SeatSelection.this,R.string.PLEASE_ONE_SEAT,Toast.LENGTH_SHORT).show();
               }
           }
       });
    }

    //to set the slot again to chosen slot
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MovieDetails.chosenSlot=movie.getTime();
    }
}