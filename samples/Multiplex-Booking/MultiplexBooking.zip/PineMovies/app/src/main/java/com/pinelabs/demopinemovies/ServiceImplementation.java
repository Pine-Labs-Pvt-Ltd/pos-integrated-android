package com.pinelabs.demopinemovies;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import static android.content.Context.BIND_AUTO_CREATE;

public class ServiceImplementation {
    private static final int MASTER_APP = 2;
    private static final int MY_APP = 1001;

    private static final String TAG = MainActivity.class.getSimpleName();

    private static ServiceImplementation INSTANCE;
    private Messenger mSeverMessenger, mClientMessenger;
    private boolean isBound;
    private MyAppCallBack myAppCallBack;

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mSeverMessenger = new Messenger(iBinder);
            isBound = true;

            try{
                linkToDeath(iBinder);
            }
            catch (RemoteException e){
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mSeverMessenger = null;
            isBound = false;
            if(myAppCallBack!=null)
                myAppCallBack.connectAgain();

        }

        private void linkToDeath(IBinder iBinder) throws RemoteException{
            iBinder.linkToDeath(new IBinder.DeathRecipient() {
                @Override
                public void binderDied() {
                    Log.d(TAG, "Device service is dead. Reconnecting...");
                }},0);
        }
    };

    private ServiceImplementation(){
        HandlerThread thread = new HandlerThread("My App Thread");
        thread.start();

        mClientMessenger = new Messenger(new IncomingHandler(thread));
    }

    public static ServiceImplementation getInstance(){
        if(INSTANCE == null){
            synchronized (ServiceImplementation.class){
                if(INSTANCE==null)
                    INSTANCE = new ServiceImplementation();
            }
        }
        return INSTANCE;
    }

    public void connect(MyAppCallBack myAppCallBack){
        this.myAppCallBack = myAppCallBack;
        if(!isBound){
            Intent intent = new Intent();
            intent.setAction(AppConfig.PINE_ACTION);
            intent.setPackage(AppConfig.PINE_PACKAGE);

            try {
                ThisApplication.getAppContext().bindService(intent, connection,BIND_AUTO_CREATE);
            }catch (Exception e){
                    e.getMessage();
            }
        }
    }

    public void callMyAppService(final HeaderRequest request){
        sendMessage(MY_APP,GsonUtils.fromJsonToString(request));
    }

    public void sendMessage(final int what, final String value){
        if(isBound && mSeverMessenger!=null){
            Message message = Message.obtain(null,what);
            Bundle data = new Bundle();
            data.putString(AppConfig.REQUEST_KEY, value);
            message.setData(data);
            try {
                message.replyTo = mClientMessenger;
                mSeverMessenger.send(message);

                if(myAppCallBack!=null)
                    myAppCallBack.showWaitingDialog();
            }
            catch (RemoteException e)
            {
                e.printStackTrace();
            }
        }
        else{
            if(myAppCallBack!=null){
                myAppCallBack.showToast("Service is not connected");
                myAppCallBack.connectAgain();
            }
        }
    }

    public interface MyAppCallBack{
        void showToast(String msg);
        void connectAgain();
        void sendResult(DetailResponse detailResponse);
        void showWaitingDialog();
    }

    private void showDialog(final DetailResponse detailResponse) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                myAppCallBack.sendResult(detailResponse);
            }
        });
    }

    private class IncomingHandler extends Handler {

        IncomingHandler(HandlerThread thr) {
            super(thr.getLooper());
        }

        @Override
        public void handleMessage(Message msg) {
            Bundle bundle;
            String value;
            switch (msg.what) {
                case MASTER_APP:
                    bundle = msg.getData();
                    value = bundle.getString(AppConfig.RESPONSE_KEY);

                    BaseResponse response = GsonUtils.fromStringToJson(value, BaseResponse.class);
                    if (response != null)
                        value = response.getResponseMessage();

                    Log.d("byte value", value + "");
                    break;
                case MY_APP:
                    bundle = msg.getData();
                    value = bundle.getString(AppConfig.RESPONSE_KEY);
                    Log.d("Value ", value);

                    DetailResponse detailResponse = GsonUtils.fromStringToJson(value, DetailResponse.class);
                    showDialog(detailResponse);
                    break;
                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

}
