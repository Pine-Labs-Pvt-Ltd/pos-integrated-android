package com.pinelabs.raptorcabs;

//Shows the list of booking history
public class Book {
    private String PickupLocation;
    private String DropLocation;
    private String Dates;

    //Return the Ride Date
    public String getDates() {
        return Dates;
    }

    //Return the Pickup Location
    public String getPickupLocation() {
        return PickupLocation;
    }

    //Return the Drop Location
    public String getDropLocation() {
        return DropLocation;
    }

    //use for storing the data of pickup, drop, date in the form of book to the ViewListOfContent
    public Book(String pickupLocation, String dropLocation, String date1) {
        PickupLocation = pickupLocation;
        DropLocation = dropLocation;
        Dates=date1;

    }

}

