package com.pinelabs.raptorcabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;

import androidx.appcompat.app.AppCompatActivity;

//Splash activity on Launching the Raptor Cabs App
public class WelcomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                /*Will check whether the user is already logged in or not
                If logged in, It'll take the user from Splash Screen to Map Screen*/
                if (PreferenceHelper.getInstance().isLoggedIn()) {
                    startActivity(new Intent(WelcomeScreen.this, MapActivity.class));
                    //If not logged in, It'll provoke the user to login first
                } else {
                        startActivity(new Intent(WelcomeScreen.this, LoginActivity.class));
                }
                finish();
            }
        },1500);
    }


}