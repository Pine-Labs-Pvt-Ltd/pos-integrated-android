package com.pinelabs.raptorcabs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.pinelabs.raptorcabs.activities.BasePineActivity;
import com.pinelabs.raptorcabs.beans.response.DetailResponse;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;
import com.pinelabs.raptorcabs.utility.UIUtils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

//Shows all the details for a ride of particular pickup and drop location
public class RideDetails extends BasePineActivity implements NavigationView.OnNavigationItemSelectedListener{
    private static RideDetails instance;
    private TextView checkOut;
    TextView pickup_RideDetails, drop_RideDetails, driving_distance_RideDetails,estimated_time,amount_RideDetails,netAmount_RideDetails;
    double distance;
    float amount;
    float netAmount;
    String pickup,drop,time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ride_details_main);
        instance = this;
        initViews();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }
    //returns instance of Ride details activity
    public static RideDetails getInstance() {
        return instance;
    }
    private void initViews() {

        checkOut = findViewById(R.id.tv_amount);
        pickup_RideDetails = findViewById(R.id.pickup_rideValue);
        drop_RideDetails = findViewById(R.id.drop_rideValue);
        driving_distance_RideDetails = findViewById(R.id.distance_rideValue);
        estimated_time = findViewById(R.id.time_rideValue);
        amount_RideDetails = findViewById(R.id.amount_rideValue);
        netAmount_RideDetails = findViewById(R.id.net_amount_rideValue);

        distance = PreferenceHelper.getInstance().getDistance();
        time = PreferenceHelper.getInstance().getDuration();
        pickup = PreferenceHelper.getInstance().getPickup();
        drop = PreferenceHelper.getInstance().getDrop();
        amount = (float) (distance*6);
        netAmount = (float) (amount*1.18);
        pickup_RideDetails.setText(pickup);
        drop_RideDetails.setText(drop);
        driving_distance_RideDetails.setText(String.format(getString(R.string.standard_distance_format), distance));
        estimated_time.setText(time);
        amount_RideDetails.setText(String.format(getString(R.string.standard_amount_format), amount));
        netAmount_RideDetails.setText(String.format(getString(R.string.standard_amount_format), netAmount));

        checkOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actionCheckOut();
            }
        });
    }

    //It will take the code flow to payment mode activity if checkout button is clicked
    private void actionCheckOut()
    {
        startActivity(new Intent(RideDetails.this,PaymentModeActivity.class));
    }
    //Handle the further action if Transaction is successful
    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult(detailResponse);
        if (detailResponse != null && !detailResponse.getResponse().isSuccess()) {
            UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
        }
    }

    //Hanldle action on clicking back button
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    //Handle the further action on clicking navigation drawer
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent homeIntent = new Intent(RideDetails.this,MapActivity.class);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(homeIntent);
        } else if (id == R.id.nav_mybooking) {
            Intent bookingIntent = new Intent(RideDetails.this, MyBookingsActivity.class);
            startActivity(bookingIntent);
        } else if (id == R.id.nav_ratecard) {
            Intent rateIntent = new Intent(RideDetails.this,RateChart.class);
            startActivity(rateIntent);
        }   else if (id == R.id.nav_contact){
            Intent contactIntent = new Intent(RideDetails.this, ContactActivity.class);
            startActivity(contactIntent);
        } else if (id == R.id.nav_about){
            Intent aboutIntent = new Intent(RideDetails.this,AboutActivity.class);
            startActivity(aboutIntent);
        }else if (id == R.id.nav_logout){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.alert_logout_msg);
            builder.setNegativeButton(R.string.no, null);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(RideDetails.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    PreferenceHelper.getInstance().logout();
                    UIUtils.makeToast(RideDetails.this, getString(R.string.msg_logout));
                    finish();
                }
            });
            builder.show();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public float getNetAmount() {
        return netAmount;
    }
}
