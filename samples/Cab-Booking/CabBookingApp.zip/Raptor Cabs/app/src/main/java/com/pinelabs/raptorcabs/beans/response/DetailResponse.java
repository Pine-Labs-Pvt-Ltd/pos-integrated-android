package com.pinelabs.raptorcabs.beans.response;


import com.google.gson.annotations.SerializedName;
import com.pinelabs.raptorcabs.beans.pojo.Header;

public class DetailResponse<T>{

    @SerializedName("Detail")
    private T Detail;

    @SerializedName("Header")
    private Header Header;

    @SerializedName("Response")
    private Response Response;

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    public com.pinelabs.raptorcabs.beans.pojo.Header getHeader() {
        return Header;
    }

    public void setHeader(com.pinelabs.raptorcabs.beans.pojo.Header header) {
        Header = header;
    }

    public com.pinelabs.raptorcabs.beans.response.Response getResponse() {
        return Response;
    }

    public void setResponse(com.pinelabs.raptorcabs.beans.response.Response response) {
        Response = response;
    }
}
