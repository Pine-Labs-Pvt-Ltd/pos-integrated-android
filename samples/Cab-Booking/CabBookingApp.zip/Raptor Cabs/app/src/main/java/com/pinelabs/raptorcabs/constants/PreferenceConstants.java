package com.pinelabs.raptorcabs.constants;

public interface PreferenceConstants {
    String USER_ID_PREF_KEY = "USER_ID_PREF_KEY";
    String PICKUP_LOCATION_PREF_KEY = "PICKUP_LOCATION_PREF_KEY";
    String DROP_LOCATION_PREF_KEY = "DROP_LOCATION_PREF_KEY";
    String DURATION_PREF_KEY = "0.00";
    String ORIGIN = "origin";
    String DESTINATION = "destination";
    String DIRECTIONS_FLAG = "DIRECTIONS_TYPE";
    String DISTANCE_MATRIX_FLAG = "DISTANCE_MATRIX_TYPE";

    String MAP_ACTIVITY_TAG = "Map Activity";
}
