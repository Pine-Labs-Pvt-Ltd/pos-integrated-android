package com.pinelabs.raptorcabs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.pinelabs.raptorcabs.activities.BasePineActivity;
import com.pinelabs.raptorcabs.beans.pojo.PrintData;
import com.pinelabs.raptorcabs.beans.response.DetailResponse;
import com.pinelabs.raptorcabs.helper.PineServiceHelper;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;
import com.pinelabs.raptorcabs.helper.PrinterHelper;
import com.pinelabs.raptorcabs.utility.DateUtils;
import com.pinelabs.raptorcabs.utility.UIUtils;
import com.google.android.material.navigation.NavigationView;

import java.util.List;

//Will generate Invoice on successful transaction and handle further action of printing the invoice
public class InvoiceActivity extends BasePineActivity implements NavigationView.OnNavigationItemSelectedListener{
    private long dtInMs;
    private Button btnPrint;
    private String billRefNo;
    TextView pickup_txt,drop_txt,distance_txt,amount_txt,netAmount_txt;
    float distance;
    float amount;
    float netAmount;
    String pickup,drop;
    MainDatabaseHelper myDB;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDB = new MainDatabaseHelper(this);
        setContentView(R.layout.invoice_main);
        initViews();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    //Initialize the text views of Invoice activity
    private void initViews() {
        TextView tvTxNo = findViewById(R.id.tv_tx_no);
        TextView tvTxDT = findViewById(R.id.tv_tx_dt);
        TextView tvTxTime = findViewById(R.id.tv_tx_time);
        btnPrint = findViewById(R.id.btn_print);
        pickup_txt = findViewById(R.id.pickup_invoice);
        drop_txt = findViewById(R.id.drop_invoice);
        distance_txt = findViewById(R.id.distance_invoice);
        amount_txt = findViewById(R.id.amount_invoice);
        netAmount_txt = findViewById(R.id.net_amount_invoice);

        pickup = PreferenceHelper.getInstance().getPickup();
        drop = PreferenceHelper.getInstance().getDrop();
        distance = PreferenceHelper.getInstance().getDistance();
        amount = distance*6;
        netAmount = (float) (amount*1.18);

        pickup_txt.setText(pickup);
        drop_txt.setText(drop);
        distance_txt.setText(String.format(getString(R.string.standard_distance_format),distance));
        amount_txt.setText(String.format(getString(R.string.standard_amount_format),amount));
        netAmount_txt.setText(String.format(getString(R.string.standard_amount_format),netAmount));

        dtInMs = System.currentTimeMillis();
        tvTxDT.setText(DateUtils.getDate(dtInMs));
        tvTxTime.setText(DateUtils.getTime(dtInMs));
        tvTxNo.setText(getBillRefNo());
    }

    //Print the Invoice on clicking Print Invoice button
    public void onPrintClick(View view) {

        List<PrintData> printData = PrinterHelper.getInstance().getPrintData(dtInMs);
        PineServiceHelper.getInstance().connect(this);
        PineServiceHelper.getInstance().printData(printData);
    }

    //This function will disable print invoice button if it clicked once to print the invoice
    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult(detailResponse);
        if (detailResponse != null) {
            if (detailResponse.getResponse().isSuccess()) {

                //if the invoice is printed once, disable teh print invoice button
                btnPrint.setEnabled(false);
                btnPrint.setAlpha(.3f);

            } else {
                UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
            }
        }
    }


    // Method use to end transaction and clear all locally stored cart data
    private void endTxn() {
        Intent intent = new Intent(this, MapActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    //Skip Printing and Open MapActivity
    public void onDoneClick(View view) {
        endTxn();
    }

    //If user destroy the activity without printing invoice or clicking done button
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    //Generate the Bill Reference Number
    public String getBillRefNo() {
        if (TextUtils.isEmpty(billRefNo)) {
            billRefNo = String.valueOf(System.currentTimeMillis());
        }
        return billRefNo;
    }

    // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    //Handle the further action on clicking navigation drawer
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent homeIntent = new Intent(InvoiceActivity.this,MapActivity.class);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(homeIntent);
        } else if (id == R.id.nav_mybooking) {
            Intent bookingIntent = new Intent(InvoiceActivity.this, MyBookingsActivity.class);
            startActivity(bookingIntent);
            finish();
        } else if (id == R.id.nav_ratecard) {
            Intent rateIntent = new Intent(InvoiceActivity.this, RateChart.class);
            startActivity(rateIntent);
        } else if (id == R.id.nav_contact){
            Intent contactIntent = new Intent(InvoiceActivity.this, ContactActivity.class);
            startActivity(contactIntent);
            finish();
        } else if (id == R.id.nav_about){
            Intent aboutIntent = new Intent(InvoiceActivity.this, AboutActivity.class);
            startActivity(aboutIntent);
            finish();
        }else if (id == R.id.nav_logout){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.alert_logout_msg);
            builder.setNegativeButton(R.string.no, null);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(InvoiceActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    PreferenceHelper.getInstance().logout();
                    UIUtils.makeToast(InvoiceActivity.this, getString(R.string.msg_logout));
                    finish();
                }
            });
            builder.show();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //Handle the action on clicking the back button
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            UIUtils.makeToast(this, getString(R.string.invoice_onbackpress_message));
        }
    }
}
