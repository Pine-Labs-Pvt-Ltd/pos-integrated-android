package com.pinelabs.raptorcabs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;

import static com.pinelabs.raptorcabs.constants.ApplicationConstants.REGEX_PHONE_NUMBER;

//Will handle the action in Login Screen
public class LoginActivity extends AppCompatActivity {

    Button login;
    Button register;
    MainDatabaseHelper mainDb;
    private AwesomeValidation awesomeValidation;
    int passLen;
    EditText number_login;
    EditText password_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        mainDb = new MainDatabaseHelper(this);
        register = findViewById(R.id.register);
        number_login = findViewById(R.id.login_phone);
        password_login = findViewById(R.id.login_password);
        login = findViewById(R.id.login);

        //Login phone number regex validation
        awesomeValidation.addValidation(this, R.id.login_phone, REGEX_PHONE_NUMBER, R.string.mobileerror);

        // Capture login button clicks
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                //check Regex validation on Phone number
                if (awesomeValidation.validate()) {
                    passLen = password_login.getText().length();

                    //check for password length
                    if (passLen > 7) {
                        login(Long.parseLong(number_login.getText().toString()), password_login.getText().toString());
                        password_login.setText("");
                    }
                    else {
                        Toast.makeText(getApplicationContext(), getString(R.string.minimum_password_length_message), Toast.LENGTH_LONG).show();
                    }
                }

            }
        });
        // Capture register button clicks
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                Intent registerIntent = new Intent(LoginActivity.this,
                        RegisterActivity.class);
                startActivity(registerIntent);
                finish();
            }
        });
    }

    //check whether the password entered matches with password stored in the database to the entered corresponding phone number
    public void login(Long num,String pass)
    {
        String tempPass;
        String mUserID = number_login.getText().toString().trim();
        tempPass = mainDb.loginSuccess(num);
        if(tempPass != null) {
            try {
                if (EncryptDecrypt.encrypt(pass).equals(tempPass)) {
                    PreferenceHelper.getInstance().saveUserID(mUserID);
                    Intent loginIntent = new Intent(LoginActivity.this,
                            MapActivity.class);
                    startActivity(loginIntent);
                    finish();//redirect to home page
                } else {
                    Toast toast2 = Toast.makeText(getApplicationContext(), getString(R.string.invalid_details_message), Toast.LENGTH_SHORT);
                    toast2.show();
                    //message display error
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else {
            Toast toast3 = Toast.makeText(getApplicationContext(), getString(R.string.invalid_details_message), Toast.LENGTH_SHORT);
            toast3.show();
            //message display error
        }
    }

    //Handle the action on clicking Back Button
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

