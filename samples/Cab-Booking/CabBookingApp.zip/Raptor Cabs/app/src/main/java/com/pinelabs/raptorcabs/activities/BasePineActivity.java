package com.pinelabs.raptorcabs.activities;

import com.pinelabs.raptorcabs.R;
import com.pinelabs.raptorcabs.beans.response.DetailResponse;
import com.pinelabs.raptorcabs.helper.PineServiceHelper;
import com.pinelabs.raptorcabs.utility.UIUtils;

public abstract class BasePineActivity extends BaseActivity implements PineServiceHelper.PineCallBack {
    @Override
    protected void onRestart() {
        super.onRestart();
        PineServiceHelper.getInstance().connect(this);
    }

    @Override
    public void showToast(String msg) {
        UIUtils.dismissProgressbar();
        UIUtils.makeToast(this, msg);
    }

    @Override
    public void connectAgain() {
        UIUtils.dismissProgressbar();
        PineServiceHelper.getInstance().connect(this);
    }

    @Override
    public void sendResult(DetailResponse detailResponse) {
        UIUtils.dismissProgressbar();
    }

    @Override
    public void showWaitingDialog() {
        UIUtils.showDialog(this, getString(R.string.please_Wait));
    }

}
