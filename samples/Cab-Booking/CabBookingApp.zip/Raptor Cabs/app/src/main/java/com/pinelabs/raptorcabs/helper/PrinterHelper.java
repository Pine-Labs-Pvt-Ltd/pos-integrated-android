package com.pinelabs.raptorcabs.helper;

import com.pinelabs.raptorcabs.R;
import com.pinelabs.raptorcabs.RideDetails;
import com.pinelabs.raptorcabs.beans.pojo.PrintData;
import com.pinelabs.raptorcabs.config.AppConfig;
import com.pinelabs.raptorcabs.config.MyApplication;
import com.pinelabs.raptorcabs.utility.AndroidUtils;
import com.pinelabs.raptorcabs.utility.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class PrinterHelper {
    private static PrinterHelper INSTANCE;
    private ArrayList<PrintData> printDataList;
    private long dtInMs;

    private PrinterHelper() {
    }

    public static PrinterHelper getInstance() {
        if (INSTANCE == null) {
            synchronized (PrinterHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new PrinterHelper();
                }
            }
        }
        return INSTANCE;
    }

    public List<PrintData> getPrintData(long dtInMs) {
        this.dtInMs = dtInMs;
        printDataList = new ArrayList<>();
        addHeaders();

        PrintData printDataSeparator = new PrintData(AppConfig.Separator);

        String amount = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion((long) (PreferenceHelper.getInstance().getDistance()*600)));

        PrintData printDataDistance = new PrintData(getString(R.string.tag_distance), Float.toString(PreferenceHelper.getInstance().getDistance()));
        printDataList.add(printDataDistance);
        PrintData printDataRate = new PrintData(getString(R.string.tag_rate), getString(R.string.standard_rate));
        printDataList.add(printDataRate);
        PrintData printDataTotal = new PrintData(getString(R.string.tag_total), amount);
        printDataList.add(printDataTotal);


        PrintData printDataTax = new PrintData(getString(R.string.tag_tax), getString(R.string.standard_tax));
        printDataList.add(printDataTax);

        printDataList.add(printDataSeparator);

        String netPay = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion((long) RideDetails.getInstance().getNetAmount()*100));
        PrintData printDataNetPay = new PrintData(getString(R.string.tag_net_pay), netPay);
        printDataList.add(printDataNetPay);

        printDataList.add(printDataSeparator);

        PrintData printDataEmpty = new PrintData("\n");
        printDataList.add(printDataEmpty);
        printDataList.add(printDataEmpty);
        printDataList.add(printDataEmpty);
        printDataList.add(printDataEmpty);

        return printDataList;
    }

    /**
     * Add Basic Header in the receipt
     */
    private void addHeaders() {
        PrintData printData = new PrintData(getString(R.string.tag_invoice));
        printDataList.add(printData);

        PrintData appMchineName = new PrintData(getString(R.string.store_test_store), getString(R.string.plutus));
        printDataList.add(appMchineName);

        PrintData printData1 = new PrintData(getString(R.string.tag_inv_no),String.valueOf(System.currentTimeMillis()));
        printDataList.add(printData1);

        PrintData printData2 = new PrintData(getString(R.string.tag_amt),Float.toString(RideDetails.getInstance().getNetAmount()));
        printDataList.add(printData2);

        PrintData printData3 = new PrintData(getString(R.string.tag_dt), DateUtils.getDate(dtInMs));
        printDataList.add(printData3);

        PrintData printData4 = new PrintData(getString(R.string.tag_time), DateUtils.getTime(dtInMs));
        printDataList.add(printData4);

        PrintData printData7 = new PrintData(AppConfig.Separator);
        printDataList.add(printData7);

        PrintData printData6 = new PrintData(getString(R.string.tag_ride_details), getString(R.string.tag_price));
        printDataList.add(printData6);

        printDataList.add(printData7);
    }

    private String getString(int resId) {
        return MyApplication.getAppContext().getString(resId);
    }

}
