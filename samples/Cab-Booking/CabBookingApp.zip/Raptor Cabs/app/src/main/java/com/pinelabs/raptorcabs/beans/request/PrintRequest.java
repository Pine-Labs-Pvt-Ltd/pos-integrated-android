package com.pinelabs.raptorcabs.beans.request;

import com.google.gson.annotations.SerializedName;
import com.pinelabs.raptorcabs.beans.pojo.LookUpInfo;
import com.pinelabs.raptorcabs.beans.pojo.PrintData;

import java.util.ArrayList;
import java.util.List;

/*
 * Created by Pinelabs Pvt Ltd on 5/10/2018.
 */

public class PrintRequest {
    @SerializedName("PrintRefNo")
    private String PrintRefNo;

    @SerializedName("SavePrintData")
    private boolean SavePrintData;

    @SerializedName("Data")
    private List<PrintData> Data;

    @SerializedName("PrintDataInfo")
    private List<LookUpInfo> PrintDataInfo;

    @SerializedName("AdditionalInfo")
    private List<LookUpInfo> AdditionalInfo;

    public List<PrintData> getData() {
        return Data;
    }

    public void setData(List<PrintData> data) {
        Data = data;
    }

    public void addData(String data) {
        if (Data == null) {
            Data = new ArrayList<>();
        }

        Data.add(new PrintData(data));
    }

    public String getPrintRefNo() {
        return PrintRefNo;
    }

    public void setPrintRefNo(String printRefNo) {
        PrintRefNo = printRefNo;
    }

    public boolean isSavePrintData() {
        return SavePrintData;
    }

    public void setSavePrintData(boolean savePrintData) {
        SavePrintData = savePrintData;
    }

    public List<LookUpInfo> getPrintDataInfo() {
        return PrintDataInfo;
    }

    public void setPrintDataInfo(List<LookUpInfo> printDataInfo) {
        PrintDataInfo = printDataInfo;
    }

    public List<LookUpInfo> getAdditionalInfo() {
        return AdditionalInfo;
    }

    public void setAdditionalInfo(List<LookUpInfo> additionalInfo) {
        AdditionalInfo = additionalInfo;
    }
}
