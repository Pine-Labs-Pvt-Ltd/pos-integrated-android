package com.pinelabs.raptorcabs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.pinelabs.raptorcabs.helper.PreferenceHelper;
import com.pinelabs.raptorcabs.utility.UIUtils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

//Activity to extract data from database and show it the booking history
public class MyBookingsActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    MainDatabaseHelper myDB;
    ArrayList<Book> bookList;
    ListView listView;
    Book book;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_list_of_content_main);
        myDB = new MainDatabaseHelper(this);
        bookList = new ArrayList<>();
        Cursor data = myDB.getListContents();
        int numRows = data.getCount();
        //checks if database is empty or not
        if(numRows == 0){
            Toast.makeText(MyBookingsActivity.this,getString(R.string.empty_database),Toast.LENGTH_LONG).show();
        }else{
            int i=0;
            while(data.moveToNext()){
                //To add data(rows) to the Table on the basis of the Column Index
                book = new Book(data.getString(1),data.getString(2),data.getString(3));
                bookList.add(i,book);
                System.out.println(data.getString(1)+" "+data.getString(2));
                System.out.println(bookList.get(i).getPickupLocation());
                i++;
            }
            ThreeColumnListAdapter adapter =  new ThreeColumnListAdapter(this, R.layout.list_adapter_view, bookList);
            listView = findViewById(R.id.listView);
            listView.setAdapter(adapter);
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        //capture click of floating action button
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent contact = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(contact);
                finish();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    //Hanldle action on clicking back button
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    //Hanlde the further action on clicking navigation drawer
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent homeIntent = new Intent(this,MapActivity.class);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(homeIntent);
        } else if (id == R.id.nav_mybooking) {
            Intent bookingIntent = new Intent(this, MyBookingsActivity.class);
            startActivity(bookingIntent);
            finish();
        } else if (id == R.id.nav_ratecard) {
            Intent rateIntent = new Intent(this,RateChart.class);
            startActivity(rateIntent);
            finish();
        } else if (id == R.id.nav_contact){
            Intent contactIntent = new Intent(this, ContactActivity.class);
            startActivity(contactIntent);
            finish();
        } else if (id == R.id.nav_about){
            Intent aboutIntent = new Intent(this,AboutActivity.class);
            startActivity(aboutIntent);
            finish();
        }else if (id == R.id.nav_logout){

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.alert_logout_msg);
            builder.setNegativeButton(R.string.no, null);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(MyBookingsActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    PreferenceHelper.getInstance().logout();
                    UIUtils.makeToast(MyBookingsActivity.this, getString(R.string.msg_logout));
                    finish();
                }
            });
            builder.show();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
