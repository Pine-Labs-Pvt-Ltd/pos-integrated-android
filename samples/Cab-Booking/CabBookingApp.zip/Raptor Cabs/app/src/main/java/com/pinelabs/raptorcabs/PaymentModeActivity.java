package com.pinelabs.raptorcabs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.pinelabs.raptorcabs.activities.BasePineActivity;
import com.pinelabs.raptorcabs.beans.request.DoTransactionRequest;
import com.pinelabs.raptorcabs.beans.request.HeaderRequest;
import com.pinelabs.raptorcabs.beans.response.DetailResponse;
import com.pinelabs.raptorcabs.enums.PaymentModeEnum;
import com.pinelabs.raptorcabs.helper.PineServiceHelper;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;
import com.pinelabs.raptorcabs.utility.UIUtils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

//Handle the further action if a particular payment mode is selected in Payment mode activity
public class PaymentModeActivity extends BasePineActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static PaymentModeActivity instance;
    @NonNull
    private PineServiceHelper pineSH;
    private String billRefNo;
    private TextView PayableAmount;
    float netAmount;
    Button cash,card,upi,bharatQR;
    MainDatabaseHelper myDB;
    String pickup,drop;

    private void initViews() {
        PayableAmount = findViewById(R.id.netAmount_payMode);
        pineSH = PineServiceHelper.getInstance();
        PayableAmount = findViewById(R.id.netAmount_payMode);
        cash = findViewById(R.id.cash);
        card = findViewById(R.id.card);
        upi = findViewById(R.id.upi);
        bharatQR = findViewById(R.id.bharatQR);
        pickup = PreferenceHelper.getInstance().getPickup();
        drop = PreferenceHelper.getInstance().getDrop();
        netAmount = (float) (PreferenceHelper.getInstance().getDistance()*6*1.18);
        PayableAmount.setText(String.format(getString(R.string.net_payable_amount) + " " + getString(R.string.standard_amount_format),netAmount));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDB = new MainDatabaseHelper(this);
        setContentView(R.layout.payment_mode_main);
        setBackButton();
        initViews();
        setData();
        instance = this;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);

        //Capture floating action button click
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent contact = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(contact);

            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    //returns instance of payment mode activity
    public static PaymentModeActivity getInstance() {
        return instance;
    }
    private void setData() {
        //Connecting to the Pine Service Helper
         pineSH.connect(this);

         //Will take to Invoice activity if cash mode is selected
        cash.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                //Add the pickup and drop location to the database
                String add_pickup = pickup;
                String add_drop = drop;
                try {
                    if (add_pickup.length() != 0 && add_drop.length() != 0) {
                        boolean res = myDB.addData(add_pickup, add_drop);
                        if(res)
                            Toast.makeText(PaymentModeActivity.this,getString(R.string.ride_details_added),Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(PaymentModeActivity.this,getString(R.string.addition_failed),Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(PaymentModeActivity.this, getString(R.string.put_something_message), Toast.LENGTH_LONG).show();
                    }
                }catch(NullPointerException e)
                {
                    e.printStackTrace();
                }

                startActivity(new Intent(PaymentModeActivity.this, InvoiceActivity.class));
            }
        });

        //Will connect Pine payment app if Card mode is selected for transaction
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.Sale.getRequest();
                callPineService(headerRequest);
            }
        });

        //Will connect Pine payment app if UPI mode is selected for trasaction
        upi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.UPI.getRequest();
                callPineService(headerRequest);
            }
        });

        //Will connect Pine payment app if Bharat QR mode is selected for trasaction
        bharatQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.Bharat_QR.getRequest();
                callPineService(headerRequest);
            }
        });
        }

        //Connect Pine payment payment app for a particular mode of trasaction
    private void callPineService(final HeaderRequest<DoTransactionRequest> headerRequest) {

        DoTransactionRequest request = headerRequest.getDetail();
        request.setBillingRefNo(getBillRefNo());
        request.setPaymentAmount((long) (netAmount*100));
        pineSH.callPineService(headerRequest);
    }

    //Handle the action if transaction is successful or not
    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult( detailResponse);
        if (detailResponse != null) {
            //Check if the transaction is successful or not
            if (detailResponse.getResponse().isSuccess()) {
                //if the Transaction is successful then add the pickup and drop location to the database
                String add_pickup = pickup;
                String add_drop = drop;
                try {
                    if (add_pickup.length() != 0 && add_drop.length() != 0) {
                        boolean res = myDB.addData(add_pickup, add_drop);
                        if(res)
                            Toast.makeText(PaymentModeActivity.this,getString(R.string.ride_details_added),Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(PaymentModeActivity.this,getString(R.string.addition_failed),Toast.LENGTH_LONG).show();
                    }

                    else {
                        Toast.makeText(PaymentModeActivity.this, getString(R.string.put_something_message), Toast.LENGTH_LONG).show();
                    }
                }catch(NullPointerException e) {
                    e.printStackTrace();
                }
                //Open invoice on successful Transaction.
                    openInvoice();
            } else {
                UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
            }
        } else {
            UIUtils.makeToast(this, getString(R.string.error_occured));
        }
    }

    //Function to open Invoice activity
    private void openInvoice() {
        startActivity(new Intent(this, InvoiceActivity.class));
    }

    //Will generate the Billing number which is further passed to Pine payment app
    public String getBillRefNo() {
        if (TextUtils.isEmpty(billRefNo)) {
            //To Generate Bill reference number
            billRefNo = String.valueOf(System.currentTimeMillis());
        }
        return billRefNo;
    }

    //Handle the action on clicking the back button
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    //Hanlde the further action on clicking navigation drawer
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent homeIntent = new Intent(PaymentModeActivity.this, MapActivity.class);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(homeIntent);
        } else if (id == R.id.nav_mybooking) {
            Intent bookingIntent = new Intent(PaymentModeActivity.this, MyBookingsActivity.class);
            startActivity(bookingIntent);
        } else if (id == R.id.nav_ratecard) {
            Intent rateIntent = new Intent(PaymentModeActivity.this, RateChart.class);
            startActivity(rateIntent);
        } else if (id == R.id.nav_contact){
            Intent contactIntent = new Intent(PaymentModeActivity.this, ContactActivity.class);
            startActivity(contactIntent);
        } else if (id == R.id.nav_about){
            Intent aboutIntent = new Intent(PaymentModeActivity.this, AboutActivity.class);
            startActivity(aboutIntent);
        }else if (id == R.id.nav_logout){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.alert_logout_msg);
            builder.setNegativeButton(R.string.no, null);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(PaymentModeActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    PreferenceHelper.getInstance().logout();
                    UIUtils.makeToast(PaymentModeActivity.this, getString(R.string.msg_logout));
                    finish();
                }
            });
            builder.show();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
