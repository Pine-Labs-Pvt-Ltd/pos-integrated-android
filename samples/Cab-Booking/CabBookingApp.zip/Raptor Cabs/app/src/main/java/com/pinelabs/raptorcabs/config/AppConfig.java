package com.pinelabs.raptorcabs.config;



public class AppConfig {
    public static final Integer PrinterWidth = 24;
    public static final String Separator = String.format("%0" + PrinterWidth + "d", 0).replace("0", "-");

    public static final String REQUEST_KEY = "MASTERAPPREQUEST";
    public static final String RESPONSE_KEY = "MASTERAPPRESPONSE";

    public static final String PINE_ACTION = "com.pinelabs.masterapp.SERVER";
    public static final String PINE_PACKAGE = "com.pinelabs.masterapp";

}
