package com.pinelabs.raptorcabs.constants;

public interface ApplicationConstants {

    String DISTANCE_MATRIX_TYPE = "distancematrix";
    String DIRECTIONS_TYPE = "directions";
    String MESSAGE_DIGEST_ALGORITHM_TYPE = "MD5";
    String KEY_GENERATOR_ALGORITHM_TYPE = "AES";
    String SECURE_RANDOM_ALGORITHM_TYPE = "SHA1PRNG";
    String SECURE_RANDOM_PROVIDER = "Crypto";
    String SECRET_KEY_SPEC_ALGORITHM_TYPE = "AES";
    String CIPHER_TRANSFORMATION = "AES";
    String REGEX_PHONE_NUMBER = "^[2-9]{2}[0-9]{8}$";
    String REGEX_NAME ="^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$";
    double PINE_LABS_LATITUDE = 28.6209906;
    double PINE_LABS_LONGITUDE = 77.3555655;
    float PINE_LABS_MARKER_DEFAULT_ZOOM = 12f;
    String NAME = "NAME";
    String NUMBER = "NUMBER";
    String PASSWORD = "PASSWORD";
    String DRIVERS = "DRIVERS";
    String PICK_LOCATION = "PICK_LOCATION";
    String DROP_LOCATION = "DROP_LOCATION";
    String DATE = "DATE";
    String DATABASE_NAME = "pineRide.db";
    int DATABASE_VERSION = 1;
    String TABLE_DRIVERS = "DRIVERS";
    String COLUMN_NAME = "NAME";
    String COLUMN_NUMBER = "NUMBER";
    String COLUMN_PASSWORD = "PASSWORD";
    String TABLE_BOOKLIST = "BOOKLIST";
    String seedValue = "123";
    String MY_LOCATION = "My Location";
}
