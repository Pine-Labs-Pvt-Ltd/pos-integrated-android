package com.pinelabs.raptorcabs;

import com.pinelabs.raptorcabs.helper.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//Class to fetch different type of Distance matrix data from JSON
public class JSONParserTaskDistanceMatrix {
    public void parse(JSONObject jObject) {
        JSONArray jRows;
        JSONArray jElements;
        String distance_value;
        float distance;
        String time;

        try {
            jRows = jObject.getJSONArray("rows");
            jElements = ((JSONObject) jRows.get(0)).getJSONArray("elements");

            //Get the Driving distance value from JSON
            distance_value = ((JSONObject) ((JSONObject) jElements.get(0)).get("distance")).getString("value");
            distance = (Float.parseFloat(distance_value)/1000);
            PreferenceHelper.getInstance().saveDistance(distance);

            //Get the estimated time from JSON
            time = (String) ((JSONObject) ((JSONObject) jElements.get(0)).get("duration")).get("text");
            PreferenceHelper.getInstance().saveDuration(time);
        }
        catch (JSONException e) {
            e.printStackTrace();
        }catch (Exception e){
        }
    }
}
