package com.pinelabs.raptorcabs;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;

import java.util.HashMap;

import static com.pinelabs.raptorcabs.constants.ApplicationConstants.REGEX_NAME;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.REGEX_PHONE_NUMBER;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.seedValue;

//Allow the user to register if not already registered
public class RegisterActivity extends AppCompatActivity {
    Button register_final;
    MainDatabaseHelper mainDb;
    HashMap<String ,String> item;
    int passwordLength;
    private AwesomeValidation awesomeValidation;
    EditText name_register,number_register,password_register,confirmPassword_register;

    //Function to encrypt the entered password for security purpose
    public String encryption(String strNormalText){

        String normalTextEnc="";
        try {
            normalTextEnc = EncryptDecrypt.encrypt(strNormalText);
            String test  = EncryptDecrypt.decrypt(seedValue,normalTextEnc);
            Log.i("Check",getString(R.string.normal_text)+strNormalText+getString(R.string.encrypted)+normalTextEnc+getString(R.string.decrypted)+test);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return normalTextEnc;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        item = null;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        name_register = findViewById(R.id.name);
        number_register = findViewById(R.id.phone_number);
        password_register = findViewById(R.id.password);
        confirmPassword_register = findViewById(R.id.confirmPassword);

        register_final = findViewById(R.id.register_final);
        mainDb = new MainDatabaseHelper(RegisterActivity.this);

        //Validate the entered name and phone number details from the Regex
        awesomeValidation.addValidation(this, R.id.name, REGEX_NAME, R.string.nameerror);
        awesomeValidation.addValidation(this, R.id.phone_number, REGEX_PHONE_NUMBER, R.string.mobileerror);

        // Capture button clicks
        register_final.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                //check Regex validation on Name and Phone Number
                if (awesomeValidation.validate()){
                    String mUserID = name_register.getText().toString().trim();
                    passwordLength = password_register.getText().length();
                    //Check Password length
                    if (passwordLength > 7) {
                        //check whether entered password in both text fields are same or not
                        if (password_register.getText().toString().equals(confirmPassword_register.getText().toString())) {
                            try {
                                item = mainDb.returnSingleItem(Long.parseLong(number_register.getText().toString()));
                            }
                            catch (Exception e)
                            {
                                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                            }
                            if (item == null) {
                                boolean flag;
                                //encrypt the password to be stored in database
                                String temp=""+encryption(password_register.getText().toString());
                                flag = mainDb.addItem(name_register.getText().toString(),Long.parseLong(number_register.getText().toString()), temp);
                                if (flag) {
                                    //save phone number in string format
                                    PreferenceHelper.getInstance().saveUserID(mUserID);
                                    Toast.makeText(getApplicationContext(), R.string.succesfull_registration_message, Toast.LENGTH_LONG).show();
                                    Intent registerIntent = new Intent(RegisterActivity.this,
                                            MapActivity.class);
                                    startActivity(registerIntent);
                                    registerIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    finish();//redirect to login page
                                } else {
                                    //message display : please enter details correctly
                                    Toast toast = Toast.makeText(getApplicationContext(), R.string.correct_details_message, Toast.LENGTH_SHORT);
                                    toast.setMargin(50, 50);
                                    toast.show();

                                }
                            } else {
                                Toast toast2 = Toast.makeText(getApplicationContext(), R.string.number_already_registered, Toast.LENGTH_SHORT);//Display message already registered
                                toast2.show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), R.string.password_should_match, Toast.LENGTH_LONG).show();
                        }
                    }
                    else {
                        Toast.makeText(getApplicationContext(), R.string.minimum_length_password, Toast.LENGTH_LONG).show();
                    }
            }
            }
        });
    }

}
