package com.pinelabs.raptorcabs;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import com.pinelabs.raptorcabs.utility.DateUtils;

import java.util.HashMap;

import static com.pinelabs.raptorcabs.constants.ApplicationConstants.COLUMN_NAME;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.COLUMN_NUMBER;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.COLUMN_PASSWORD;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DATABASE_NAME;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DATABASE_VERSION;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DATE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DRIVERS;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DROP_LOCATION;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.NAME;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.NUMBER;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.PASSWORD;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.PICK_LOCATION;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.TABLE_BOOKLIST;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.TABLE_DRIVERS;

//This activity handles data in SQLite Database
public class MainDatabaseHelper extends SQLiteOpenHelper {

    private static MainDatabaseHelper instance;
    public String name;
    private long dtInMs;

    MainDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        instance = this;
        String createTable1 = "CREATE TABLE " + TABLE_DRIVERS +
                "(NAME TEXT not null, NUMBER INTEGER PRIMARY KEY NOT NULL, PASSWORD TEXT NOT NULL)";
        db.execSQL(createTable1);
        String createTable2 = "CREATE TABLE " + TABLE_BOOKLIST + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                " PICK_LOCATION TEXT not null, DROP_LOCATION TEXT NOT NULL, DATE Text)";
        db.execSQL(createTable2);
    }

    //returns instance of class
    public static MainDatabaseHelper getInstance()
    {
        return instance;
    }

    //Delete old version of tables if exist and create new table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS DRIVERS");
        db.execSQL("DROP TABLE IF EXISTS BOOKLIST");
        onCreate(db);
    }

    //add the registration data into the database
    public boolean addItem(String name, Long num, String pswrd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues item = new ContentValues();
        item.put(NAME, name);
        item.put(NUMBER, num);
        item.put(PASSWORD, pswrd);
        return db.insert(DRIVERS, null, item) != -1;
    }

    //add the registration data into the data base if entered phone number doesn't exist already exist
    public HashMap<String, String> returnSingleItem(Long num) {
        try {
            HashMap<String, String> new_items_added = new HashMap<>();
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = null;
            cursor = db.query(TABLE_DRIVERS, new String[]{COLUMN_NAME, COLUMN_NUMBER, COLUMN_PASSWORD}, "NUMBER=?", new String[]{Long.toString(num)}, null, null, null);
            if (((cursor != null) && (cursor.getCount() > 0))) {
                while (cursor.moveToNext()) {
                    new_items_added.put(NAME, cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                    new_items_added.put(NUMBER, cursor.getString(cursor.getColumnIndex(COLUMN_NUMBER)));
                    new_items_added.put(PASSWORD, cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD)));
                }
                db.close();
            } else {
                return null;
            }
            return new_items_added;
        } catch (SQLiteException e) {
            return null;
        }
    }

    //Verify the password from the data base corresponding the entered phone number
    public String loginSuccess(Long num)
    {
        try {
            String password=null;
            Long temp_num=num;
            String number;
            number=temp_num.toString();
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(TABLE_DRIVERS, new String[]{COLUMN_PASSWORD}, "NUMBER=?", new String[]{number}, null, null, null);
            if (((cursor != null) && (cursor.getCount() > 0)))
            {
                while (cursor.moveToNext())
                {
                    password = cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD));
                }
                db.close();
                return password;
            }
            else {
                return null;
            }
        }
        catch (SQLiteException e) {
            return null;
        }
    }

    //Add the pickup and drop location in the database
    public boolean addData(String pick,String drop)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(PICK_LOCATION,pick);
        contentValues.put(DROP_LOCATION,drop);
        dtInMs = System.currentTimeMillis();
        contentValues.put(DATE, DateUtils.getDate(dtInMs) + "\n" + DateUtils.getTime(dtInMs) );
        long result=db.insert(TABLE_BOOKLIST,null,contentValues);
        return result != -1;
    }

    //Get the value of pickup and drop location from the database
    public Cursor getListContents()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor data =db.rawQuery("SELECT *FROM " + TABLE_BOOKLIST,null);
        return data;
    }
}
