package com.pinelabs.raptorcabs.helper;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.pinelabs.raptorcabs.config.MyApplication;
import com.pinelabs.raptorcabs.constants.PreferenceConstants;

public class PreferenceHelper {
    private static PreferenceHelper sInstance;
    private final SharedPreferences mPreferences;
    private float distance;
    private PreferenceHelper() {
        mPreferences = PreferenceManager.getDefaultSharedPreferences(MyApplication.getAppContext());
    }

    public static PreferenceHelper getInstance() {
        if (sInstance == null)
            sInstance = new PreferenceHelper();
        return sInstance;
    }

    /********
     * USER ID
     **********/
    public String getUserID() {
        return mPreferences.getString(PreferenceConstants.USER_ID_PREF_KEY, "");
    }
    public String getPickup() {
        return mPreferences.getString(PreferenceConstants.PICKUP_LOCATION_PREF_KEY, "");
    }
    public String getDrop() {
        return mPreferences.getString(PreferenceConstants.DROP_LOCATION_PREF_KEY, "");
    }
    public Float getDistance() {
        return distance;
    }
    public String getDuration() {
        return mPreferences.getString(PreferenceConstants.DURATION_PREF_KEY, "0.00");
    }
    public void saveUserID(String userID) {
        mPreferences.edit().putString(PreferenceConstants.USER_ID_PREF_KEY, userID).apply();
    }
    public void savePickupLocation(String pickup) {
        mPreferences.edit().putString(PreferenceConstants.PICKUP_LOCATION_PREF_KEY, pickup).apply();
    }
    public void saveDropLocation(String drop) {
        mPreferences.edit().putString(PreferenceConstants.DROP_LOCATION_PREF_KEY, drop).apply();
    }
    public void saveDistance(Float distance) {
        this.distance = distance;
    }
    public void saveDuration(String duration) {
        mPreferences.edit().putString(PreferenceConstants.DURATION_PREF_KEY, duration).apply();
    }

    public boolean isLoggedIn() {
        return !TextUtils.isEmpty(getUserID());
    }

    public void logout() {
        mPreferences.edit().clear().commit();
    }

}