package com.pinelabs.raptorcabs.enums;


public enum BillingMethodId {
    DO_TRANSACTION("1001"),
    PRINT("1002"),
    LAUNCH_APP("1005");


    private String value;

    BillingMethodId(String s) {
        value = s;
    }

    public String getValue() {
        return value;
    }
}
