package com.pinelabs.raptorcabs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

//Activity to handle layout of MyBookingsActivity activity into 3 columns
public class ThreeColumnListAdapter extends ArrayAdapter<Book> {

    private LayoutInflater mInflater;
    private ArrayList<Book> books;
    private int mViewResourceId;

    //This adapter fills data into the columns from the data source
    public ThreeColumnListAdapter(Context context, int textViewResourceId, ArrayList<Book> books) {
        super(context, textViewResourceId, books);
        this.books = books;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mViewResourceId = textViewResourceId;
    }

    //Initialize the view of details which is to be stored in the respective 3 columns
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView = mInflater.inflate(mViewResourceId, null);

        Book book = books.get(position);

        if (book != null) {
            TextView pickupLocation = convertView.findViewById(R.id.pickl);
            TextView dropLocation = convertView.findViewById(R.id.dropl);
            TextView currentDate =  convertView.findViewById(R.id.date);
           // TextView favFood = (TextView) convertView.findViewById(R.id.textFavFood);
            if (pickupLocation != null) {
                pickupLocation.setText(book. getPickupLocation());
            }
            if (dropLocation != null) {
                dropLocation.setText((book.getDropLocation()));
            }
           if (currentDate != null) {
                currentDate.setText((book.getDates()));
            }
        }
        return convertView;
    }
}