package com.pinelabs.raptorcabs.utility;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Pinelabs Pvt Ltd on 9/1/2017.
 */

public class DateUtils {

    /**
     * Get date.
     */
    public static String getDate(Date date, String expectedFormat) {
        SimpleDateFormat format = new SimpleDateFormat(expectedFormat);
        return format.format(date);
    }

    /**
     * Get current time.
     */
    public static String getCurrentTime(String format) {
        SimpleDateFormat df = new SimpleDateFormat(format);
        Date curDate = new Date(System.currentTimeMillis());
        return df.format(curDate);
    }

    public static String getDate(long dateMs) {
        // Create a DateFormatter object for displaying date in specified
        // format.
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(dateMs);
        return formatter.format(calendar.getTime());
    }

    public static String getTime(long dateMs) {
        // Create a DateFormatter object for displaying date in specified
        // format.
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss a", Locale.getDefault());

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(dateMs);
        return formatter.format(calendar.getTime());
    }

}
