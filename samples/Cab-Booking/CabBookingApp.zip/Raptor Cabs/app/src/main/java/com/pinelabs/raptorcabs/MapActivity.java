package com.pinelabs.raptorcabs;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.pinelabs.raptorcabs.activities.BasePineActivity;
import com.pinelabs.raptorcabs.beans.response.DetailResponse;
import com.pinelabs.raptorcabs.constants.PreferenceConstants;
import com.pinelabs.raptorcabs.helper.PineServiceHelper;
import com.pinelabs.raptorcabs.helper.PreferenceHelper;
import com.pinelabs.raptorcabs.utility.UIUtils;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DIRECTIONS_TYPE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.DISTANCE_MATRIX_TYPE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.MY_LOCATION;
import static com.pinelabs.raptorcabs.constants.PreferenceConstants.DESTINATION;
import static com.pinelabs.raptorcabs.constants.PreferenceConstants.DIRECTIONS_FLAG;
import static com.pinelabs.raptorcabs.constants.PreferenceConstants.DISTANCE_MATRIX_FLAG;
import static com.pinelabs.raptorcabs.constants.PreferenceConstants.ORIGIN;

//This activity will handle all the actions in Map Window
public class MapActivity extends BasePineActivity implements OnMapReadyCallback,
        GoogleApiClient.OnConnectionFailedListener,NavigationView.OnNavigationItemSelectedListener {
        private static MapActivity instance;
    Button ride_now;
    LatLng dropPosition, pickPosition, currentLocation;
    LatLngBounds bounds;
    private String apiKey = BuildConfig.API_KEY;
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 15f;
    private ImageView mGps;
    private Boolean mLocationPermissionsGranted = false;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private AutocompleteSupportFragment pickup_autocompleteFragment, drop_autocompleteFragment;
    public static final float HUE_RED = 0.0F;
    public static final float HUE_GREEN = 120.0F;

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Toast.makeText(this, getString(R.string.map_ready), Toast.LENGTH_SHORT).show();
        Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.map_ready));
        mMap = googleMap;

        //if location is not granted then gps marker will not be displayed on the map
        if (mLocationPermissionsGranted) {
            getDeviceLocation();

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
            initViews();
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instance = this;
        ride_now = findViewById(R.id.get_details);
        mGps = findViewById(R.id.ic_gps);
        PineServiceHelper.getInstance().connect(this);
        //Get permission for the app to access location of the device
        getLocationPermission();
        //Initialize the Map Fragment
        initMap();
        //Initialize the Views of Map Activity
        initViews();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        //capture button click of floating action button
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent contact = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(contact);
            }
        });

        //Navigation drawer functionality
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    //Function to connect Pine payment app
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        PineServiceHelper.getInstance().connect(this);
    }

    //Returns the instance of Map Activity
    public static MapActivity getInstance() {
        return instance;
    }

    //Initialize the Views of Map Activity
    private void initViews(){

        Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.initializing));

        //Initialize Places with API Key
        Places.initialize(getApplicationContext(), apiKey);

        pickup_autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.id_PickUp);
        pickup_autocompleteFragment.setHint(getString(R.string.pickup_hint));

        //Filter the pickup search results for India
        pickup_autocompleteFragment.setCountry(getString(R.string.country));

        drop_autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.id_Drop);
        drop_autocompleteFragment.setHint(getString(R.string.drop_hint));

        //Filter the Drop search results for India
        drop_autocompleteFragment.setCountry(getString(R.string.country));

        pickup_autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.NAME, Place.Field.LAT_LNG, Place.Field.ADDRESS));
        drop_autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.NAME, Place.Field.LAT_LNG, Place.Field.ADDRESS));

        //Capture fragment click of pickup location
        pickup_autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                Log.i(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.place) + place.getName());
                    //save the pickup place name
                    PreferenceHelper.getInstance().savePickupLocation(place.getName());
                    mMap.clear();
                    pickPosition = place.getLatLng();
                    moveCamera(pickPosition, DEFAULT_ZOOM, place.getAddress(), HUE_GREEN);

                    /*Check if the drop position is null or not, If it is not null then place
                    the marker to the pickup position else draw the route between pickup and drop location*/
                    if (dropPosition != null) {

                        mMap.clear();
                        moveCamera(pickPosition, DEFAULT_ZOOM, PreferenceHelper.getInstance().getPickup(), HUE_GREEN);
                        moveCamera(dropPosition, DEFAULT_ZOOM, PreferenceHelper.getInstance().getDrop(), HUE_RED);
                        bounds = new LatLngBounds.Builder().include(pickPosition)
                                .include(dropPosition).build();
                        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 200));

                        //Create the directions URL for selected pick up and drop position
                        String directionUrl = Url(pickPosition,dropPosition,DIRECTIONS_FLAG);
                        Log.d("directionURL", directionUrl);

                        //Fetch the Direction URL
                        FetchUrl_Direction fetchUrl_direction = new FetchUrl_Direction();
                        fetchUrl_direction.execute(directionUrl);
                    }
                }
            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
                Log.i(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.error_occured) + status);
            }
        });

        //Capture fragment click drop location
        drop_autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                Log.i(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.place) + place.getName());
                //save the drop place name
                PreferenceHelper.getInstance().saveDropLocation(place.getName());
                mMap.clear();
                dropPosition = place.getLatLng();
                moveCamera(dropPosition, DEFAULT_ZOOM, place.getAddress(), HUE_RED);

                 /*Check if the Pickup position is null or not, If it is not null
                  then draw the route between pickup and drop location*/
                if (pickPosition != null) {

                    mMap.clear();
                    moveCamera(pickPosition, DEFAULT_ZOOM, PreferenceHelper.getInstance().getPickup(), HUE_GREEN);
                    moveCamera(dropPosition, DEFAULT_ZOOM, PreferenceHelper.getInstance().getDrop(), HUE_RED);
                    bounds = new LatLngBounds.Builder().include(pickPosition)
                            .include(dropPosition).build();
                    mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 200));

                    //Create the directions URL for selected pick up and drop position
                    String directionUrl = Url(pickPosition,dropPosition,DIRECTIONS_FLAG);
                    Log.d("directionURL", directionUrl);

                    //Fetch the Direction URL
                    FetchUrl_Direction fetchUrl_direction = new FetchUrl_Direction();
                    fetchUrl_direction.execute(directionUrl);
                }
            }
            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
                Log.i(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.error_occured) + status);
            }
        });

        //Capture button click of Ride now
        ride_now.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                if (pickPosition == null || dropPosition == null){
                    Toast.makeText(MapActivity.this,getString(R.string.select_location),Toast.LENGTH_LONG).show();
                }
                else {

                    //Create the Distance matrix url for pickup and drop location
                    String distanceMatrixUrl = Url(pickPosition,dropPosition,DISTANCE_MATRIX_FLAG);
                    Log.d("distanceMatrixUrl", distanceMatrixUrl);

                    //Fetch the Distance Matrix URL
                    FetchUrl_Distance_Matrix fetchUrl_distance_matrix = new FetchUrl_Distance_Matrix();
                    fetchUrl_distance_matrix.execute(distanceMatrixUrl);
                }
            }
        });

        //capture click of GPS Button
        mGps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.gps_clicked));

                if(mLocationPermissionsGranted)
                {
                    //getDeviceLocation();
                    //initMap();
                    pickup_autocompleteFragment.setText(getString(R.string.yourLocation));
                    PreferenceHelper.getInstance().savePickupLocation(getString(R.string.yourLocation));
                    mMap.clear();
                    pickPosition = currentLocation;
                    moveCamera(pickPosition, DEFAULT_ZOOM, getString(R.string.yourLocation), HUE_GREEN);
               /*Check if the drop position is  null or not, If it is not null
                  then draw the route between pickup and drop location*/
                    if (dropPosition != null) {

                        mMap.clear();
                        moveCamera(pickPosition, DEFAULT_ZOOM, getString(R.string.yourLocation), HUE_GREEN);
                        moveCamera(dropPosition, DEFAULT_ZOOM, PreferenceHelper.getInstance().getDrop(), HUE_RED);
                        bounds = new LatLngBounds.Builder().include(pickPosition)
                                .include(dropPosition).build();
                        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 200));

                        String directionUrl = Url(pickPosition,dropPosition,DIRECTIONS_FLAG);
                        Log.d("directionURL", directionUrl);
                        FetchUrl_Direction fetchUrl_direction = new FetchUrl_Direction();
                        fetchUrl_direction.execute(directionUrl);
                    }
                }
                else{
                    getLocationPermission();
                    if(mLocationPermissionsGranted)
                    {
                        getDeviceLocation();
                        mMap.setMyLocationEnabled(true);
                    }

                    //initMap();
                }
            }
        });
        hideSoftKeyboard();
    }

    //Make the url in string format to hit Google APIs
    private String Url(LatLng pickup, LatLng drop, String flag)
    {
        String url_initial_part = getString(R.string.initial_part);
        String origin,destination;
        String sensor = getString(R.string.sensor);
        String output = getString(R.string.JSON);
        String type;

        //Condition to hit distance matrix API
        if(flag.equals(DISTANCE_MATRIX_FLAG))
        {
            origin = ORIGIN + "s";
            destination = DESTINATION + "s";
            type = DISTANCE_MATRIX_TYPE;
        }

        //Condition to hit directions API
        else {
            origin = ORIGIN;
            destination = DESTINATION;
            type = DIRECTIONS_TYPE;
        }

        //Put the pickup and drop location details into the url parameters
        String parameters = origin + "=" + pickup.latitude + "," + pickup.longitude + "&" + destination + "=" + drop.latitude + "," + drop.longitude + "&" + sensor;

        //Create the URL string to hit the google Server
        String url = url_initial_part + type + "/" + output + "?" + parameters + "&key=" + apiKey;
        return url;
    }

    //Get the Direction data in JSON Format and then execute it
    private class FetchUrl_Direction extends AsyncTask<String, Void, String> {

        //Execute the url in background process.
        @Override
        protected String doInBackground(String... url) {
            String data = "";

            //Download the URL
            try {
                data = downloadUrl(url[0]);
                Log.d("Background Task data", data);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        //Execute the downloaded data
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask_Direction parserTask = new ParserTask_Direction();
            parserTask.execute(result);

        }
    }

    //Get Distance data from the URL in String format
    private class FetchUrl_Distance_Matrix extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... url) {
            String data = "";

            //Download the URL
            try {
                data = downloadUrl(url[0]);
                Log.d("Background Task data", data);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        //Execute the downloaded data
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            ParserTask_Distance_Matrix parserTask_distance_matrix = new ParserTask_Distance_Matrix();
            parserTask_distance_matrix.execute(result);
        }
    }

    //Download the data in the from of String from the given URL
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            Log.d("downloadUrl", data);
            br.close();
        } catch (Exception e) {
            Log.d("Exception", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    //Class to process and execute the downloaded direction data in the form of JSON and then process it to draw polyline on Map
    private class ParserTask_Direction extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                Log.d("ParserTask",jsonData[0].toString());
                JSONParserTaskDirection direction_parser = new JSONParserTaskDirection();
                Log.d("ParserTask", direction_parser.toString());

                //Parse the routes details of downloaded Directions Data in the form of JSON object
                routes = direction_parser.parse(jObject);
                Log.d("ParserTask",getString(R.string.executing_routes));
                Log.d("ParserTask",routes.toString());

            } catch (Exception e) {
                Log.d("ParserTask",e.toString());
                e.printStackTrace();
            }
            return routes;
        }

        //After executing the data in JSON format, draw polyline
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList<LatLng> points;
            PolylineOptions lineOptions = null;
            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList<>();
                lineOptions = new PolylineOptions();
                List<HashMap<String, String>> path = result.get(i);
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);
                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);
                    points.add(position);
                }

                //Add the characteristics of polyline
                lineOptions.addAll(points);
                lineOptions.width(22);
                lineOptions.color(0xFF1464F4);

            }
            if(lineOptions != null) {
                mMap.addPolyline(lineOptions);
            }
            else {
                Log.d("onPostExecute",getString(R.string.polyline_message));
            }
        }
    }

    //Class to process and execute the downloaded distance data in the form of JSON
    private class ParserTask_Distance_Matrix  {

        protected void execute(String... jsonData) {

            JSONObject jObject;
            try {
                jObject = new JSONObject(jsonData[0]);
                Log.d("ParserTask",jsonData[0]);
                JSONParserTaskDistanceMatrix distance_matrix_parser = new JSONParserTaskDistanceMatrix();
                Log.d("ParserTask", distance_matrix_parser.toString());
                distance_matrix_parser.parse(jObject);
                startActivity(new Intent(MapActivity.this, RideDetails.class));

            } catch (Exception e) {
                Log.d("ParserTask",e.toString());
                e.printStackTrace();
            }
        }
    }

    //Get the device GPS Location in real time
    private void getDeviceLocation(){
        Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.getting_location));

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        try{
            //Check if location permission is granted or not
            if(mLocationPermissionsGranted){

                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if(task.isSuccessful()){
                            Location currentLocation = (Location) task.getResult();
                            if(currentLocation == null) {
                                Toast.makeText(MapActivity.this,R.string.location_error_message,Toast.LENGTH_LONG).show();
                        }
                            else {
                                MapActivity.this.currentLocation = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(MapActivity.this.currentLocation, DEFAULT_ZOOM));
                            }
                        }
                        else{
                            Toast.makeText(MapActivity.this, R.string.location_error_message, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }catch (SecurityException e){
            Log.e(PreferenceConstants.MAP_ACTIVITY_TAG, R.string.security_exception + e.getMessage() );
        }
    }

    //It'll move the camera to the particular Latitude and Longitude of the input location
    private void moveCamera(LatLng latLng, float zoom, String title, float HUE_COLOR){
        if(latLng == null)
        {
            Toast.makeText(MapActivity.this,"Location not accessed",Toast.LENGTH_LONG).show();
            pickup_autocompleteFragment.setText("");
        }
        else {
            Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, R.string.moving_camera + latLng.latitude + getString(R.string.longitude) + latLng.longitude );
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));

            if(!title.equals(MY_LOCATION)){
                MarkerOptions options = new MarkerOptions()
                        .position(latLng)
                        .title(title).icon(BitmapDescriptorFactory.defaultMarker(HUE_COLOR));
                mMap.addMarker(options);
            }
        }

        hideSoftKeyboard();
    }

    //Initialize the Map
    private void initMap(){
        Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.initializing_map));
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(MapActivity.this);
    }

    //Get device permission to access GPS Location
    private void getLocationPermission(){
        Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.getting_location_permission));
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionsGranted = true;
                initMap();
            }else{
                ActivityCompat.requestPermissions(this,
                        permissions,
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        }else{
            ActivityCompat.requestPermissions(this,
                    permissions,
                    LOCATION_PERMISSION_REQUEST_CODE);

        }
    }

    //Take permission from the user to allow access to GPS Location
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        mLocationPermissionsGranted = false;

        if(requestCode == LOCATION_PERMISSION_REQUEST_CODE){
            if(grantResults.length > 0){
                for(int i = 0; i < grantResults.length; i++){
                    if(grantResults[i] != PackageManager.PERMISSION_GRANTED){
                        mLocationPermissionsGranted = false;
                        Log.d(PreferenceConstants.MAP_ACTIVITY_TAG,getString(R.string.permission_failed));
                        return;
                    }
                }
                Log.d(PreferenceConstants.MAP_ACTIVITY_TAG, getString(R.string.permission_granted));
                mLocationPermissionsGranted = true;
                initMap();
            }
        }
    }

    //Handle action on clicking back button
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    //Handle the further action on clicking navigation drawer
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent homeIntent = new Intent(MapActivity.this,MapActivity.class);
            startActivity(homeIntent);
            finish();
        } else if (id == R.id.nav_mybooking) {
            Intent bookingIntent = new Intent(MapActivity.this, MyBookingsActivity.class);
            startActivity(bookingIntent);

        } else if (id == R.id.nav_ratecard) {
            Intent rateIntent = new Intent(MapActivity.this,RateChart.class);
            startActivity(rateIntent);

        } else if (id == R.id.nav_contact){
            Intent contactIntent = new Intent(MapActivity.this, ContactActivity.class);
            startActivity(contactIntent);

        } else if (id == R.id.nav_about){
            Intent aboutIntent = new Intent(MapActivity.this,AboutActivity.class);
            startActivity(aboutIntent);
        }else if (id == R.id.nav_logout){
            actionLogout();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //Handle the action if Logout button is clicked in the Navigation drawer
    public void actionLogout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.alert_logout_msg);
        builder.setNegativeButton(R.string.no, null);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(MapActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                PreferenceHelper.getInstance().logout();
                UIUtils.makeToast(MapActivity.this, getString(R.string.msg_logout));
                finish();
            }
        });
        builder.show();

    }

    //Responsible for returning to Map screen if the transaction is successful
    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult(detailResponse);
        if (detailResponse != null && !detailResponse.getResponse().isSuccess()) {
            UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
        }
    }
}
