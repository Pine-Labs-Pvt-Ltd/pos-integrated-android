package com.pinelabs.raptorcabs.enums;

import com.pinelabs.raptorcabs.beans.request.DoTransactionRequest;
import com.pinelabs.raptorcabs.beans.request.HeaderRequest;

public enum PaymentModeEnum {

    Sale("Card", new DoTransactionRequest(4001L)),
    UPI("UPI", new DoTransactionRequest(5120L)),
    Bharat_QR("Bharat QR", new DoTransactionRequest(5123L));

    private final String name;
    private HeaderRequest<DoTransactionRequest> request;

    PaymentModeEnum(String s, DoTransactionRequest doTransactionRequest) {
        this.name = s;
        request = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        request.setDetail(doTransactionRequest);
    }

    public HeaderRequest<DoTransactionRequest> getRequest() {
        return request;
    }

    public String getName() {
        return name;
    }
}
