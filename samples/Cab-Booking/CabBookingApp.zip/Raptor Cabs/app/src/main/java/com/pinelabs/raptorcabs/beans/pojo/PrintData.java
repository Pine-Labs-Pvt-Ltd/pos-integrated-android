package com.pinelabs.raptorcabs.beans.pojo;

import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;
import com.pinelabs.raptorcabs.config.AppConfig;
import com.pinelabs.raptorcabs.utility.AndroidUtils;

/**
 * Print data bean
 */
public class PrintData {

    @SerializedName("PrinterWidth")
    private Integer iPrinterWidth = AppConfig.PrinterWidth;
    @SerializedName("DataToPrint")
    private String strDataToPrint;
    @SerializedName("ImagePath")
    private String strImagePath;
    @SerializedName("ImageData")
    private String strImageData;
    @SerializedName("IsCenterAligned")
    private Boolean IsCenterAligned = true;
    @SerializedName("PrintDataType")
    private int iPrintDataType;

    public PrintData(String value) {
        strDataToPrint = value;
    }

    public PrintData(String key, String txId) {
        strDataToPrint = getFormattedData(key, txId);
    }

    public PrintData() {

    }

    private static String getFormattedData(String key, String value) {
        int keyLen = TextUtils.isEmpty(key) ? 0 : key.length();
        int valueLen = TextUtils.isEmpty(value) ? 0 : value.length();
        int paddingValue = AppConfig.PrinterWidth - keyLen;
        if (paddingValue > valueLen) {
            paddingValue = paddingValue - valueLen;
            value = key + AndroidUtils.leftPadding(value, paddingValue);
        } else {
            value = key + "\n" + value;
        }

        return value;
    }

    public String getStrDataToPrint() {
        return strDataToPrint;
    }

    public void setStrDataToPrint(String strDataToPrint) {
        this.strDataToPrint = strDataToPrint;
    }

    public String getStrImagePath() {
        return strImagePath;
    }

    public void setStrImagePath(String strImagePath) {
        this.strImagePath = strImagePath;
    }

    public String getStrImageData() {
        return strImageData;
    }

    public void setStrImageData(String strImageData) {
        this.strImageData = strImageData;
    }

    public Boolean getCenterAligned() {
        return IsCenterAligned;
    }

    public void setCenterAligned(Boolean centerAligned) {
        IsCenterAligned = centerAligned;
    }

    public Integer getiPrinterWidth() {
        return iPrinterWidth;
    }

    public Integer getiPrintDataType() {
        return iPrintDataType;
    }

    public void setPrintDataType(Integer iPrintDataType) {
        this.iPrintDataType = iPrintDataType;
    }

    public interface DataType {
        int PrintText = 0;
        int PrintImageByPath = 1;
        int PrintImageDump = 2;
        int PrintBarcode = 3;
        int PrintQRCode = 4;
    }
}
