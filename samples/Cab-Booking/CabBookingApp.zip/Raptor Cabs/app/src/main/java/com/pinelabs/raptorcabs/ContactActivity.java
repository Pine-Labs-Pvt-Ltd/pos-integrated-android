package com.pinelabs.raptorcabs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.pinelabs.raptorcabs.helper.PreferenceHelper;
import com.pinelabs.raptorcabs.utility.UIUtils;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import com.google.android.material.navigation.NavigationView;
import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;

import static com.pinelabs.raptorcabs.constants.ApplicationConstants.PINE_LABS_LATITUDE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.PINE_LABS_LONGITUDE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.PINE_LABS_MARKER_DEFAULT_ZOOM;


//Show the contact details about the Pine Labs and Marker on the Location of Pine Lab on Google Maps
public class ContactActivity extends AppCompatActivity implements OnMapReadyCallback,NavigationView.OnNavigationItemSelectedListener{
    GoogleMap mMap_contact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_activity);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map_contact);
        mapFragment.getMapAsync(this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    //Handle action on clicking back button
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    // Inflate the menu; this adds items to the action bar if it is present.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    //Handle the further action on clicking navigation drawer
    //StatementWithEmptyBody
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent homeIntent = new Intent(ContactActivity.this,MapActivity.class);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(homeIntent);
        } else if (id == R.id.nav_mybooking) {
            Intent bookingIntent = new Intent(ContactActivity.this, MyBookingsActivity.class);
            startActivity(bookingIntent);
            finish();
        } else if (id == R.id.nav_ratecard) {
            Intent rateIntent = new Intent(ContactActivity.this,RateChart.class);
            startActivity(rateIntent);
            finish();
        } else if (id == R.id.nav_contact){
            Intent contactIntent = new Intent(ContactActivity.this, ContactActivity.class);
            startActivity(contactIntent);
            finish();
        } else if (id == R.id.nav_about){
            Intent aboutIntent = new Intent(ContactActivity.this,AboutActivity.class);
            startActivity(aboutIntent);
            finish();
        }else if (id == R.id.nav_logout){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.alert_logout_msg);
            builder.setNegativeButton(R.string.no, null);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(ContactActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    PreferenceHelper.getInstance().logout();
                    UIUtils.makeToast(ContactActivity.this, getString(R.string.msg_logout));
                    finish();
                }
            });
            builder.show();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //Place the marker to the location of Pine labs on Google Maps
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap_contact = googleMap;
        LatLng PineLabs = new LatLng(PINE_LABS_LATITUDE,PINE_LABS_LONGITUDE);
        mMap_contact.addMarker(new MarkerOptions().position(PineLabs).title(getString(R.string.pinelabs_marker_title)));
        mMap_contact.moveCamera(CameraUpdateFactory.newLatLngZoom(PineLabs,PINE_LABS_MARKER_DEFAULT_ZOOM));
    }
}
