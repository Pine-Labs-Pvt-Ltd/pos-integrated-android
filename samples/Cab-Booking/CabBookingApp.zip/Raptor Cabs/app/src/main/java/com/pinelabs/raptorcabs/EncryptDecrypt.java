package com.pinelabs.raptorcabs;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import static com.pinelabs.raptorcabs.constants.ApplicationConstants.CIPHER_TRANSFORMATION;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.KEY_GENERATOR_ALGORITHM_TYPE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.MESSAGE_DIGEST_ALGORITHM_TYPE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.SECRET_KEY_SPEC_ALGORITHM_TYPE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.SECURE_RANDOM_ALGORITHM_TYPE;
import static com.pinelabs.raptorcabs.constants.ApplicationConstants.SECURE_RANDOM_PROVIDER;

//Class which handle the encryption and decryption of Password to be stored in database
public class EncryptDecrypt {

    public static String encrypt( String cleartext)  {

        try {
            // Static getInstance method is called with hashing MD5. 
            MessageDigest md = MessageDigest.getInstance(MESSAGE_DIGEST_ALGORITHM_TYPE);

            // digest() method is called to calculate message digest of an input digest() return array of byte
            byte[] messageDigest = md.digest(cleartext.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        }

        // For specifying wrong message digest algorithms

        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    //Function to decrypt the password
    public static String decrypt(String seed, String encrypted) throws Exception {
        byte[] rawKey = getRawKey(seed.getBytes());
        byte[] enc = toByte(encrypted);
        byte[] result = decrypt(rawKey, enc);
        return new String(result);
    }

    //encryption of the entered seed in the form of byte to return a corresponding raw key in the form of byte
    private static byte[] getRawKey(byte[] seed) throws Exception {
        KeyGenerator kGen = KeyGenerator.getInstance(KEY_GENERATOR_ALGORITHM_TYPE);
        SecureRandom sr = SecureRandom.getInstance(SECURE_RANDOM_ALGORITHM_TYPE,SECURE_RANDOM_PROVIDER);
        sr.setSeed(seed);
        kGen.init(128, sr); // 192 and 256 bits may not be available
        SecretKey skey = kGen.generateKey();
        byte[] raw = skey.getEncoded();
        return raw;
    }

    //Function to decrypt the password
    private static byte[] decrypt(byte[] raw, byte[] encrypted) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, SECRET_KEY_SPEC_ALGORITHM_TYPE);
        Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] decrypted = cipher.doFinal(encrypted);
        return decrypted;
    }

    //Covert the hexString to the byte format
    public static byte[] toByte(String hexString) {
        int len = hexString.length()/2;
        byte[] result = new byte[len];
        for (int i = 0; i < len; i++)
            result[i] = Integer.valueOf(hexString.substring(2*i, 2*i+2), 16).byteValue();
        return result;
    }

}
