package com.pinelabs.book.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.beans.pojo.PassengerHistoryBean;
import com.pinelabs.book.helper.StringConstants;

import java.util.List;

/*
        get data from model and set in holder
 */
public class PassengerHistoryAdapter extends RecyclerView.Adapter<PassengerHistoryAdapter.MyViewHolder> {

    private List<PassengerHistoryBean> passengerHistoryBeanList;
    private Context mContext;
    private AdapterCallback callback;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvBusNameHistory, tvStationArrivedHistory, tvStationDestinationHistory, tvDateArrivedHistory,tvCanceledHistory,tvConfirmedHistory;
        public MyViewHolder(View view) {
            super(view);

            tvBusNameHistory = itemView.findViewById(R.id.tvBusNameHistory);
            tvStationArrivedHistory = itemView.findViewById(R.id.tvStationArrivedHistory);
            tvStationDestinationHistory = itemView.findViewById(R.id.tvStationDestinationHistory);
            tvDateArrivedHistory = itemView.findViewById(R.id.tvDateArrivedHistory);
            tvCanceledHistory=itemView.findViewById(R.id.tvCanceledHistory);
            tvConfirmedHistory=itemView.findViewById(R.id.tvConfirmedHistory);
        }
    }
    public interface AdapterCallback{
        void onClickItem(PassengerHistoryBean passengerHistoryBean);
    }

    public PassengerHistoryAdapter(Context mContext, AdapterCallback callback, List<PassengerHistoryBean> passengerHistoryBeanList) {
        this.passengerHistoryBeanList = passengerHistoryBeanList;
        this.callback=callback;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_history, parent, false);
        return new MyViewHolder(itemView);
    }

    //set data on view holder
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final PassengerHistoryBean passengerHistoryBean = passengerHistoryBeanList.get(position);
        holder.tvBusNameHistory.setText(passengerHistoryBean.getBusNameHistory());
        holder.tvStationArrivedHistory.setText(passengerHistoryBean.getStationArrivedHistory());
        holder.tvStationDestinationHistory.setText(passengerHistoryBean.getStationDestinationHistory());
        holder.tvDateArrivedHistory.setText(passengerHistoryBean.getDateArrivedHistory());
        holder.tvCanceledHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(view.getRootView().getContext());
                        alertDialog.setTitle(StringConstants.CANCEL_TICKET)
                                .setMessage(StringConstants.DO_YOU_REALLY_WANT_TO_CANCEL)
                                .setNegativeButton(android.R.string.no, null)
                                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                    public void onClick(DialogInterface arg0, int arg1) {
                                        holder.tvConfirmedHistory.setText(StringConstants.CANCELED);
                                        holder.tvConfirmedHistory.setTextColor(ContextCompat.getColor(mContext, R.color.colorAccent));
                                        holder.tvCanceledHistory.setVisibility(View.INVISIBLE);
                                        if (callback!=null){
                                            callback.onClickItem(passengerHistoryBean);
                                        }
                                    }
                                }).create().show();

                //notifyItemChanged(position);
            }
        });
        if(passengerHistoryBean.getBookedCanceled()==0) {
            holder.tvConfirmedHistory.setText(StringConstants.CANCELED);
            holder.tvConfirmedHistory.setTextColor(ContextCompat.getColor(mContext, R.color.colorAccent));
            holder.tvCanceledHistory.setVisibility(View.INVISIBLE);
        } else {
            holder.tvConfirmedHistory.setText(StringConstants.CONFIRMED);
            holder.tvConfirmedHistory.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary));
            holder.tvCanceledHistory.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return passengerHistoryBeanList.size();
    }

}
