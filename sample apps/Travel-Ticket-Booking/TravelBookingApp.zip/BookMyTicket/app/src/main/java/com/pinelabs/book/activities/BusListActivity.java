package com.pinelabs.book.activities;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.adapters.BusListAdapter;
import com.pinelabs.book.beans.pojo.BusBean;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/*
 *Implements BusListAdapter and get callback of item clicked
 */
public class BusListActivity extends AppCompatActivity implements BusListAdapter.Callback {

    private RecyclerView rvBusList;
    private DBHelper dbHelper;
    private List<BusBean> busBeanList;
    private BusListAdapter mAdapterBus;
    TextView tvBusListSize;
    private boolean flagMenuSortClick = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_list);
        initViews();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        busBeanList = new ArrayList<BusBean>();
        //these constraints will go in db function for search
        Intent intent = getIntent();
        String strAutoCompleteSource = intent.getStringExtra(StringConstants.AUTOCOMPLETE_SOURCE);
        String strAutoCompleteDest = intent.getStringExtra(StringConstants.AUTOCOMPLETE_DESTINATION);

        dbHelper = new DBHelper(BusListActivity.this);
        //get data from database in busBeanList which is model for bus data
        busBeanList = dbHelper.getDataBus(strAutoCompleteSource, strAutoCompleteDest);

        setData();
    }

    //create menu which allows to sort data
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_sort, menu);
        return true;
    }

    //onSelect sort menu change the flag to identify even and odd click
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
            }
            case R.id.sort_price: {
                flagMenuSortClick = !flagMenuSortClick;
                ascendingOrDecending();
                Toast.makeText(this,getString(R.string.BUS_SORTED_BY_PRICE),Toast.LENGTH_SHORT).show();
                setData();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    //get data from busBeanList and set in adapter
    private void setData() {
        if (mAdapterBus == null)
            mAdapterBus = new BusListAdapter(BusListActivity.this, this, busBeanList);
        else {
            mAdapterBus.setList(busBeanList);
        }
        rvBusList.setAdapter(mAdapterBus);
        //set bus list size
        tvBusListSize.setText(busBeanList.size()+getString(R.string.BUSES_FOUND));

    }

    //Rearrange list on runtime according to price
    public void ascendingOrDecending() {
        Collections.sort(busBeanList, new Comparator<BusBean>() {
            @Override
            public int compare(BusBean lhs, BusBean rhs) {
                // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                if (flagMenuSortClick) {
                    return Double.compare(Double.parseDouble(lhs.getBtnBuy()), Double.parseDouble(rhs.getBtnBuy()));
                } else {
                    return Double.compare(Double.parseDouble(rhs.getBtnBuy()), Double.parseDouble(lhs.getBtnBuy()));
                }
            }
        });
    }

    //initiate recycler view
    private void initViews() {
        tvBusListSize=findViewById(R.id.tv_buslistsize);
        rvBusList = findViewById(R.id.rv_bus_list);
        //Manage rv layout
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(BusListActivity.this);
        rvBusList.setLayoutManager(mLayoutManager);
    }

    @Override
    public void onClickItem(BusBean busBean) {
        Toast.makeText(this, busBean.getTxtBusName(), Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, SeatSelectionActivity.class);
        //pass spinner items and bus bean model to next activity
        i.putExtra(StringConstants.BUS_DATA, busBean);
        i.putExtra(StringConstants.SPINNER_PASSENGER_BUS, getIntent().getStringExtra(StringConstants.SPINNER_PASSENGER));
        i.putExtra(StringConstants.SPINNER_CLASS_BUS, getIntent().getStringExtra(StringConstants.SPINNER_CLASS));
        i.putExtras(getIntent());
        startActivity(i);
    }

}
