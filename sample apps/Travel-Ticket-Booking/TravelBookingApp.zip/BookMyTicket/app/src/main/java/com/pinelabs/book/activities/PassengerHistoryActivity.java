package com.pinelabs.book.activities;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.adapters.PassengerHistoryAdapter;
import com.pinelabs.book.beans.pojo.PassengerHistoryBean;
import com.pinelabs.book.db.DBHelper;

import java.util.ArrayList;
import java.util.List;

public class PassengerHistoryActivity extends AppCompatActivity implements PassengerHistoryAdapter.AdapterCallback {

    TextView tvCanceledHistory;
    private RecyclerView rvPassengerHistoryList;
    ImageView ivClearHistory;
    private DBHelper dbHelper;
    private List<PassengerHistoryBean> passengerHistoryBeanList;
    private PassengerHistoryAdapter mAdapterPassengerHistory;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passengerhistory);

        initViews();
        passengerHistoryBeanList = new ArrayList<>();
        //get booking history data and set it in recyclerView
        dbHelper = new DBHelper(PassengerHistoryActivity.this);
        passengerHistoryBeanList = dbHelper.getBookingHistoryData();
        setData();
    }

    //set data to Passenger History Adapter
    private void setData() {

        mAdapterPassengerHistory = new PassengerHistoryAdapter(PassengerHistoryActivity.this, this, passengerHistoryBeanList);
        rvPassengerHistoryList.setAdapter(mAdapterPassengerHistory);
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(PassengerHistoryActivity.this);
        ivClearHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.setTitle(getString(R.string.DELETE_BOOKING_HISTORY))
                        .setMessage(getString(R.string.CONFIRM_DELETE_BOOKING_HISTORY))
                        .setNegativeButton(android.R.string.no, null)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0, int arg1) {
                                if (passengerHistoryBeanList != null) {
                                    dbHelper.deleteHistoryTable();
                                    passengerHistoryBeanList.clear();
                                    mAdapterPassengerHistory.notifyDataSetChanged();
                                }
                            }
                        }).create().show();

            }
        });

    }

    //initiate views for passengerHistory activity
    private void initViews() {

        rvPassengerHistoryList = findViewById(R.id.rv_busHistory);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(PassengerHistoryActivity.this);
        rvPassengerHistoryList.setLayoutManager(mLayoutManager);
        ivClearHistory = findViewById(R.id.iv_clearlistHistory);
        tvCanceledHistory = findViewById(R.id.tvCanceledHistory);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    //Cancel Ticket on TextClick
    @Override
    public void onClickItem(PassengerHistoryBean passengerHistoryBean) {
        Toast.makeText(PassengerHistoryActivity.this, getString(R.string.BOOKING_NO) +" "+passengerHistoryBean.getBookingId()+" "+ getString(R.string.CANCELED), Toast.LENGTH_SHORT).show();
        dbHelper.updateBookingHistory(passengerHistoryBean.getBookingId(), passengerHistoryBean.getBusNameHistory());
    }
}