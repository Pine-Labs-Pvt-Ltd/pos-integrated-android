package com.pinelabs.book.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.adapters.PassengerListAdapter;
import com.pinelabs.book.beans.pojo.PassengerBean;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;

import java.util.ArrayList;
import java.util.List;



public class AddPassengerActivity extends AppCompatActivity {

    TextView tvContinueBooking, tvAddPassenger;
    ImageView ivAddPassenger;
    SharedPreferences sp;
    SharedPreferences.Editor editor;
    int myIntValue;
    private RecyclerView rvPassengerList;
    private DBHelper dbHelper;
    private List<PassengerBean> passengerBeanList;
    private PassengerListAdapter mAdapterPassenger;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpassenger);

        initViews();
        passengerBeanList = new ArrayList<>();

        dbHelper = new DBHelper(AddPassengerActivity.this);
        passengerBeanList = dbHelper.getData();
        setData();
    }
    //set data for add passenger Activity
    private void setData() {

        mAdapterPassenger = new PassengerListAdapter(AddPassengerActivity.this, passengerBeanList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(AddPassengerActivity.this);
        rvPassengerList.setLayoutManager(mLayoutManager);
        rvPassengerList.setAdapter(mAdapterPassenger);
        //get number of clicks in button in a file
        sp = getSharedPreferences(StringConstants.PCOUNT_PREF, Activity.MODE_PRIVATE);
        myIntValue = sp.getInt(StringConstants.PASSENGER_COUNT, 0);
        editor = sp.edit();
        //get data of passenger count from previous page
        String pcount = getIntent().getStringExtra(StringConstants.SPINNER_PASSENGER_1);
        //if both data matches disable button
        if (myIntValue < Integer.parseInt(pcount)) {
            ivAddPassenger.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    editor.putInt(StringConstants.PASSENGER_COUNT, ++myIntValue);
                    editor.commit();
                    Intent intent = new Intent(AddPassengerActivity.this, AddPassengerDetailsActivity.class);
                    intent.putExtras(getIntent());
                    startActivity(intent);
                    finish();
                }
            });
            //make the whole text box clickable to add passenger
            tvAddPassenger.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    editor.putInt(StringConstants.PASSENGER_COUNT, ++myIntValue);
                    editor.commit();
                    Intent intent = new Intent(AddPassengerActivity.this, AddPassengerDetailsActivity.class);
                    intent.putExtras(getIntent());
                    startActivity(intent);
                    finish();
                }
            });
        } else
            Toast.makeText(AddPassengerActivity.this,getString(R.string.MAX_NUMBER_OF_PASSENGER_ADDED), Toast.LENGTH_SHORT).show();
        //proceed to next activity if data matches
        if (myIntValue == Integer.parseInt(pcount)) {
            tvContinueBooking.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(AddPassengerActivity.this, ConfirmTicketActivity.class);
                    intent.putExtras(getIntent());
                    startActivity(intent);
                    finish();
                }
            });
        } else
            Toast.makeText(AddPassengerActivity.this,getString(R.string.ADD_EVERY_PASSENGER_INFO_TO_PROCEED), Toast.LENGTH_SHORT).show();
    }

    //initiate views for add passenger activity
    private void initViews() {
        tvContinueBooking = findViewById(R.id.tv_continuebooking);
        ivAddPassenger = findViewById(R.id.iv_addpassenger);
        rvPassengerList = findViewById(R.id.rv_passengerinfo);
        tvAddPassenger = findViewById(R.id.tv_addpassenger);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
