package com.pinelabs.book.activities;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.pinelabs.book.R;
import com.pinelabs.book.adapters.CustomSwipeAdapter;
import com.pinelabs.book.adapters.RecentSearchAdapter;
import com.pinelabs.book.beans.pojo.RecentSearchBean;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;


public class BusActivity extends AppCompatActivity implements RecentSearchAdapter.Callback {

    private AutoCompleteTextView acTVSource, acTVDestination;
    private TextView tvRoundTrip, tvOneWay, tvReturn;
    private EditText etDepDate, etReturnDate;
    private Spinner spClass;
    private LinearLayout llRoundTrip, llOneWay, llLineRoundTrip, llLineOneWay;
    private FloatingActionButton fabSearchBtn, fabSwaplocationBtn;
    private Spinner spPassengerCount;
    DBHelper db;
    List<String> listClass, listPassenger;
    ArrayList<String> arrStrCitiesSource, arrStrCitiesDestination;
    private Calendar calDepDate = Calendar.getInstance();
    private Calendar calReturnDate = Calendar.getInstance();
    private ViewPager viewPager;
    private CustomSwipeAdapter adapter;
    private Timer timer;
    private int current_position = 0;
    private LinearLayout dotsLayout;
    private int custom_position = 0;
    Animation FabRClockwise, FabRanticlockwise;
    boolean isRotated = false;
    private RecyclerView rvRecentSearch;
    private List<RecentSearchBean> recentSearchBeanList;
    private RecentSearchAdapter mAdapterRecentSearch;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_bus);
        initViews();
        setData();
    }

    //SlideShow for images of bus
    private void createSlideShow() {
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (current_position == Integer.MAX_VALUE)
                    current_position = 0;
                viewPager.setCurrentItem(current_position++, true);
            }
        };
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 250, 2500);
    }

    //Dots that corresponds to a particular slide
    private void prepareDots(int currentSlidePosition) {
        if (dotsLayout.getChildCount() > 0)
            dotsLayout.removeAllViews();

        ImageView dots[] = new ImageView[5];

        for (int i = 0; i < 5; i++) {
            dots[i] = new ImageView(this);
            if (i == currentSlidePosition)
                dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.active_dot));
            else
                dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.inactive_dot));

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(4, 0, 4, 0);
            dotsLayout.addView(dots[i], layoutParams);
        }
    }

    //set data on autocomplete and spinner
    private void setData() {
        recentSearchBeanList = new ArrayList<>();
        db = new DBHelper(this);
        recentSearchBeanList = db.getRecentSearchData();
        arrStrCitiesSource = db.getBusSource();
        arrStrCitiesDestination = db.getBusDestination();

        //recent search adapter puts recentSearchList on recyclerView
        mAdapterRecentSearch = new RecentSearchAdapter(BusActivity.this, this, recentSearchBeanList);
        rvRecentSearch.setAdapter(mAdapterRecentSearch);

        adapter = new CustomSwipeAdapter(this);
        viewPager.setAdapter(adapter);
        prepareDots(custom_position++);
        //create slideshow of bus
        createSlideShow();
        //Move dots according to slideShow
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (custom_position > 4)
                    custom_position = 0;

                prepareDots(custom_position++);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        //Data Mapping for Source
        ArrayAdapter<String> adapterSourceCities = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrStrCitiesSource);
        acTVSource.setAdapter(adapterSourceCities);

        //Data Mapping for Destination
        ArrayAdapter<String> adapterDestCities = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrStrCitiesDestination);
        acTVDestination.setAdapter(adapterDestCities);

        //Do a rotate animation when clicked the swap location button
        fabSwaplocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isRotated)
                    fabSwaplocationBtn.startAnimation(FabRanticlockwise);
                else
                    fabSwaplocationBtn.startAnimation(FabRClockwise);

                Editable s;
                s = acTVSource.getText();
                acTVSource.setText(acTVDestination.getText());
                acTVDestination.setText(s);
            }
        });

        addItemsOnPassengerCount();
        addItemsOnClass();
    }

    //initiate views for busActivity
    private void initViews() {
        acTVSource = findViewById(R.id.actv_source);
        acTVDestination = findViewById(R.id.actv_destination);
        etDepDate = findViewById(R.id.et_dep_date);
        etReturnDate = findViewById(R.id.et_return_date);
        llRoundTrip = findViewById(R.id.ll_round_trip);
        llOneWay = findViewById(R.id.ll_one_way);
        llLineRoundTrip = findViewById(R.id.ll_line_round_trip);
        llLineOneWay = findViewById(R.id.ll_line_one_way);
        tvRoundTrip = findViewById(R.id.tv_round_trip);
        tvReturn = findViewById(R.id.tv_return);
        tvOneWay = findViewById(R.id.tv_one_way);
        spClass = findViewById(R.id.sp_class);
        spPassengerCount = findViewById(R.id.sp_passenger_count);
        fabSearchBtn = findViewById(R.id.fab_search_btn);
        viewPager = findViewById(R.id.view_pager);
        dotsLayout = findViewById(R.id.dotsContainer);
        fabSwaplocationBtn = findViewById(R.id.fab_swaplocation);
        FabRClockwise = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_clockwise);
        FabRanticlockwise = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate_anticlockwise);
        rvRecentSearch = findViewById(R.id.rv_recentsearch);

        //datetime
        final DatePickerDialog.OnDateSetListener dateRoundTrip = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                calDepDate.set(Calendar.MONTH, monthOfYear);
                calDepDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDepDate();
            }

        };

        //set date on calendar
        etDepDate.setOnClickListener(new View.OnClickListener() {

            DatePickerDialog datePickerDialog = new DatePickerDialog(BusActivity.this, dateRoundTrip, calDepDate
                    .get(Calendar.YEAR), calDepDate.get(Calendar.MONTH),
                    calDepDate.get(Calendar.DAY_OF_MONTH));

            @Override
            public void onClick(View v) {
                //disable back date
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
            }
        });

        final DatePickerDialog.OnDateSetListener dateOneWay = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                calReturnDate.set(Calendar.YEAR, year);
                calReturnDate.set(Calendar.MONTH, monthOfYear);
                calReturnDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateReturnDate();
            }
        };

        etReturnDate.setOnClickListener(new View.OnClickListener() {
            DatePickerDialog datePickerDialog = new DatePickerDialog(BusActivity.this, dateOneWay, calReturnDate
                    .get(Calendar.YEAR), calReturnDate.get(Calendar.MONTH),
                    calReturnDate.get(Calendar.DAY_OF_MONTH));

            @Override
            public void onClick(View v) {
                //disable back date
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.show();
            }
        });
        //set visibility for return trip components
        llRoundTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvRoundTrip.setTextColor(Color.parseColor(StringConstants.COLOR_STRING));
                tvOneWay.setTextColor(Color.parseColor(StringConstants.A_7_A));
                llLineRoundTrip.setBackgroundColor(Color.parseColor(StringConstants.COLOR_STRING1));
                llLineOneWay.setVisibility(View.INVISIBLE);
                etReturnDate.setVisibility(View.VISIBLE);
                tvReturn.setVisibility(View.VISIBLE);
                llLineRoundTrip.setVisibility(View.VISIBLE);
            }
        });
        //set visibility for one way components
        llOneWay.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tvRoundTrip.setTextColor(Color.parseColor(StringConstants.A_7_A1));
                        tvOneWay.setTextColor(Color.parseColor(StringConstants.COLOR_STRING2));
                        llLineOneWay.setBackgroundColor(Color.parseColor(StringConstants.COLOR_STRING3));
                        llLineRoundTrip.setVisibility(View.INVISIBLE);
                        etReturnDate.setVisibility(View.INVISIBLE);
                        tvReturn.setVisibility(View.INVISIBLE);
                        llLineOneWay.setVisibility(View.VISIBLE);
                    }
                }
        );
        //search button
        addListenerOnButton();
    }

    //choose a format for entered date
    private void updateDepDate() {
        String myFormat = StringConstants.MMM_DD; //We display this format
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.getDefault());
        etDepDate.setText(sdf.format(calDepDate.getTime()));
    }

    //choose a format for entered date
    private void updateReturnDate() {
        String myFormat = StringConstants.MMM_DD; //We display this format
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.getDefault());
        etReturnDate.setText(sdf.format(calReturnDate.getTime()));
    }

    //add items on spinner class
    private void addItemsOnClass() {
        listClass = new ArrayList<>();
        listClass.add(StringConstants.SEATER);
        listClass.add(StringConstants.SLEEPER);
        listClass.add(StringConstants.AC);
        listClass.add(StringConstants.SEMI_SLEEPER);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listClass);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spClass.setAdapter(dataAdapter);
    }

    //add items on spinner passenger
    private void addItemsOnPassengerCount() {
        listPassenger = new ArrayList<>();
        listPassenger.add("1");
        listPassenger.add("2");
        listPassenger.add("3");
        listPassenger.add("4");
        listPassenger.add("5");
        listPassenger.add("6");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listPassenger);
        spPassengerCount.setAdapter(adapter);
    }
    //search button task
    public void addListenerOnButton() {
        db = new DBHelper(this);
        fabSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //provide validations for all fields
                if (acTVSource.getText().toString().trim().isEmpty())
                    acTVSource.setError(StringConstants.FIELDS_CAN_T_BE_EMPTY);
                else if (acTVDestination.getText().toString().trim().isEmpty())
                    acTVDestination.setError(StringConstants.FIELDS_CAN_T_BE_EMPTY);
                else if (!arrStrCitiesSource.contains(acTVSource.getText().toString()) || !arrStrCitiesDestination.contains(acTVDestination.getText().toString()))
                    Toast.makeText(BusActivity.this,getString(R.string.NO_SOURCE_OR_DESTINATION_WITH_THIS_NAME_FOUND), Toast.LENGTH_SHORT).show();
                else if (etDepDate.getText().toString().trim().isEmpty())
                    Toast.makeText(BusActivity.this, getString(R.string.PLEASE_PROVIDE_JOURNEY_DATE), Toast.LENGTH_SHORT).show();
                else {
                    db.InsertRecentSearch(acTVSource.getText().toString(), acTVDestination.getText().toString(), etDepDate.getText().toString());
                    Intent intent = new Intent(BusActivity.this, BusListActivity.class);
                    intent.putExtra(StringConstants.AUTOCOMPLETE_SOURCE, acTVSource.getText().toString());
                    intent.putExtra(StringConstants.AUTOCOMPLETE_DESTINATION, acTVDestination.getText().toString());
                    intent.putExtra(StringConstants.SPINNER_PASSENGER, spPassengerCount.getSelectedItem().toString());
                    intent.putExtra(StringConstants.JOURNEY_DATE, etDepDate.getText().toString());
                    intent.putExtra(StringConstants.SPINNER_CLASS, spClass.getSelectedItem().toString());
                    startActivity(intent);
                }
            }
        });
    }

    /*
        Exit screen popup on back pressed
        Delete database on exit
        Change the value of shared Preference file
        Finish all stack activity
     */
    @Override
    public void onBackPressed() {
        db = new DBHelper(this);
        new AlertDialog.Builder(this)
                .setTitle(StringConstants.REALLY_EXIT)
                .setMessage(StringConstants.ARE_YOU_SURE_YOU_WANT_TO_EXIT)
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        SharedPreferences sp = getSharedPreferences(StringConstants.PCOUNT_PREF, Activity.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putInt(StringConstants.PASSENGER_COUNT, 0);
                        editor.commit();
                        db.deleteTable();
                        BusActivity.super.onBackPressed();
                        finishAffinity();
                    }
                }).create().show();
    }

    //When Book Now is clicked in Recent Search layout it ask for date and directs it to search page
    @Override
    public void onClickItem(final RecentSearchBean recentSearchBean) {

        final DatePickerDialog.OnDateSetListener dateRoundTrip = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                calDepDate.set(Calendar.MONTH, monthOfYear);
                calDepDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDepDate();
                Intent intent = new Intent(BusActivity.this, BusListActivity.class);
                intent.putExtra(StringConstants.AUTOCOMPLETE_SOURCE, recentSearchBean.getRecentSource());
                intent.putExtra(StringConstants.AUTOCOMPLETE_DESTINATION, recentSearchBean.getRecentDestination());
                intent.putExtra(StringConstants.SPINNER_PASSENGER, spPassengerCount.getSelectedItem().toString());
                intent.putExtra(StringConstants.JOURNEY_DATE, etDepDate.getText().toString());
                intent.putExtra(StringConstants.SPINNER_CLASS, spClass.getSelectedItem().toString());
                startActivity(intent);
            }

        };
        DatePickerDialog datePickerDialog = new DatePickerDialog(BusActivity.this, dateRoundTrip, calDepDate
                .get(Calendar.YEAR), calDepDate.get(Calendar.MONTH),
                calDepDate.get(Calendar.DAY_OF_MONTH));
        //disable back date
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();


    }
}