package com.pinelabs.book.enums;

import com.pinelabs.book.beans.request.DoTransactionRequest;
import com.pinelabs.book.beans.request.HeaderRequest;

public enum PaymentModeEnum {

    Sale("Card", new DoTransactionRequest(4001L)),
    P360_LR("Loyalty Redeem", new DoTransactionRequest(4209L)),
    P360_GVR("Prepaid Redeem", new DoTransactionRequest(4203L)),
    P360_VR("Voucher Redeem", new DoTransactionRequest(4215L)),
    P360_R("Gift Redeem", new DoTransactionRequest(4212L)),
    Payback_R("Payback", new DoTransactionRequest(4402L)),
    Sodexo("Sodexo", new DoTransactionRequest(5106L)),
    UPI("UPI", new DoTransactionRequest(5120L)),
    Bharat_QR("Bharat QR", new DoTransactionRequest(5123L));

    private final String name;
    private HeaderRequest<DoTransactionRequest> request;

    PaymentModeEnum(String s, DoTransactionRequest doTransactionRequest) {
        this.name = s;
       request = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        request.setDetail(doTransactionRequest);
    }

    public HeaderRequest<DoTransactionRequest> getRequest() {
        return request;
    }

    public String getName() {
        return name;
    }
}
