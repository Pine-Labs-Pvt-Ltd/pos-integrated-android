package com.pinelabs.book.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.beans.pojo.PassengerBean;

import java.util.List;

/*
        get data from model and set in holder
 */
public class PassengerListAdapter extends RecyclerView.Adapter<PassengerListAdapter.MyViewHolder> {

    private List<PassengerBean> passengerBeanList;
    private Context mContext;

    public List<PassengerBean> getList() {
        return passengerBeanList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvPassengerName,tvPassengerAge,tvPassengerGender;

        public MyViewHolder(View view) {
            super(view);

           tvPassengerName= itemView.findViewById(R.id.tv_passengername);
           tvPassengerAge=itemView.findViewById(R.id.tv_passengerage);
           tvPassengerGender=itemView.findViewById(R.id.tv_passengergender);

        }
    }

    public PassengerListAdapter(Context mContext, List<PassengerBean> passengerBeanList) {
        this.passengerBeanList = passengerBeanList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_passengerdetails, parent, false);
        return new MyViewHolder(itemView);
    }

    //set data on view holder
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
        PassengerBean passengerBean = passengerBeanList.get(position);
        holder.tvPassengerName.setText(passengerBean.getPassengerName());
        holder.tvPassengerAge.setText(passengerBean.getAge());
        holder.tvPassengerGender.setText(passengerBean.getGender());

    }

    @Override
    public int getItemCount() {
        return passengerBeanList.size();
    }

}