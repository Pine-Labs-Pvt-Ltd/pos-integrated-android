package com.pinelabs.book.activities;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.pinelabs.book.R;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;

public class PaymentSuccessActivity extends AppCompatActivity {

    Button btAnotherPayment;
    FloatingActionButton btContactUs;
    DBHelper db;
    int flag = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paymentsuccess);

        initViews();
        db = new DBHelper(this);
        //Change the sp file and clear stack
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                SharedPreferences sp = getSharedPreferences(StringConstants.PCOUNT_PREF, Activity.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putInt(StringConstants.PASSENGER_COUNT, 0);
                editor.commit();
                db.deleteTable();
                final Intent intent = new Intent(PaymentSuccessActivity.this, BusActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PaymentSuccessActivity.this.startActivity(intent);
                PaymentSuccessActivity.this.finish();

            }
        };
        //change data in sp file,delete table and clear stack
        //if button is clicked remove automatic postdelay handler
        btAnotherPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handler.removeCallbacks(runnable);
                SharedPreferences sp = getSharedPreferences(StringConstants.PCOUNT_PREF, Activity.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putInt(StringConstants.PASSENGER_COUNT, 0);
                editor.commit();
                db.deleteTable();
                Intent intent = new Intent(PaymentSuccessActivity.this, BusActivity.class);
                //clear activities from stack
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
        //Allow user going in same bus to chat with customer care
        btContactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //disable auto postdelay handler
                handler.removeCallbacks(runnable);
                Toast.makeText(PaymentSuccessActivity.this,StringConstants.ENTER_ROOM_NAME_CODERED, Toast.LENGTH_LONG).show();
                Intent intent = new Intent(PaymentSuccessActivity.this,
                        StandardWebView.class);
                startActivity(intent);
            }
        });

        //automatic transfer to new activity after few seconds
        {
            handler.postDelayed(runnable, 5000);
        }
    }

    //init views for passenger success activity
    private void initViews() {
        btAnotherPayment = findViewById(R.id.bt_book_another_ticket);
        btContactUs = findViewById(R.id.contactus);
    }

    @Override
    public void onBackPressed() {
        //alert box for exit
        new AlertDialog.Builder(this)
                .setTitle(StringConstants.REALLY_EXIT)
                .setMessage(StringConstants.ARE_YOU_SURE_YOU_WANT_TO_EXIT)
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        SharedPreferences sp = getSharedPreferences(StringConstants.PCOUNT_PREF, Activity.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putInt(StringConstants.PASSENGER_COUNT, 0);
                        editor.commit();
                        db.deleteTable();
                        PaymentSuccessActivity.super.onBackPressed();
                        finishAffinity();
                    }
                }).create().show();
    }
}
