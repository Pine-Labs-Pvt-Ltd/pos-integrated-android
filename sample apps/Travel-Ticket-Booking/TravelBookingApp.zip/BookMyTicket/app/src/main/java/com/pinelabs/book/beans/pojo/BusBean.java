package com.pinelabs.book.beans.pojo;


import java.io.Serializable;

public class BusBean implements Serializable {

    private int busNumber;
    private String txtBusName;
    private String txtStationArrived;
    private String txtStationDestination;
    private String txtTimeArrived;
    private String txtDateArrived;
    private String txtTimeDeparture;
    private String txtJourneyTime;
    private String btnBuy;

    /*
            by set method we set data to this model from database
            by get method we get data from this model to set in holder
     */
    public int getBusNumber(){return busNumber;}
    public void setBusNumber(int busNumber){this.busNumber=busNumber;}

    public String getTxtTimeArrived() {
        return txtTimeArrived;
    }

    public void setTxtTimeArrived(String txtTimeArrived) {
        this.txtTimeArrived = txtTimeArrived;
    }

    public String getTxtDateArrived() {
        return txtDateArrived;
    }

    public void setTxtDateArrived(String txtDateArrived) {
        this.txtDateArrived = txtDateArrived;
    }

    public String getTxtTimeDeparture() {
        return txtTimeDeparture;
    }

    public void setTxtTimeDeparture(String txtTimeDeparture) {
        this.txtTimeDeparture = txtTimeDeparture;
    }

    public String getTxtJourneyTime() {
        return txtJourneyTime;
    }

    public void setTxtJourneyTime(String txtJourneyTime) {
        this.txtJourneyTime = txtJourneyTime;
    }


    public String getTxtBusName() {
        return txtBusName;
    }

    public void setTxtBusName(String txtBusName) {
        this.txtBusName = txtBusName;
    }


    public String getTxtStationArrived() {
        return txtStationArrived;
    }

    public void setTxtStationArrived(String txtStationArrived) {
        this.txtStationArrived = txtStationArrived;
    }


    public String getTxtStationDestination() {
        return txtStationDestination;
    }

    public void setTxtStationDestination(String txtStationDestination) {
        this.txtStationDestination = txtStationDestination;
    }

    public String getBtnBuy() {
        return btnBuy;
    }

    public void setBtnBuy(String btnBuy) {
        this.btnBuy = btnBuy;
    }

}
