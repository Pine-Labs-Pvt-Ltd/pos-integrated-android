package com.pinelabs.book.beans.pojo;


public class PassengerHistoryBean {

    private String busNameHistory;
    private String stationArrivedHistory;
    private String stationDestinationHistory;
    private String dateArrivedHistory;
    private int bookedCanceled;
    private int bookingId;
    /*
            by set method we set data to this model from database
            by get method we get data from this model to set in holder
     */

    public int getBookingId(){return bookingId;}
    public void setBookingId(int bookingId)
    {
        this.bookingId =bookingId;
    }
    public int getBookedCanceled(){return bookedCanceled;}
    public void setBookedCanceled(int bookedCanceled)
    {
        this.bookedCanceled=bookedCanceled;
    }
    public String getDateArrivedHistory() {
        return dateArrivedHistory;
    }

    public void setDateArrivedHistory(String dateArrivedHistory) {
        this.dateArrivedHistory = dateArrivedHistory;
    }

    public String getBusNameHistory() {
        return busNameHistory;
    }

    public void setBusNameHistory(String busNameHistory) {
        this.busNameHistory = busNameHistory;
    }

    public String getStationArrivedHistory() {
        return stationArrivedHistory;
    }

    public void setStationArrivedHistory(String stationArrivedHistory) {
        this.stationArrivedHistory = stationArrivedHistory;
    }

    public String getStationDestinationHistory() {
        return stationDestinationHistory;
    }

    public void setStationDestinationHistory(String stationDestinationHistory) {
        this.stationDestinationHistory = stationDestinationHistory;
    }

}
