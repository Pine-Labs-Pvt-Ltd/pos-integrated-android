package com.pinelabs.book.activities;


import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.pinelabs.book.R;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;
import com.pinelabs.book.utility.AESUtils;

import java.util.regex.Pattern;

public class SignupActivity extends AppCompatActivity {


    TextView tvSignIn, tvSignInBack;
    DBHelper db;
    EditText etRegisterUser, etRegisterEmail, etRegisterPassword, etConfirmPassword;
    AESUtils aesUtils;
    //Password validation pattern
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initViews();

        db = new DBHelper(this);

    }

    //init views for signup
    private void initViews() {
        tvSignIn = findViewById(R.id.tv_signin);
        etRegisterUser = findViewById(R.id.et_register_user);
        etRegisterEmail = findViewById(R.id.et_register_email);
        etRegisterPassword = findViewById(R.id.et_register_password);
        tvSignInBack = findViewById(R.id.tv_signin_back);
        etConfirmPassword = findViewById(R.id.et_confirm_password);


        tvSignInBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //encrypt password with AES
                aesUtils=new AESUtils();
                String encrypted="";
                String user = etRegisterUser.getText().toString().trim();
                String email = etRegisterEmail.getText().toString().trim();
                String password = etRegisterPassword.getText().toString().trim();
                try {
                    encrypted = AESUtils.encrypt(password);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //register user and fill database with user information
                if (!password.equals(etConfirmPassword.getText().toString().trim()))
                    Toast.makeText(SignupActivity.this,StringConstants.PASSWORD_DON_T_MATCH, Toast.LENGTH_SHORT).show();
                else if (confirmInputSignUp()) {
                     db.addUser(user, email, encrypted);
                    Toast.makeText(SignupActivity.this,getString(R.string.YOU_HAVE_REGISTERED), Toast.LENGTH_SHORT).show();
                    Intent it = new Intent(SignupActivity.this, LoginActivity.class);
                    startActivity(it);
                }
            }
        });
    }

    //validation Email
    private boolean validateEmail() {
        String emailInput = etRegisterEmail.getText().toString().trim();

        if (emailInput.isEmpty()) {
            etRegisterEmail.setError(getString(R.string.FIELD_CAN_T_BE_EMPTY));
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            etRegisterEmail.setError(getString(R.string.PLEASE_ENTER_A_VALID_EMAIL_ADDRESS));
            return false;
        } else {
            etRegisterEmail.setError(null);
            return true;
        }
    }

    //validation Username
    private boolean validateUsername() {
        String usernameInput = etRegisterUser.getText().toString().trim();

        if (usernameInput.isEmpty()) {
            etRegisterUser.setError(getString(R.string.USERNAME_CANT_BE_EMPTY));
            return false;
        } else if (usernameInput.length() > 15) {
            etRegisterUser.setError(getString(R.string.USERNAME_TOO_LONG));
            return false;
        } else {
            etRegisterUser.setError(null);
            return true;
        }
    }

    //validation Signup Password
    private boolean validatePassword() {
        String passwordInput = etRegisterPassword.getText().toString().trim();

        if (passwordInput.isEmpty()) {
            etRegisterPassword.setError(getString(R.string.PASSWORD_CANT_BE_EMPTY));
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            etRegisterPassword.setError(getString(R.string.PASSWORD_MUST_CONTAIN_ALPHABET_AND_A_SPECIALCHARACTER));
            return false;
        } else {
            etRegisterPassword.setError(null);
            return true;
        }
    }

    //Validation email name and password
    public boolean confirmInputSignUp() {
        if (!validateEmail() | !validateUsername() | !validatePassword())
            return false;
        return true;
    }
}