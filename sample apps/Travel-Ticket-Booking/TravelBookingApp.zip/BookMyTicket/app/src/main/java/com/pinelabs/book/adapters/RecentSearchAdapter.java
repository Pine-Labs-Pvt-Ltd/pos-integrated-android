package com.pinelabs.book.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.beans.pojo.RecentSearchBean;

import java.util.List;


public class RecentSearchAdapter extends RecyclerView.Adapter<RecentSearchAdapter.MyViewHolder> {

    private Callback callback;
    private List<RecentSearchBean> recentSearchBeanList;
    private Context mContext;

    public List<RecentSearchBean> getList() {
        return recentSearchBeanList;
    }

    //for callback of adapter position to BusListActivity
    public interface Callback {
        void onClickItem(RecentSearchBean recentSearchBean);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvRecentFrom, tvRecentTo, tvRecentDate, tvBookNow;

        //Initialize view
        public MyViewHolder(View view) {
            super(view);

            tvRecentFrom=itemView.findViewById(R.id.tv_recentfrom);
            tvRecentTo=itemView.findViewById(R.id.tv_recentto);
            tvRecentDate=itemView.findViewById(R.id.tv_recentdate);
            tvBookNow=itemView.findViewById(R.id.tv_booknow);
            tvBookNow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (callback != null)
                        callback.onClickItem(recentSearchBeanList.get(getAdapterPosition()));
                }
            });
        }
    }

    //constructor for callback
    public RecentSearchAdapter(Context mContext, Callback callback, List<RecentSearchBean> recentSearchBeanList) {
        this.recentSearchBeanList = recentSearchBeanList;
        this.callback = callback;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recentsearch, parent, false);
        return new MyViewHolder(itemView);
    }

    //set data on view holder
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
        RecentSearchBean recentSearchBean = recentSearchBeanList.get(position);
        holder.tvRecentFrom.setText(recentSearchBean.getRecentSource());
        holder.tvRecentTo.setText(recentSearchBean.getRecentDestination());
        holder.tvRecentDate.setText(recentSearchBean.getRecentDate());
    }

    //get list count
    @Override
    public int getItemCount() {
        return recentSearchBeanList.size();
    }

}