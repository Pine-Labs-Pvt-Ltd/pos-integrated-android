package com.pinelabs.book.beans.pojo;

import java.io.Serializable;
import java.util.ArrayList;
/*Booking bean for collecting data and sending it to PineServiceHelper for
    getting seat information that can be stored in database
 */
public class Booking implements Serializable {
    private int busNumber;
    private ArrayList<String> seatList;


    public ArrayList<String> getSeatList() {
        return seatList;
    }

    public int getBusNumber() {
        return busNumber;
    }

    public void setSeatList(int busNumber, ArrayList<String> seatList) {
        this.busNumber = busNumber;
        this.seatList = seatList;
    }

}
