package com.pinelabs.book.beans.request;

import com.google.gson.annotations.SerializedName;
import com.pinelabs.book.beans.pojo.HeaderBean;
import com.pinelabs.book.utility.GsonUtils;

public class HeaderRequest<T> {

    @SerializedName("Header")
    private HeaderBean HeaderBean;
    @SerializedName("Detail")
    private T Detail;

    public HeaderRequest(String methodId) {
        this.HeaderBean = new HeaderBean("5116d9535f4f42ef97adaa0c12c61184", methodId, "userId", "1.0");
    }

    public HeaderBean getHeaderBean() {
        return HeaderBean;
    }

    public void setHeaderBean(HeaderBean headerBean) {
        HeaderBean = headerBean;
    }

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    @Override
    public String toString() {
        return GsonUtils.fromJsonToString(this);
    }
}
