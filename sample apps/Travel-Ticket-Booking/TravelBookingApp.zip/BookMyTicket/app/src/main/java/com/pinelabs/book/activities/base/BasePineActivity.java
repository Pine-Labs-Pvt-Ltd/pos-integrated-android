package com.pinelabs.book.activities.base;

import android.content.Intent;

import com.pinelabs.book.R;
import com.pinelabs.book.activities.PaymentSuccessActivity;
import com.pinelabs.book.beans.response.DetailResponse;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.PineServiceHelper;
import com.pinelabs.book.helper.StringConstants;
import com.pinelabs.book.utility.UIUtils;

import java.util.ArrayList;

import static com.pinelabs.book.helper.PineServiceHelper.getInstance;

/**
 * Created by Pinelabs Pvt Ltd on 2/5/2019.
 * <p>
 * This activity use to implement Bound service callbacks
 */
public abstract class BasePineActivity extends BaseActivity implements PineServiceHelper.PineCallBack {

    @Override
    protected void onRestart() {
        super.onRestart();
        getInstance().connect(this);
    }

    @Override
    public void showToast(String msg) {
        UIUtils.dismissProgressbar();
        UIUtils.makeToast(this, msg);
    }

    @Override
    public void connectAgain() {
        UIUtils.dismissProgressbar();
        getInstance().connect(this);
    }

    @Override
    public void sendResult(DetailResponse detailResponse) {
        UIUtils.dismissProgressbar();
        if (detailResponse != null) {
            if (detailResponse.getResponse().isSuccess()) {
                UIUtils.makeToast(this, getString(R.string.PAYMENT_SUCCESS));
                getInstance().getBooking();
                //save this booking
                DBHelper dbHelper = new DBHelper(this);
                ArrayList<String> arrayList = getInstance().getBooking().getSeatList();
                int busNumber = getInstance().getBooking().getBusNumber();
                 {
                    for (int i = 0; i < arrayList.size(); i++) {
                        dbHelper.setSeat(busNumber, arrayList.get(i));
                    }
                }
                Intent intent = new Intent(this, PaymentSuccessActivity.class);
                startActivity(intent);
            } else {
                UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
            }
        } else {
            UIUtils.makeToast(this, StringConstants.ERROR);
        }
    }
    @Override
    public void showWaitingDialog() {
        UIUtils.showDialog(this, getString(R.string.please_Wait));
    }

}
