package com.pinelabs.book.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pinelabs.book.R;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;

import java.util.regex.Pattern;

public class AddPassengerDetailsActivity extends AppCompatActivity {

    TextView tvAddPassengerDetails, tvAddPassengerBack;
    EditText etPassengerName, etPassengerAge;
    CheckBox cbGenderMale, cbGenderFemale;
    DBHelper db;
    private static final Pattern AGE_PATTERN = Pattern.compile("[0-9][0-9]*"), NAME_PATTERN = Pattern.compile("^[a-zA-Z ]+$");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpassengerdetails);
        initViews();
        cbGender();
        setData();
    }

    //automatic uncheck one checkbox if other is clicked
    private void cbGender() {

        cbGenderMale.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    cbGenderFemale.setChecked(false);
                }
            }
        });

        cbGenderFemale.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    cbGenderMale.setChecked(false);
                }
            }
        });
    }

    private void setData() {
        //validation and add data to database
        tvAddPassengerDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db = new DBHelper(AddPassengerDetailsActivity.this);
                if (!cbGenderFemale.isChecked() && !cbGenderMale.isChecked())
                    Toast.makeText(AddPassengerDetailsActivity.this, getString(R.string.PLEASE_SELECT_GENDER), Toast.LENGTH_SHORT).show();
                else if (confirmAddPassenger()) {
                    db.InsertPassengerRecords(etPassengerName.getText().toString(), Integer.parseInt(etPassengerAge.getText().toString()), cbGenderFemale.isChecked() ? "FEMALE" : "MALE");
                    Intent intent = new Intent(AddPassengerDetailsActivity.this, AddPassengerActivity.class);
                    intent.putExtras(getIntent());
                    startActivity(intent);
                    finish();
                }
            }
        });

        tvAddPassengerBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    //initiate views for add passenger details
    private void initViews() {
        etPassengerName = findViewById(R.id.et_passengername);
        etPassengerAge = findViewById(R.id.et_passengerage);
        cbGenderMale = findViewById(R.id.cb_gendermale);
        cbGenderFemale = findViewById(R.id.cb_genderfemale);
        tvAddPassengerDetails = findViewById(R.id.tv_addpassengerdetails);
        tvAddPassengerBack = findViewById(R.id.tv_addpassengerback);

    }

    //validation passengerName
    private boolean validatePassengerName() {
        String passengerName = etPassengerName.getText().toString().trim();

        if (passengerName.isEmpty()) {
            etPassengerName.setError(getString(R.string.FIELD_CAN_T_BE_EMPTY));
            return false;
        } else if (passengerName.length() > 15) {
            etPassengerName.setError(getString(R.string.USERNAME_TOO_LONG));
            return false;
        } else if (!NAME_PATTERN.matcher(passengerName).matches()) {
            etPassengerAge.setError(StringConstants.ENTER_TEXT);
            return false;
        } else {
            etPassengerName.setError(null);
            return true;
        }
    }

    //validate age
    private boolean validateAge() {
        String age = etPassengerAge.getText().toString().trim();

        if (age.isEmpty()) {
            etPassengerAge.setError(getString(R.string.FIELD_CAN_T_BE_EMPTY));
            return false;
        } else if (!AGE_PATTERN.matcher(age).matches()) {
            etPassengerAge.setError(StringConstants.AGE_IS_JUST_A_NUMBER);
            return false;
        } else {
            etPassengerAge.setError(null);
            return true;
        }
    }

    public boolean confirmAddPassenger() {
        if (!validatePassengerName() | !validateAge())
            return false;
        return true;
    }

    @Override
    public void onBackPressed() {
        //if user clicks back button it decrease value in file ,to assume user never entered
        SharedPreferences sp = getSharedPreferences(StringConstants.PCOUNT_PREF, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        int myIntValue = sp.getInt(StringConstants.PASSENGER_COUNT, 0);
        editor.putInt(StringConstants.PASSENGER_COUNT1, myIntValue - 1);
        editor.commit();
        finish();
    }
}
