package com.pinelabs.book.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pinelabs.book.R;
import com.pinelabs.book.beans.pojo.BusBean;

import java.util.List;


public class BusListAdapter extends RecyclerView.Adapter<BusListAdapter.MyViewHolder> {

    private Callback callback;
    private List<BusBean> busBeanList;
    private Context mContext;

    //Notify data change to adapter when sort function is executed
    public void setList(List<BusBean> list) {
        this.busBeanList = list;
        notifyDataSetChanged();
    }

    public List<BusBean> getList() {
        return busBeanList;
    }

    //for callback of adapter position to BusListActivity
    public interface Callback {
        void onClickItem(BusBean busBean);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvBusName, tvStationSource, tvStationDestination, tvPrice, tvArrivalTime, tvArrivalDate, tvJourneyDuration, tvDepartureTime;
        LinearLayout linear;

        //Initialize view
        public MyViewHolder(View view) {
            super(view);

            linear = itemView.findViewById(R.id.linear);
            tvBusName = itemView.findViewById(R.id.txtBusName);
            tvStationSource = itemView.findViewById(R.id.txtStationArrived);
            tvStationDestination = itemView.findViewById(R.id.txtStationDestination);
            tvPrice = itemView.findViewById(R.id.btnBuy);
            tvArrivalTime = itemView.findViewById(R.id.txtTimeArrived);
            tvArrivalDate = itemView.findViewById(R.id.txtDateArrived);
            tvDepartureTime = itemView.findViewById(R.id.txtTimeDestination);
            tvJourneyDuration = itemView.findViewById(R.id.txtTravelTime);

            tvPrice.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (callback != null)
                        callback.onClickItem(busBeanList.get(getAdapterPosition()));
                }
            });
        }
    }

    //constructor for callback
    public BusListAdapter(Context mContext, Callback callback, List<BusBean> busBeanList) {
        this.busBeanList = busBeanList;
        this.callback = callback;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bus, parent, false);
        return new MyViewHolder(itemView);
    }

    //set data on view holder
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
        BusBean busBean = busBeanList.get(position);
        holder.tvBusName.setText(busBean.getTxtBusName());
        holder.tvStationSource.setText(busBean.getTxtStationArrived());
        holder.tvStationDestination.setText(busBean.getTxtStationDestination());
        holder.tvPrice.setText("Rs " + busBean.getBtnBuy());
        holder.tvArrivalTime.setText(busBean.getTxtTimeArrived());
        holder.tvDepartureTime.setText(busBean.getTxtTimeDeparture());
        holder.tvArrivalDate.setText(busBean.getTxtDateArrived());
        holder.tvJourneyDuration.setText(busBean.getTxtJourneyTime());
    }

    //get list count
    @Override
    public int getItemCount() {
        return busBeanList.size();
    }

}


