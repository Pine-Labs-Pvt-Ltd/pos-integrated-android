package com.pinelabs.book.utility;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;


/*
 * Created by Pinelabs Pvt Ltd on 9/1/2017.
 */

public class UIUtils {

    private static Toast mToast;
    private static Snackbar snackbar;
    private static ProgressDialog dialog;


    public static void makeToast(Context context, String msg) {
        try {
            if (mToast != null) {
                mToast.cancel();
            }

            if (msg != null && msg.length() > 0) {
                mToast = Toast.makeText(context, msg, Toast.LENGTH_SHORT);
                mToast.show();
            }
        } catch (Exception e) {
            Log.e("toast", "" + e.getMessage());
        }
    }


    public static void makeToastLong(Context context, String msg) {
        try {
            if (mToast != null) {
                mToast.cancel();
            }

            if (msg != null && msg.length() > 0) {
                mToast = Toast.makeText(context, msg, Toast.LENGTH_LONG);
                mToast.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * SnackBar for indefinite time
     */


    /**
     * SnackBar without Action
     */
    public static void showSnackBar(View rootLayout, Context context, String msg) {
        if (context == null || rootLayout == null) return;
        try {
            dismissSnackBar();
            closeVirtualKeyBoard(context);

            snackbar = Snackbar.make(rootLayout, msg, Snackbar.LENGTH_LONG);

            View snackBarView = snackbar.getView();


            // Changing message text color
            snackbar.setAction("Dismiss", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dismissSnackBar();
                }
            });
            snackbar.setActionTextColor(Color.RED);
            snackbar.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void dismissSnackBar() {
        if (snackbar != null) {
            snackbar.dismiss();
        }
    }

    /**
     * Show snackBar with Action.
     */


    /**
     * close Keyboard from Activity
     */
    public static void closeVirtualKeyBoard(Context context) {
        Activity activity;
        if (context instanceof Activity) {
            activity = ((Activity) context);

            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            try {
                imm.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
            } catch (Exception e) {
            }
            //if (imm != null && imm.isActive() && imm.isAcceptingText() && activity.getCurrentFocus() != null)

        }
    }



    public static void showDialog(Context context, String msg) {
        try {
            dialog = new ProgressDialog(context);
            dialog.setCancelable(false);
            dialog.setMessage(msg);
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void dismissProgressbar() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
            dialog = null;
        }
    }
}
