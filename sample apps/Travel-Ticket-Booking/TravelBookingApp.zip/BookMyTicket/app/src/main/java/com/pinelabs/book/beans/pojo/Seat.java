package com.pinelabs.book.beans.pojo;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import androidx.appcompat.widget.AppCompatButton;

import com.pinelabs.book.R;

import static com.pinelabs.book.helper.StringConstants.SEAT;
import static com.pinelabs.book.helper.StringConstants.SET_BACKGROUND_ISBOOKED;
import static com.pinelabs.book.helper.StringConstants.SET_BACKGROUND_STATUS_WAS_FALSE;
import static com.pinelabs.book.helper.StringConstants.SET_BACKGROUND_STATUS_WAS_TRUE;
import static com.pinelabs.book.helper.StringConstants.SET_THIS_CHAIR_TO_BOOKED;


public class Seat extends AppCompatButton {

    private String seatID;
    private int rowNum;
    private int colNum;
    private boolean isSelected;
    private boolean isBooked = false;
    private final double price = 1;

    private static final String TAG = SEAT;


    public Seat(Context context) {
        super(context);
    }

    public Seat(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public Seat(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public Seat(Context context, int row, int col) {
        super(context);
        this.rowNum = row;
        this.colNum = col;
        this.seatID = Integer.toString(this.rowNum) + "," + Integer.toString(this.colNum);
    }

    public int getRowNum() {
        return rowNum;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    public int getColNum() {
        return colNum;
    }

    public void setColNum(int colNum) {
        this.colNum = colNum;
    }

    public boolean setBackground() {

        if (this.isBooked) {
            Log.d(TAG, SET_BACKGROUND_ISBOOKED + isBooked + SET_THIS_CHAIR_TO_BOOKED);
            this.setBackgroundResource(R.drawable.seat_sold);
            return false;
        }

        if (this.isSelected) {
            Log.d(TAG, SET_BACKGROUND_STATUS_WAS_TRUE);
            this.setBackgroundResource(R.drawable.seat_selected);
            this.isSelected = false;
            return true;
        } else {
            Log.d(TAG, SET_BACKGROUND_STATUS_WAS_FALSE);

            this.setBackgroundResource(R.drawable.seat_sale);
            this.isSelected = true;
            return true;
        }
    }

    public void setStatus(boolean status) {
        this.isSelected = status;
    }

    public boolean getStatus() {
        return isSelected;
    }

    public double getPrice() {
        return price;
    }

    public String getSeatID() {
        return this.seatID;
    }

    public void setIsBooked() {
        this.isBooked = true;
    }

    public boolean IsBooked() {
        return this.isBooked;
    }


}
