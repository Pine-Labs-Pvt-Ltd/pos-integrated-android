package com.pinelabs.book.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.pinelabs.book.R;
import com.pinelabs.book.beans.pojo.Booking;
import com.pinelabs.book.beans.pojo.BusBean;
import com.pinelabs.book.beans.pojo.Room;
import com.pinelabs.book.beans.pojo.Seat;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;

import java.util.ArrayList;

public class SeatSelectionActivity extends AppCompatActivity {

    private static final int ROW = 7;
    private static final int COL = 4;
    private ArrayList<Seat> seats;
    private ArrayList<String> seatIds;//seatIds[0]=2,0 if 3rd row and 1 column
    private Room room;
    private static final String TAG = StringConstants.SEAT_SELECTION_ACTIVITY;
    String PassengerCount;
    int busNumber;
    BusBean busBean;
    DBHelper dbHelper;
    Booking booking;
    ImageView ivBack;
    TextView tvBusNameSeat, tvBusFromSeat, tvBusToSeat,tvBusDate,tvBusTime;

    //on click button set seat selected to bean file and move to next activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_selection);
        initViews();
        //back arrow
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        //get data from Intent
        PassengerCount = getIntent().getStringExtra(StringConstants.SPINNER_PASSENGER_BUS);
        busBean = (BusBean) getIntent().getSerializableExtra(StringConstants.BUS_DATA);
        tvBusNameSeat.setText(busBean.getTxtBusName());
        tvBusFromSeat.setText(busBean.getTxtStationArrived());
        tvBusToSeat.setText(busBean.getTxtStationDestination());
        tvBusDate.setText(busBean.getTxtDateArrived());
        tvBusTime.setText(busBean.getTxtTimeArrived());
        //create table layout for seat
        createTable();
        seatIds = new ArrayList<>();
        dbHelper = new DBHelper(this);
        //reserve seat button
        final Button button = findViewById(R.id.reserveButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seats = room.getSeats();
                seatIds.clear();
                busNumber = busBean.getBusNumber();
                Log.d(TAG, StringConstants.SEAT_SIZE + seats.size());
                for (int i = 0; i < seats.size(); i++) {
                    seatIds.add(seats.get(i).getSeatID());
                    Log.d(TAG, StringConstants.SEATS_IDS_ADDED + seatIds.get(i));
                }

                if (seats.size() == 0) {
                    Toast.makeText(getApplicationContext(), getString(R.string.NO_SEAT_SELECTED), Toast.LENGTH_SHORT).show();
                } else if (seats.size() != Integer.parseInt(PassengerCount)) {
                    Toast.makeText(SeatSelectionActivity.this,getString(R.string.PLEASE_SELECT_SEAT_A_PASSENGER_COUNT), Toast.LENGTH_SHORT).show();
                } else {
                    //put busNumber and List of Seat ID's in Bean to move data to page where we get payment callback
                    booking = new Booking();
                    booking.setSeatList(busNumber, seatIds);
                    Intent itemDetailIntent = new Intent(SeatSelectionActivity.this, AddPassengerActivity.class);
                    itemDetailIntent.putStringArrayListExtra(StringConstants.SEAT_ID_LIST, seatIds);
                    itemDetailIntent.putExtra(StringConstants.SEATDATA, booking);
                    itemDetailIntent.putExtra(StringConstants.TOTAL_PRICE, Double.toString(room.calculate(seats)));
                    itemDetailIntent.putExtras(getIntent());
                    startActivity(itemDetailIntent);
                }
            }
        });
    }

    private void initViews() {
        ivBack = findViewById(R.id.iv_back);
        tvBusNameSeat = findViewById(R.id.tv_busnameseat);
        tvBusFromSeat = findViewById(R.id.tv_busfromseat);
        tvBusToSeat = findViewById(R.id.tv_bustoseat);
        tvBusDate=findViewById(R.id.tv_busdate);
        tvBusTime=findViewById(R.id.tv_bustime);
    }

    //create table for seat selection
    private void createTable() {
        dbHelper = new DBHelper(this);
        TableLayout tableLayout = findViewById(R.id.TableSeats);
        final TextView titleTextView = findViewById(R.id.textView);
        ArrayList<String> seatList;
        busBean = (BusBean) getIntent().getSerializableExtra(StringConstants.BUS_DATA);
        seatList = dbHelper.getSeatList(busBean.getBusNumber());
        //populate view
        room = new Room(this, tableLayout, titleTextView, ROW, COL, seatList);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
