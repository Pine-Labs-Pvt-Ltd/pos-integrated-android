package com.pinelabs.book.beans.pojo;

public class RecentSearchBean {

    private String recentSource;
    private String recentDestination;
    private String recentDate;


    public String getRecentSource() {
        return recentSource;
    }

    public void setRecentSource(String recentSource) {
        this.recentSource = recentSource;
    }

    public String getRecentDestination() {
        return recentDestination;
    }

    public void setRecentDestination(String recentDestination) {
        this.recentDestination = recentDestination;
    }

    public String getRecentDate() {
        return recentDate;
    }

    public void setRecentDate(String recentDate) {
        this.recentDate = recentDate;
    }
}
