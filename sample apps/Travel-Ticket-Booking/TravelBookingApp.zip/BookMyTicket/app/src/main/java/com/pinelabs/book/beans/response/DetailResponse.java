package com.pinelabs.book.beans.response;


import com.google.gson.annotations.SerializedName;
import com.pinelabs.book.beans.pojo.HeaderBean;

public class DetailResponse<T>{

    @SerializedName("Detail")
    private T Detail;

    @SerializedName("HeaderBean")
    private HeaderBean HeaderBean;

    @SerializedName("Response")
    private Response Response;

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    public HeaderBean getHeaderBean() {
        return HeaderBean;
    }

    public void setHeaderBean(HeaderBean headerBean) {
        HeaderBean = headerBean;
    }

    public com.pinelabs.book.beans.response.Response getResponse() {
        return Response;
    }

    public void setResponse(com.pinelabs.book.beans.response.Response response) {
        Response = response;
    }
}
