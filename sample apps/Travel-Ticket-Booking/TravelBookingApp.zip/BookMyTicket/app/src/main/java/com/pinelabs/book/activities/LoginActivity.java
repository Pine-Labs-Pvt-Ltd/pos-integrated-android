package com.pinelabs.book.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.pinelabs.book.R;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.helper.StringConstants;
import com.pinelabs.book.utility.AESUtils;


public class LoginActivity extends AppCompatActivity {
    DBHelper db;
    SignInButton signInButton;
    GoogleSignInClient mGoogleSignInClient;
    TextView tvCreate, tvLogin;
    int RC_SIGN_IN = 0;
    EditText etUsername, etPassword;
    AESUtils aesUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initViews();
        db = new DBHelper(this);

        // Configure sign-in to request the user's ID, email address, and basic
        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.

        signInButton = findViewById(R.id.sign_in_button);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.sign_in_button:
                        signIn();
                        break;
                    // ...
                }
            }
        });


    }

    private void initViews() {
        tvLogin = findViewById(R.id.login);
        tvCreate = findViewById(R.id.create);
        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);
        aesUtils=new AESUtils();
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String encrypted="";
                String user = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                //Encrypt password using AES
                try {
                    encrypted = AESUtils.encrypt(password);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //check username and password in database and also check username validation and password strength
                boolean res = db.checkUser(user, encrypted);
                if (res && confirmInput()) {
                    Intent it = new Intent(LoginActivity.this, BusActivity.class);
                    startActivity(it);
                } else
                    Toast.makeText(LoginActivity.this, getString(R.string.INVALID_USER), Toast.LENGTH_SHORT).show();
            }
        });
        //Move to SignUp Page
        tvCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(it);

            }
        });

    }

    //Google SignIn
    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.
            Intent intent = new Intent(LoginActivity.this, BusActivity.class);
            startActivity(intent);
            finish();
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(StringConstants.ERROR,StringConstants.SIGN_IN_RESULT_FAILED_CODE + e.getStatusCode());
        }
    }

    private boolean validateUsername() {
        String usernameInput = etUsername.getText().toString().trim();
        //check username
        if (usernameInput.isEmpty()) {
            etUsername.setError(getString(R.string.USERNAME_CANT_BE_EMPTY));
            return false;
        } else if (usernameInput.length() > 15) {
            etUsername.setError(getString(R.string.USERNAME_TOO_LONG));
            return false;
        } else {
            etUsername.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = etPassword.getText().toString().trim();
        //check password strength
        if (passwordInput.isEmpty()) {
            etPassword.setError(getString(R.string.PASSWORD_CANT_BE_EMPTY));
            return false;
        } else {
            etPassword.setError(null);
            return true;
        }
    }
    //confirm username and password field are valid inputs
    public boolean confirmInput() {
        if (!validateUsername() | !validatePassword()) {
            return false;
        }
        return true;
    }
}
