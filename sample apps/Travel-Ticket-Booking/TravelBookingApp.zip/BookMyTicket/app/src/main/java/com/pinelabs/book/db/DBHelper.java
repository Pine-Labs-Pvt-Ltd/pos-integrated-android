package com.pinelabs.book.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.pinelabs.book.beans.pojo.BusBean;
import com.pinelabs.book.beans.pojo.PassengerBean;
import com.pinelabs.book.beans.pojo.PassengerHistoryBean;
import com.pinelabs.book.beans.pojo.RecentSearchBean;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String dbName = "busdb";
    private static final int version = 1;


    public DBHelper(Context context) {
        super(context, dbName, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE REGISTER_USER(username TEXT PRIMARY KEY,email TEXT,password TEXT)");
        String sql = "CREATE TABLE BUS_INFO (_id INTEGER PRIMARY KEY AUTOINCREMENT,BUS_NO INTEGER UNIQUE,BUS_NAME TEXT,SOURCE TEXT,DESTINATION TEXT,DOJ TEXT,ARRIVAL TEXT,DEPARTURE TEXT,DURATION TEXT,PRICE REAL)";
        sqLiteDatabase.execSQL(sql);

        String sql_addPassenger = "CREATE TABLE PASSENGER_INFO(ID INTEGER PRIMARY KEY AUTOINCREMENT,PASSENGER_NAME TEXT,AGE TEXT,GENDER TEXT)";
        sqLiteDatabase.execSQL(sql_addPassenger);

        String sql_seat = "CREATE TABLE SEAT_INFO(ID INTEGER PRIMARY KEY,BUSNUMBER INTEGER,SEATMAP TEXT)";
        sqLiteDatabase.execSQL(sql_seat);

        String sql_passengerHistory = "CREATE TABLE BOOKING_HISTORY(ID INTEGER PRIMARY KEY AUTOINCREMENT,BUS_NAME TEXT,SOURCE TEXT,DESTINATION TEXT,JOURNEYDATE TEXT,BOOKCANCEL INTEGER)";
        sqLiteDatabase.execSQL(sql_passengerHistory);

        String sql_recentSearch="CREATE TABLE RECENT_SEARCH(ID INTEGER PRIMARY KEY AUTOINCREMENT,SOURCE TEXT,DESTINATION TEXT,DATE TEXT)";
        sqLiteDatabase.execSQL(sql_recentSearch);
        //insert data into bus info table
        insertData(60774, "NORTHERN TRAVELS", "DELHI", "LUCKNOW", "MON", "08:50", "19:00", "10h10m", 2034.45, sqLiteDatabase);
        insertData(60773, "AKASH TRAVELS", "DELHI", "LUCKNOW", "TUE", "22:45", "05:20", "06h35m", 1425.50, sqLiteDatabase);
        insertData(60775, "S R TRADERS", "DELHI", "LUCKNOW", "MON", "16:25", "23:30", "07h05m", 1550.20, sqLiteDatabase);
        insertData(60771, "GARIB RATH", "DELHI", "LUCKNOW", "WED", "22:00", "08:00", "10h00m", 800.10, sqLiteDatabase);
        insertData(60778, "DHRUV TRAVELS", "DELHI", "LUCKNOW", "THU", "23:30", "06:30", "07h00m", 1299.20, sqLiteDatabase);
        insertData(60798, "UPSRTC", "DELHI", "LUCKNOW", "FRI", "19:01", "07:00", "11h59m", 808.40, sqLiteDatabase);
        insertData(59061, "MAHALAXMI TRAVELS", "DELHI", "MORADABD", "SAT", "02:15", "05:45", "03h30m", 700.30, sqLiteDatabase);
        insertData(59067, "UPSRTC", "DELHI", "MORADABD", "SUN", "08:00", "11:29", "03h29m", 393.30, sqLiteDatabase);
        insertData(143746, "UPSRTC", "DELHI", "MORADABD", "TUE", "21:30", "01:30", "04h00m", 290.60, sqLiteDatabase);
        insertData(53349, "JAN RATH", "HARIDWAR", "DELHI", "WED", "08:10", "13:15", "05h05m", 355.20, sqLiteDatabase);
        insertData(142939, "PINK EXPRESS", "HARIDWAR", "DELHI", "MON", "18:05", "23:00", "04h55m", 375.30, sqLiteDatabase);
        insertData(12347, "BSRTC", "DELHI", "PATNA", "TUE", "13:00", "09:00", "20h00m", 1650.40, sqLiteDatabase);
        insertData(12346, "BSRTC", "DELHI", "PATNA", "FRI", "16:30", "12:30", "20h00m", 1900.50, sqLiteDatabase);
        insertData(12348, "TRAVEL POINT", "DELHI", "PATNA", "SAT", "15:30", "07:45", "16h15m", 1664.50, sqLiteDatabase);
        insertData(12345, "BENGAL TIGER", "DELHI", "PATNA", "SUN", "12:30", "11:30", "23h00m", 1400.70, sqLiteDatabase);
        insertData(12344, "HOLIDAY APPEAL", "CHANDIGARH", "MANALI", "MON", "00:40", "10:00", "09h20m", 1249.00, sqLiteDatabase);
        insertData(1506, "HRTC", "CHANDIGARH", "MANALI", "THU", "08:30", "18:30", "10h00m", 1125.10, sqLiteDatabase);
        insertData(12343, "MAHALAXMI TRAVELS", "DELHI", "JAIPUR", "SAT", "23:45", "06:00", "06h15m", 500.20, sqLiteDatabase);
        insertData(12342, "GOLDLINE SUPER DELUXE", "DELHI", "JAIPUR", "SUN", "21:55", "04:05", "06h10m", 400.50, sqLiteDatabase);
        insertData(119903, "RSRTC", "DELHI", "JAIPUR", "MON", "00:45", "06:15", "05h30m", 591.10, sqLiteDatabase);
        insertData(119078, "RSRTC", "DELHI", "JAIPUR", "TUE", "00:31", "06:30", "05h59m", 852.40, sqLiteDatabase);
        insertData(97386, "KTCL", "MUMBAI", "GOA", "FRI", "17:05", "06:00", "12h55m", 1200.40, sqLiteDatabase);
        insertData(97387, "PULAO TRAVELS", "MUMBAI", "GOA", "SAT", "21:01", "12:16", "15h15m", 1615.90, sqLiteDatabase);
        insertData(97388, "SUBHAM TRAVELS", "MUMBAI", "GOA", "WED", "17:00", "10:30", "17h30m", 900.90, sqLiteDatabase);
        insertData(13241, "CHIRAG TRAVELS", "MUMBAI", "DELHI", "THU", "16:00", "23:00", "31h00m", 3000.30, sqLiteDatabase);
        insertData(13142, "ASIAN XPRESS", "BANGLORE", "CHENNAI", "THU", "22:00", "03:20", "5h20m", 580.00, sqLiteDatabase);
        insertData(13240, "MAHARANI TRAVELS", "JAIPUR", "DELHI", "SAT", "23:30", "05:05", "5h35m", 380.95, sqLiteDatabase);
        insertData(10009, "BSRCT", "PATNA", "DELHI", "SUN", "16:30", "12:30", "20h00m", 1800.00, sqLiteDatabase);
        insertData(10012, "GREENLINE TRAVELS", "BANGLORE", "HYDRABAD", "MON", "22:30", "7:00", "08h30m", 1249.00, sqLiteDatabase);
        insertData(10003, "LIMOLINER", "HYDRABAD", "BANGLORE", "WED", "22:30", "07:30", "09h00m", 1810.00, sqLiteDatabase);
        insertData(10019, "KMRL KALAIMAKAL", "CHENNAI", "BANGLORE", "FRI", "22:00", "04:45", "06h45m", 750.00, sqLiteDatabase);
        insertData(10014, "PARVEEN TRAVELS", "CHENNAI", "HYDRABAD", "WED", "19:45", "05:55", "10h10m", 1000.00, sqLiteDatabase);
        insertData(10010, "VRL TRAVELS", "MUMBAI", "PUNE", "THU", "17:00", "22:00", "05h00m", 333.00, sqLiteDatabase);
        insertData(10021, "ORANGE TOURS AND TRAVELS", "MUMBAI", "BANGLORE", "MON", "16:00", "09:30", "17h30m", 1900.00, sqLiteDatabase);
        insertData(10029, "SHARMA TRANSPORTS", "BANGLORE", "MUMBAI", "SUN", "16:30", "11:00", "18h30m", 1048.00, sqLiteDatabase);
    }

    //add data to signup
    public long addUser(String user, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", user);
        values.put("email", email);
        values.put("password", password);

        long res = db.insert("REGISTER_USER", null, values);
        db.close();
        return res;
    }

    //check login details
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "SELECT username FROM REGISTER_USER WHERE username='" + username + "'AND password='" + password + "'";
        Cursor cursor = db.rawQuery(sql, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if (count > 0)
            return true;
        else
            return false;
    }

    //insert data to bus info tables
    private void insertData(int bus_no, String bus_name, String source, String destination, String doj, String arrival, String departure, String duration, double price, SQLiteDatabase database) {
        ContentValues values = new ContentValues();
        values.put("BUS_NO", bus_no);
        values.put("BUS_NAME", bus_name);
        values.put("SOURCE", source);
        values.put("DESTINATION", destination);
        values.put("DOJ", doj);
        values.put("ARRIVAL", arrival);
        values.put("DEPARTURE", departure);
        values.put("DURATION", duration);
        values.put("PRICE", price);

        database.insert("BUS_INFO", null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    //insert data to passenger info table
    public void InsertPassengerRecords(String passengername, int age, String gender) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("PASSENGER_NAME", passengername);
        values.put("AGE", age);
        values.put("GENDER", gender);

        db.insert("PASSENGER_INFO", null, values);

        StringBuilder sb = new StringBuilder();
        Cursor cursor = db.rawQuery("SELECT * FROM PASSENGER_INFO", null);

        if (cursor.moveToFirst()) {
            do {
                sb.append(cursor.getInt(0));
                sb.append(cursor.getString(1));
                sb.append(cursor.getString(2));
                sb.append(cursor.getString(3));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        Log.i("VALUES", sb.toString());
    }

    //get passenger name to display in confirm ticket
    public ArrayList<String> getPassengerName() {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<String> arrayList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM PASSENGER_INFO", null);

        if (cursor.moveToFirst()) {
            do {
                arrayList.add(cursor.getString(cursor.getColumnIndexOrThrow("PASSENGER_NAME")));

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return arrayList;
    }

    //get passenger age to display in confirm ticket
    public ArrayList<String> getPassengerAge() {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<String> arrayList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM PASSENGER_INFO", null);

        if (cursor.moveToFirst()) {
            do {
                arrayList.add(cursor.getString(cursor.getColumnIndexOrThrow("AGE")));

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return arrayList;
    }

    //get passenger name to display in confirm ticket
    public ArrayList<String> getBusSource() {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<String> arrayList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM BUS_INFO", null);

        if (cursor.moveToFirst()) {
            do {
                if (!arrayList.contains(cursor.getString(cursor.getColumnIndexOrThrow("SOURCE"))))
                    arrayList.add(cursor.getString(cursor.getColumnIndexOrThrow("SOURCE")));

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return arrayList;
    }

    //get passenger name to display in confirm ticket
    public ArrayList<String> getBusDestination() {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<String> arrayList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM BUS_INFO", null);

        if (cursor.moveToFirst()) {
            do {
                if (!arrayList.contains(cursor.getString(cursor.getColumnIndexOrThrow("DESTINATION"))))
                    arrayList.add(cursor.getString(cursor.getColumnIndexOrThrow("DESTINATION")));

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return arrayList;
    }

    //search data according to source and destination
    public List<BusBean> getDataBus(String src, String dest) {

        List<BusBean> data = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM BUS_INFO WHERE SOURCE='" + src + "' AND DESTINATION='" + dest + "' ORDER BY PRICE DESC ", null);
        StringBuffer stringBuffer = new StringBuffer();

        BusBean busBean = null;
        while (cursor.moveToNext()) {
            busBean = new BusBean();
            int busNumber=cursor.getInt(cursor.getColumnIndexOrThrow("BUS_NO"));
            String busName = cursor.getString(cursor.getColumnIndexOrThrow("BUS_NAME"));
            String source = cursor.getString(cursor.getColumnIndexOrThrow("SOURCE"));
            String destination = cursor.getString(cursor.getColumnIndexOrThrow("DESTINATION"));
            String timeArrived = cursor.getString(cursor.getColumnIndexOrThrow("ARRIVAL"));
            String timeDepart = cursor.getString(cursor.getColumnIndexOrThrow("DEPARTURE"));
            String dateArrived = cursor.getString(cursor.getColumnIndexOrThrow("DOJ"));
            String duration = cursor.getString(cursor.getColumnIndexOrThrow("DURATION"));
            String buy = cursor.getString(cursor.getColumnIndexOrThrow("PRICE"));
            //set data to bean
            busBean.setBusNumber(busNumber);
            busBean.setTxtBusName(busName);
            busBean.setTxtStationArrived(source);
            busBean.setTxtStationDestination(destination);
            busBean.setBtnBuy(buy);
            busBean.setTxtTimeArrived(timeArrived);
            busBean.setTxtDateArrived(dateArrived);
            busBean.setTxtTimeDeparture(timeDepart);
            busBean.setTxtJourneyTime(duration);
            stringBuffer.append(busBean);
            data.add(busBean);
        }
        return data;
    }

    //get passenger info from database
    public List<PassengerBean> getData() {
        List<PassengerBean> data = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM PASSENGER_INFO", null);
        PassengerBean passengerBean = null;

        while (cursor.moveToNext()) {
            passengerBean = new PassengerBean();
            String passengerName = cursor.getString(cursor.getColumnIndexOrThrow("PASSENGER_NAME"));
            String passengerAge = cursor.getString(cursor.getColumnIndexOrThrow("AGE"));
            String passengerGender = cursor.getString(cursor.getColumnIndexOrThrow("GENDER"));

            passengerBean.setPassengerName(passengerName);
            passengerBean.setAge(passengerAge);
            passengerBean.setGender(passengerGender);

            data.add(passengerBean);
        }
        return data;
    }

    //delete passenger info table
    public void deleteTable() {
        SQLiteDatabase db = this.getWritableDatabase();

        String sql_deletePassengerInfo = "DELETE FROM PASSENGER_INFO";
        db.execSQL(sql_deletePassengerInfo);
    }

    //set seat info of different bus in database
    public long setSeat(int busNumber, String seatId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("BUSNUMBER", busNumber);
        values.put("SEATMAP", seatId);

        long res = db.insert("SEAT_INFO", null, values);
        db.close();
        return res;

    }

    //get seat list from database
    public ArrayList<String> getSeatList(int busNumber) {
        ArrayList<String> data = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM SEAT_INFO WHERE BUSNUMBER='" + busNumber + "'", null);

        while (cursor.moveToNext()) {
            String seatId = cursor.getString(cursor.getColumnIndexOrThrow("SEATMAP"));
            data.add(seatId);
        }

        return data;
    }
    //get booking history data
    public List<PassengerHistoryBean> getBookingHistoryData() {
        List<PassengerHistoryBean> data = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM BOOKING_HISTORY", null);
        PassengerHistoryBean passengerHistoryBean = null;

        while (cursor.moveToNext()) {
            passengerHistoryBean = new PassengerHistoryBean();
            int bookingId=cursor.getInt(cursor.getColumnIndexOrThrow("ID"));
            String busHistoryName = cursor.getString(cursor.getColumnIndexOrThrow("BUS_NAME"));
            String busHistorySource = cursor.getString(cursor.getColumnIndexOrThrow("SOURCE"));
            String busHistoryDestination = cursor.getString(cursor.getColumnIndexOrThrow("DESTINATION"));
            String busHistoryArrivalDate = cursor.getString(cursor.getColumnIndexOrThrow("JOURNEYDATE"));
            int bookCancel=cursor.getInt(cursor.getColumnIndexOrThrow("BOOKCANCEL"));

            passengerHistoryBean.setBookingId(bookingId);
            passengerHistoryBean.setBusNameHistory(busHistoryName);
            passengerHistoryBean.setStationArrivedHistory(busHistorySource);
            passengerHistoryBean.setStationDestinationHistory(busHistoryDestination);
            passengerHistoryBean.setDateArrivedHistory(busHistoryArrivalDate);
            passengerHistoryBean.setBookedCanceled(bookCancel);

            data.add(passengerHistoryBean);
        }
        return data;
    }

    //insert data to passenger info table
    public void setBookingHistoryData(String busName, String busSource, String busDestination, String busArrivalDate,int bookCancel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("BUS_NAME", busName);
        values.put("SOURCE", busSource);
        values.put("DESTINATION", busDestination);
        values.put("JOURNEYDATE", busArrivalDate);
        values.put("BOOKCANCEL",bookCancel);

        db.insert("BOOKING_HISTORY", null, values);

        StringBuilder sb = new StringBuilder();
        Cursor cursor = db.rawQuery("SELECT * FROM BOOKING_HISTORY", null);

        if (cursor.moveToFirst()) {
            do {
                sb.append(cursor.getString(0));
                sb.append(cursor.getString(1));
                sb.append(cursor.getString(2));
                sb.append(cursor.getString(3));
                sb.append(cursor.getInt(cursor.getColumnIndexOrThrow("BOOKCANCEL")));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        Log.i("VALUES", sb.toString());
    }

    //delete booking history table
    public void deleteHistoryTable() {
        SQLiteDatabase db = this.getWritableDatabase();

        String sql_deleteBookingHistory = "DELETE FROM BOOKING_HISTORY";
        db.execSQL(sql_deleteBookingHistory);
    }
    //update booking history
    public void updateBookingHistory(int bookingId,String busName)
    {
        SQLiteDatabase db=getWritableDatabase();
        String sql_updateBookingHistory="UPDATE BOOKING_HISTORY SET BOOKCANCEL=0 WHERE ID='"+bookingId+"' AND BUS_NAME='"+busName+"'";
        db.execSQL(sql_updateBookingHistory);
    }
    //insert data into recent search
    public void InsertRecentSearch(String source, String destination, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("SOURCE", source);
        values.put("DESTINATION", destination);
        values.put("DATE", date);

        db.insert("RECENT_SEARCH", null, values);

        StringBuilder sb = new StringBuilder();
        Cursor cursor = db.rawQuery("SELECT * FROM RECENT_SEARCH", null);

        if (cursor.moveToFirst()) {
            do {
                sb.append(cursor.getInt(0));
                sb.append(cursor.getString(1));
                sb.append(cursor.getString(2));
                sb.append(cursor.getString(3));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        Log.i("VALUES", sb.toString());
    }
    //get data from Recent Search
    public List<RecentSearchBean> getRecentSearchData() {
        List<RecentSearchBean> data = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM RECENT_SEARCH ORDER BY ID DESC LIMIT 5", null);
        RecentSearchBean recentSearchBean = null;

        while (cursor.moveToNext()) {
            recentSearchBean = new RecentSearchBean();
            String recentSource = cursor.getString(cursor.getColumnIndexOrThrow("SOURCE"));
            String recentDestination = cursor.getString(cursor.getColumnIndexOrThrow("DESTINATION"));
            String recentDate = cursor.getString(cursor.getColumnIndexOrThrow("DATE"));

            recentSearchBean.setRecentSource(recentSource);
            recentSearchBean.setRecentDestination(recentDestination);
            recentSearchBean.setRecentDate(recentDate);

            data.add(recentSearchBean);
        }
        return data;
    }

}