package com.pinelabs.book.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import com.pinelabs.book.R;
import com.pinelabs.book.activities.base.BasePineActivity;
import com.pinelabs.book.beans.pojo.Booking;
import com.pinelabs.book.beans.pojo.BusBean;
import com.pinelabs.book.beans.request.DoTransactionRequest;
import com.pinelabs.book.beans.request.HeaderRequest;
import com.pinelabs.book.db.DBHelper;
import com.pinelabs.book.enums.PaymentModeEnum;
import com.pinelabs.book.helper.PineServiceHelper;
import com.pinelabs.book.helper.StringConstants;
import com.pinelabs.book.utility.AndroidUtils;

import java.util.ArrayList;

public class ConfirmTicketActivity extends BasePineActivity {

    private PineServiceHelper pineSH;
    TextView tvStationSource, tvStationDestination, tvArrivalTime, tvArrivalDate, tvJourneyDuration, tvPrice, tvPassengerCount, tvClass;
    ListView lvPassengerList, lvPassengerSeat;
    private Button btnConfirmBooking;
    private String passengerCount, trainClass, journeyDate;
    private Long result;
    private Double totalPriceInRs;
    private BusBean busBean;
    Booking booking;
    DBHelper db;
    ArrayList<String> arrayListPassengerName, arrayListPassengerAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_ticket);
        initViews();
        init();
        getData();
        setData();
    }

    //Get data from Intent
    private void getData() {
        busBean = (BusBean) getIntent().getSerializableExtra(StringConstants.BUS_DATA);
        booking = new Booking();
        booking = (Booking) getIntent().getSerializableExtra(StringConstants.SEATDATA);
        passengerCount = getIntent().getStringExtra(StringConstants.SPINNER_PASSENGER_1);
        trainClass = getIntent().getStringExtra(StringConstants.SPINNER_CLASS_1);
        journeyDate = getIntent().getStringExtra(StringConstants.JOURNEY_DATE);
        db = new DBHelper(this);
        //get passenger name data from database to arrayList for displaying it in list view display in listView
        arrayListPassengerName = db.getPassengerName();
        arrayListPassengerAge = db.getPassengerAge();

    }

    //Init PineServiceHelper Instance to move data to page where payment callback is received
    private void init() {
        pineSH = PineServiceHelper.getInstance();
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        pineSH.connect(this);
    }
    //set data for Confirm Ticket Activity
    private void setData() {
        setTitle(busBean.getTxtBusName());
        tvStationSource.setText(busBean.getTxtStationArrived());
        tvStationDestination.setText(busBean.getTxtStationDestination());
        tvArrivalTime.setText(busBean.getTxtTimeArrived());
        tvArrivalDate.setText(journeyDate);
        tvJourneyDuration.setText(busBean.getTxtJourneyTime());
        tvPassengerCount.setText(passengerCount);
        tvClass.setText(trainClass);

        Double unitPrice = Double.parseDouble(busBean.getBtnBuy());
        Double passengerCount = Double.parseDouble(this.passengerCount);
        totalPriceInRs = unitPrice * passengerCount;
        //for send amount in paise to simulator app
        result = Math.round(totalPriceInRs * 100);
        //use android utils to set currency in indian format
        tvPrice.setText(AndroidUtils.getCurrencyInIndianFormat(totalPriceInRs));
        //Data mapping
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1, arrayListPassengerName);

        lvPassengerList.setAdapter(arrayAdapter);

        ArrayAdapter<String> seatArrayAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, arrayListPassengerAge);

        lvPassengerSeat.setAdapter(seatArrayAdapter);

        btnConfirmBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                db.setBookingHistoryData(busBean.getTxtBusName(), busBean.getTxtStationArrived(), busBean.getTxtStationDestination(), journeyDate, 1);
                //call pine service
                HeaderRequest<DoTransactionRequest> headerRequest = PaymentModeEnum.Sale.getRequest();
                callPineService(headerRequest);
            }
        });
    }

    //create menu which allows to show history
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_history, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                onBackPressed();
                break;
            }
            case R.id.booking_history: {
                //start passenger history activity on click
                Intent intent = new Intent(ConfirmTicketActivity.this, PassengerHistoryActivity.class);
                startActivity(intent);
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    //initiate view confirm activity
    private void initViews() {
        tvStationSource = findViewById(R.id.stationsource);
        tvStationDestination = findViewById(R.id.stationdestination);
        tvArrivalTime = findViewById(R.id.arrivaltime);
        tvArrivalDate = findViewById(R.id.arrivaldate);
        tvJourneyDuration = findViewById(R.id.journeytime);
        tvPrice = findViewById(R.id.price);
        tvPassengerCount = findViewById(R.id.passengercount);
        tvClass = findViewById(R.id.travelclass);
        lvPassengerList = findViewById(R.id.lv_passengerlist);
        lvPassengerSeat = findViewById(R.id.lv_passengerage);
        btnConfirmBooking = findViewById(R.id.btn_confirm_booking);

    }

    private void callPineService(final HeaderRequest<DoTransactionRequest> headerRequest) {
        DoTransactionRequest request = headerRequest.getDetail();
        request.setPaymentAmount(result);
        pineSH.setbookingDetails(booking);
        pineSH.callPineService(headerRequest);
    }

}

