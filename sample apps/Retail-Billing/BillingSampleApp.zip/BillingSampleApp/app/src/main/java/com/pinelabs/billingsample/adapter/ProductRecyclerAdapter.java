package com.pinelabs.billingsample.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.pojo.ProductBean;
import com.pinelabs.billingsample.config.AppConfig;
import com.pinelabs.billingsample.utility.AndroidUtils;

import java.util.List;

/**
 * Created by Pinelabs Pvt Ltd on 01-03-2017.
 *
 * adapter for populating my cards and changing card status to active/inactive
 */

public class ProductRecyclerAdapter extends RecyclerView.Adapter<ProductRecyclerAdapter.CardViewHolder> {

    private List<ProductBean> mList;
    private ItemSelectListener mListener;
    private Context mContext;
    private int type;

    public ProductRecyclerAdapter(Context context, List<ProductBean> list, ItemSelectListener listener, int type) {
        this.mContext = context;
        this.mList = list;
        this.type = type;
        this.mListener = listener;
    }

    @Override
    public CardViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.bm_item_product, parent, false);

        return new CardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CardViewHolder holder, int position) {
        ProductBean bean = mList.get(position);
        holder.name.setText(bean.getProductName());
        holder.price.setText(AndroidUtils.getCurrencyInIndianFormat(mContext, AndroidUtils.paiseToRupeeConversion(bean.getPrice())));
        holder.key.setText(String.format("%s", bean.getKey()));
        if (position == getItemCount() - AppConfig.POSITION_FROM_LAST && type == AppConfig.ITEM_RV) {
            holder.viewCategory.setVisibility(View.VISIBLE);
            holder.viewItem.setVisibility(View.GONE);
        } else {
            holder.viewItem.setVisibility(View.VISIBLE);
            holder.viewCategory.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mList != null ? mList.size() : 0;
    }

    public interface ItemSelectListener {
        void onItemSelected(ProductBean bean, int position, int type);
    }

    class CardViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final View viewItem;
        private final View viewCategory;
        private TextView name, key, price;

        private CardViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.tv_name);
            key = view.findViewById(R.id.tv_key);
            price = view.findViewById(R.id.tv_price);
            viewCategory = view.findViewById(R.id.view_category);
            viewItem = view.findViewById(R.id.view_item);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION && mList != null) {
                ProductBean bean = mList.get(position);
                if (bean != null && mListener != null) {
                    mListener.onItemSelected(bean, position, type);
                }
            }
        }

    }

}
