package com.pinelabs.billingsample.constants;

/*
 * Created by Pinelabs Pvt Ltd on 9/15/2017.
 */

public interface PreferenceConstants {
    String CART_PREF_KEY = "CART_PREF_KEY";
    String USER_ID_PREF_KEY = "USER_ID_PREF_KEY";
}
