package com.pinelabs.billingsample.config;

/*
 * Created by Pinelabs Pvt Ltd on 9/15/2017.
 */

public class AppConfig {
    public static final Integer PrinterWidth = 24;
    public static final String Separator = String.format("%0" + PrinterWidth + "d", 0).replace("0", "-");

    public static final String REQUEST_KEY = "MASTERAPPREQUEST";
    public static final String RESPONSE_KEY = "MASTERAPPRESPONSE";

    public static final String PINE_ACTION = "com.pinelabs.masterapp.SERVER";
    public static final String PINE_PACKAGE = "com.pinelabs.masterapp";

    public static final int ITEM_RV = 0;
    public static final int MORE_RV = 1;
    public static final int POSITION_FROM_LAST = 1;

    public static final String UserMno = "pinelabs";
    public static final String UserPassword = "pine@123";

}
