package com.pinelabs.billingsample.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.request.DoTransactionRequest;
import com.pinelabs.billingsample.beans.request.HeaderRequest;
import com.pinelabs.billingsample.beans.response.DetailResponse;
import com.pinelabs.billingsample.enums.PaymentModeEnum;
import com.pinelabs.billingsample.fragments.EnterAmountBottomFragment;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.helper.PineServiceHelper;
import com.pinelabs.billingsample.utility.UIUtils;

/**
 * Created by Pinelabs Pvt Ltd on 11/28/2017.
 * <p>
 * Activity use to show multiple payment option to the user
 */
public class PaymentModeActivity extends BasePineActivity {

    @NonNull
    private PineServiceHelper pineSH;
    private String payMode;
    private long amt;
    private LinearLayout mRootLayout;
    private TextView tvPendingAmount;
    private TextView tvPayableAmount;
    private TextView tvTotalPaidAmt;

    private void initViews() {
        tvPendingAmount = findViewById(R.id.tv_pending_amt);
        tvPayableAmount = findViewById(R.id.tv_payable_amt);
        tvTotalPaidAmt = findViewById(R.id.tv_paid_amt);
        mRootLayout = findViewById(R.id.root_layout);
        pineSH = PineServiceHelper.getInstance();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_payment_mode);
        setBackButton();
        initViews();
        setData();
    }

    private void setData() {
        pineSH.connect(this);

        tvPayableAmount.setText(String.format(getString(R.string.pay_amt), CartHelper.getInstance().getDisplayNetPayableAmount()));
        tvPendingAmount.setText(String.format(getString(R.string.pending_amt), CartHelper.getInstance().getPendingDisplayAmt()));
        tvTotalPaidAmt.setText(String.format(getString(R.string.paid_amt), CartHelper.getInstance().getPaidDisplayAmt()));

        for (final PaymentModeEnum type : pineSH.getSaleList()) {
            Button button = new Button(this);
            button.setText(type.getName());
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HeaderRequest<DoTransactionRequest> headerRequest = type.getRequest();
                    payMode = type.getName();
                    callPineService(headerRequest);
                }
            });
            mRootLayout.addView(button);
        }
    }

    /**
     * method use to initialize the transaction
     *
     * @param headerRequest - Request Structure
     */
    private void callPineService(final HeaderRequest<DoTransactionRequest> headerRequest) {
        EnterAmountBottomFragment.getInstance(new EnterAmountBottomFragment.Callback() {
            @Override
            public void onSubmit(Long amtInPaisa) {
                amt = amtInPaisa;
                DoTransactionRequest request = headerRequest.getDetail();
                request.setBillingRefNo(CartHelper.getInstance().getBillRefNo());
                request.setPaymentAmount(amtInPaisa);

                pineSH.callPineService(headerRequest);
            }
        }, false, true).show(getSupportFragmentManager(), "");
    }


    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult( detailResponse);
        if (detailResponse != null) {
            if (detailResponse.getResponse().isSuccess()) {
                CartHelper.getInstance().addPayment(payMode, amt);
                if (CartHelper.getInstance().isBillComplete()) {
                    openInvoice();
                } else {
                    tvPendingAmount.setText(String.format(getString(R.string.pending_amt), CartHelper.getInstance().getPendingDisplayAmt()));
                    tvTotalPaidAmt.setText(String.format(getString(R.string.paid_amt), CartHelper.getInstance().getPaidDisplayAmt()));
                    UIUtils.makeToast(this, String.format(getString(R.string.pending_amt), CartHelper.getInstance().getPendingDisplayAmt()));
                }
            } else {
                UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
            }
        } else {
            UIUtils.makeToast(this, "Error");
        }
    }

    private void openInvoice() {
        startActivity(new Intent(this, InvoiceActivity.class));
    }

    /**
     * method use for Cash Transaction
     */
    public void onCashClick(View view) {
        EnterAmountBottomFragment.getInstance(new EnterAmountBottomFragment.Callback() {
            @Override
            public void onSubmit(Long amtInPaisa) {
                CartHelper.getInstance().addPayment("Cash", CartHelper.getInstance().getPendingAmt());
                openInvoice();
            }
        }, true, true).show(getSupportFragmentManager(), "");
    }

    @Override
    public void onBackPressed() {
        if (CartHelper.getInstance().isPendingInvoice()) {
            UIUtils.makeToast(this, "Please complete the transaction");
        } else {
            super.onBackPressed();
        }
    }
}
