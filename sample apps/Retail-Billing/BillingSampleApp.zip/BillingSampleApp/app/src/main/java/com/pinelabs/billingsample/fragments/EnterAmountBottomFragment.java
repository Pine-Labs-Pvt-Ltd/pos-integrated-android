package com.pinelabs.billingsample.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.utility.AndroidUtils;
import com.pinelabs.billingsample.utility.UIUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Pinelabs Pvt Ltd on 1/30/2019.
 *
 * Fragment used for amount input
 *
 * All Validation
 *
 * for Cash handling
 * Card payment
 * Refund/load payment
 */
public class EnterAmountBottomFragment extends BottomSheetDialogFragment {
    private TextView tvReturnAmt;
    private EditText etAmt;
    private Callback callback;
    private boolean isCash;
    private boolean isSale;

    public static EnterAmountBottomFragment getInstance(Callback callback, boolean isCash, boolean isSale) {
        EnterAmountBottomFragment enterAmountBottomFragment = new EnterAmountBottomFragment();
        enterAmountBottomFragment.setIsCash(isCash);
        enterAmountBottomFragment.setIsSale(isSale);
        enterAmountBottomFragment.setCallBack(callback);
        return enterAmountBottomFragment;
    }

    private void setIsSale(boolean isSale) {
        this.isSale = isSale;
    }

    private void setCallBack(Callback callback) {
        this.callback = callback;
    }

    public void initViews(View view) {
        TextView tvAmt = view.findViewById(R.id.tv_amt);
        Button btnSubmit = view.findViewById(R.id.btn_submit);
        etAmt = view.findViewById(R.id.et_amt);
        tvReturnAmt = view.findViewById(R.id.tv_return_amt);
        final Long lPayableAmt = CartHelper.getInstance().getPendingAmt();
        Double amtInINR = AndroidUtils.paiseToRupeeConversion(lPayableAmt);

        etAmt.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(6, 2)});

        if (isSale) {
            tvAmt.setText(String.format("Payable Amount: %s", AndroidUtils.getCurrencyInIndianFormat(amtInINR)));
            etAmt.setText(String.valueOf(amtInINR));
            etAmt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    try {
                        if (!TextUtils.isEmpty(s)) {
                            long amt = AndroidUtils.getAmtInPaisa(etAmt.getText().toString());
                            long returnAmt = amt - lPayableAmt;

                            if (returnAmt >= 0) {
                                tvReturnAmt.setText(String.format("Return Amount : %s", AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(returnAmt))));
                                if (isCash)
                                    tvReturnAmt.setVisibility(View.VISIBLE);
                            } else {
                                tvReturnAmt.setVisibility(View.GONE);
                            }
                        } else {
                            tvReturnAmt.setVisibility(View.GONE);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        tvReturnAmt.setVisibility(View.GONE);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
        } else {
            tvAmt.setText(R.string.refund_amt_msg);
        }

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) {
                    Long inputAmt = AndroidUtils.getAmtInPaisa(etAmt.getText().toString());
                    if (inputAmt <= 0) {
                        UIUtils.makeToast(getContext(), "Enter Amount");
                        return;
                    }
                    if (isSale) {

                        if (isCash) {
                            //In case of Cash
                            if (inputAmt >= lPayableAmt) {
                                dismiss();
                                callback.onSubmit(inputAmt);
                            } else {
                                UIUtils.makeToast(getContext(), "Amount cannot be lesser than Payable Amount");
                            }
                        } else {
                            //Card Payment
                            if (inputAmt <= lPayableAmt) {
                                dismiss();
                                callback.onSubmit(inputAmt);
                            } else {
                                UIUtils.makeToast(getContext(), "Amount cannot be greater than Payable Amount");
                            }
                        }
                    } else {
                        dismiss();
                        callback.onSubmit(inputAmt);
                    }
                }
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bm_fragment_enter_amt, container, false);
        initViews(view);
        return view;
    }

    public void setIsCash(boolean isCash) {
        this.isCash = isCash;
    }

    public interface Callback {
        void onSubmit(Long amtInPaisa);
    }

    private class DecimalDigitsInputFilter implements InputFilter {
        Pattern mPattern;

        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }
}
