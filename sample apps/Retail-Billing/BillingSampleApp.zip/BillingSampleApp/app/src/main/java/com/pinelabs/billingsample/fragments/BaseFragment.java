package com.pinelabs.billingsample.fragments;

import android.support.v4.app.Fragment;

/*
 * Created by Pinelabs Pvt Ltd on 11/27/2017.
 */

public abstract class BaseFragment extends Fragment {
}
