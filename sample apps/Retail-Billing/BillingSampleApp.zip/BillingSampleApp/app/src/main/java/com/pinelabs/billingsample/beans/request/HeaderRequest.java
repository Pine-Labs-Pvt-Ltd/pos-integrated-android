package com.pinelabs.billingsample.beans.request;

import com.google.gson.annotations.SerializedName;
import com.pinelabs.billingsample.beans.pojo.Header;
import com.pinelabs.billingsample.utility.GsonUtils;

public class HeaderRequest<T> {

    @SerializedName("Header")
    private Header Header;
    @SerializedName("Detail")
    private T Detail;

    public HeaderRequest(String methodId) {
        this.Header = new Header("1001", methodId, "userId", "1.0");
    }

    public Header getHeader() {
        return Header;
    }

    public void setHeader(Header header) {
        Header = header;
    }

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    @Override
    public String toString() {
        return GsonUtils.fromJsonToString(this);
    }
}
