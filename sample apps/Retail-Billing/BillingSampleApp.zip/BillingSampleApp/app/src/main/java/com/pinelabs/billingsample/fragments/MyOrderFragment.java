package com.pinelabs.billingsample.fragments;

/**
 * Created by Pinelabs Pvt Ltd on 11/27/2017.
 *
 * uses to show product list
 *
 * if editable true - then product list editable in case of review cart
 * if false - then product list id read only in case of Invoice display
 */

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.adapter.MyOrderProductListAdapter;
import com.pinelabs.billingsample.beans.pojo.PurchasedProductBean;
import com.pinelabs.billingsample.constants.IntentConstants;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.utility.AndroidUtils;
import com.pinelabs.billingsample.utility.UIUtils;

import java.util.ArrayList;

public class MyOrderFragment extends BaseFragment implements MyOrderProductListAdapter.CallBack {

    private RecyclerView mRecyclerView;
    private boolean isEditable;
    private MyOrderProductListAdapter mAdapter;

    private TextView mTvTotal;
    private TextView mTvDiscount;
    private TextView mTvTax;
    private TextView mTvNetPayable;
    private MyOrderFragment.AmountCallBack amountCallBack;
    private NestedScrollView scrollView;

    public static MyOrderFragment getInstance(boolean isEditable, AmountCallBack callBack) {
        MyOrderFragment fragment = new MyOrderFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean(IntentConstants.IS_ORDER_EDITABLE, isEditable);
        fragment.setArguments(bundle);
        fragment.amountCallBack = callBack;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bm_frag_my_order, container, false);
        getData();
        initViews(view);

        scrollView.postDelayed(new Runnable() {
            @Override
            public void run() {
                scrollView.setSmoothScrollingEnabled(true);
                scrollView.fullScroll(View.FOCUS_DOWN);

            }
        }, 400);
        return view;
    }

    private void getData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            isEditable = bundle.getBoolean(IntentConstants.IS_ORDER_EDITABLE, false);
        } else {
            actionReturnToBack();
        }
    }

    private void actionReturnToBack() {
        UIUtils.makeToast(getContext(), getString(R.string.something_wrong));
        getActivity().finish();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        refreshLayout();
    }

    private void setAdapterData() {
        ArrayList<PurchasedProductBean> productBeans = new ArrayList<>(CartHelper.getInstance().getCart().values());
        if (mAdapter == null) {
            mAdapter = new MyOrderProductListAdapter(getContext(), MyOrderFragment.this, productBeans, isEditable);
            mRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.setList(productBeans);
        }
    }


    private void initViews(View view) {
        mRecyclerView = view.findViewById(R.id.recycler_view);
        mTvTotal = view.findViewById(R.id.tv_total);
        mTvDiscount = view.findViewById(R.id.tv_discount);
        mTvTax = view.findViewById(R.id.tv_tax);
        mTvNetPayable = view.findViewById(R.id.tv_net_pay);
        scrollView = view.findViewById(R.id.scrollView);
    }

    private void refreshLayout() {
        setAdapterData();
        setTotalValues();
        if (amountCallBack != null) {
            amountCallBack.onAmountChanged();
        }
    }

    private void setTotalValues() {
        mTvTotal.setText(AndroidUtils.getCurrencyInIndianFormat(getContext(), AndroidUtils.paiseToRupeeConversion(CartHelper.getInstance().getTotalCartAmount())));
        mTvDiscount.setText(AndroidUtils.getCurrencyInIndianFormat(getContext(), AndroidUtils.paiseToRupeeConversion(-1 * CartHelper.getInstance().getTotalDiscount())));
        mTvNetPayable.setText(AndroidUtils.getCurrencyInIndianFormat(getContext(), AndroidUtils.paiseToRupeeConversion(CartHelper.getInstance().getNetPayableAmount())));
        mTvTax.setText(AndroidUtils.getCurrencyInIndianFormat(getContext(), AndroidUtils.paiseToRupeeConversion(CartHelper.getInstance().getTotalTax())));
    }


    @Override
    public void OnRefresh() {
        refreshLayout();
    }

    public interface AmountCallBack {
        void onAmountChanged();
    }
}
