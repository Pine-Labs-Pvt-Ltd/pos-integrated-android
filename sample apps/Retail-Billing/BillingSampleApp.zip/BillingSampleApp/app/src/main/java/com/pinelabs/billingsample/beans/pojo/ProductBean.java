package com.pinelabs.billingsample.beans.pojo;

import com.pinelabs.billingsample.utility.AndroidUtils;

/**
 * Created by Pinelabs Pvt Ltd on 11/27/2017.
 */

public class ProductBean {
    private long key;
    private String productName;
    private long price;
    private float discountPercentage;

    public ProductBean(long key, long price, float discountPercentage, String productName) {
        this.key = key;
        this.price = price;
        this.discountPercentage = discountPercentage;
        this.productName = productName;
    }

    public float getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(float discount) {
        this.discountPercentage = discount;
    }

    public float getDiscount() {
        return price * discountPercentage / 100;
    }

    public long getKey() {
        return key;
    }

    public void setKey(long key) {
        this.key = key;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public String getFormatedPrice() {
        return AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(price));
    }
}
