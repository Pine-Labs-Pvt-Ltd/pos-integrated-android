package com.pinelabs.billingsample.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.request.DoTransactionRequest;
import com.pinelabs.billingsample.beans.request.HeaderRequest;
import com.pinelabs.billingsample.beans.response.DetailResponse;
import com.pinelabs.billingsample.enums.RefundEnum;
import com.pinelabs.billingsample.fragments.EnterAmountBottomFragment;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.helper.PineServiceHelper;
import com.pinelabs.billingsample.utility.UIUtils;


/**
 * Created by Pinelabs Pvt Ltd on 11/28/2017.
 * <p>
 * Activity use for payment refund/load
 */
public class RefundActivity extends BasePineActivity implements PineServiceHelper.PineCallBack {

    private LinearLayout mRootLayout;

    private void initViews() {
        mRootLayout = findViewById(R.id.root_layout);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_refund);
        setBackButton();
        initViews();
        setData();
    }

    private void setData() {
        PineServiceHelper.getInstance().connect(this);
        for (final RefundEnum type : PineServiceHelper.getInstance().getRefundList()) {
            Button button = new Button(this);
            button.setText(type.getName());
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HeaderRequest<DoTransactionRequest> headerRequest = type.getRequest();
                    callPineService(headerRequest);
                }
            });
            mRootLayout.addView(button);
        }
    }

    /**
     * method use to initialize the transaction
     *
     * @param headerRequest - Request Structure
     */
    private void callPineService(final HeaderRequest<DoTransactionRequest> headerRequest) {
        EnterAmountBottomFragment.getInstance(new EnterAmountBottomFragment.Callback() {
            @Override
            public void onSubmit(Long amtInPaisa) {
                if (amtInPaisa > 0) {
                    DoTransactionRequest request = headerRequest.getDetail();
                    request.setBillingRefNo(CartHelper.getInstance().getBillRefNo());
                    request.setPaymentAmount(amtInPaisa);

                    PineServiceHelper.getInstance().callPineService(headerRequest);
                }
            }
        }, false, false).show(getSupportFragmentManager(), "");
    }

    /**
     * method called after transaction
     *
     * @param detailResponse - Contain result data
     */
    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult(detailResponse);
        if (detailResponse != null) {
            if (detailResponse.getResponse().isSuccess()) {
                openMainActivity();
            } else {
                UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
            }
        } else {
            UIUtils.makeToast(this, getString(R.string.error));
        }
    }

    @Override
    public void onBackPressed() {
        if (CartHelper.getInstance().isPendingInvoice()) {
            UIUtils.makeToast(this, getString(R.string.complete_txn_error_msg));
        } else {
            super.onBackPressed();
        }
    }

    private void openMainActivity() {
        startActivity(new Intent(this, MainActivity.class));
    }

}
