package com.pinelabs.billingsample.activities;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.response.DetailResponse;
import com.pinelabs.billingsample.helper.PineServiceHelper;
import com.pinelabs.billingsample.utility.UIUtils;

/**
 * Created by Pinelabs Pvt Ltd on 2/5/2019.
 * <p>
 * This activity use to implement Bound service callbacks
 */
public abstract class BasePineActivity extends BaseActivity implements PineServiceHelper.PineCallBack {
    @Override
    protected void onRestart() {
        super.onRestart();
        PineServiceHelper.getInstance().connect(this);
    }

    @Override
    public void showToast(String msg) {
        UIUtils.dismissProgressbar();
        UIUtils.makeToast(this, msg);
    }

    @Override
    public void connectAgain() {
        UIUtils.dismissProgressbar();
        PineServiceHelper.getInstance().connect(this);
    }

    @Override
    public void sendResult(DetailResponse detailResponse) {
        UIUtils.dismissProgressbar();
    }

    @Override
    public void showWaitingDialog() {
        UIUtils.showDialog(this, getString(R.string.please_Wait));
    }

}
