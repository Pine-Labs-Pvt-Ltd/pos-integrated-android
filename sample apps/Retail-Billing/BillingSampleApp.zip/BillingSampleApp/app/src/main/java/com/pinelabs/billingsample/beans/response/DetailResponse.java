package com.pinelabs.billingsample.beans.response;


import com.google.gson.annotations.SerializedName;
import com.pinelabs.billingsample.beans.pojo.Header;

public class DetailResponse<T>{

    @SerializedName("Detail")
    private T Detail;

    @SerializedName("Header")
    private Header Header;

    @SerializedName("Response")
    private Response Response;

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    public com.pinelabs.billingsample.beans.pojo.Header getHeader() {
        return Header;
    }

    public void setHeader(com.pinelabs.billingsample.beans.pojo.Header header) {
        Header = header;
    }

    public com.pinelabs.billingsample.beans.response.Response getResponse() {
        return Response;
    }

    public void setResponse(com.pinelabs.billingsample.beans.response.Response response) {
        Response = response;
    }
}
