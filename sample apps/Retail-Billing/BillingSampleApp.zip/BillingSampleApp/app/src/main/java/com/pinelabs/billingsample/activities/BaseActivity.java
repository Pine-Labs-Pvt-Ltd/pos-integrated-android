package com.pinelabs.billingsample.activities;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.utility.UIUtils;

/**
 * Activity to provide common functionality in the app
 */
public abstract class BaseActivity extends AppCompatActivity {

    /**
     * Hide Soft Keyboard automatically for Dialogs.
     */
    public void hideSoftKeyboard() {
        View view = this.getCurrentFocus();

        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && imm.isActive()) {
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        }
    }

    @Override
    public void finish() {
        super.finish();
        UIUtils.closeVirtualKeyBoard(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);

    }

    protected void setBackButton() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        hideSoftKeyboard();
        CartHelper.getInstance().saveCart();
    }

    protected void hideActionBar() {
        try {
            if (getSupportActionBar() != null) {
                getSupportActionBar().hide();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
