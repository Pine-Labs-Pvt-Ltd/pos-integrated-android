package com.pinelabs.billingsample.activities;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.adapter.ProductRecyclerAdapter;
import com.pinelabs.billingsample.beans.pojo.ProductBean;
import com.pinelabs.billingsample.beans.response.DetailResponse;
import com.pinelabs.billingsample.config.AppConfig;
import com.pinelabs.billingsample.constants.IntentConstants;
import com.pinelabs.billingsample.fragments.SearchDialogFragment;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.helper.PineServiceHelper;
import com.pinelabs.billingsample.helper.PreferenceHelper;
import com.pinelabs.billingsample.utility.PermissionUtil;
import com.pinelabs.billingsample.utility.UIUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * this activity show all products
 * Also provide functionality to search product using product number and Barcode/QR Scan
 */
public class MainActivity extends BasePineActivity implements ProductRecyclerAdapter.ItemSelectListener, SearchDialogFragment.DismissListener {

    private static final int RQS_OPEN_CAMERA = 102;
    private static final int PRODUCT_CODE = 103;
    private static final int UPDATE_CART = 104;
    private static final int MORE_PRODUCTS = 105;

    private Map<Long, ProductBean> map = new LinkedHashMap<Long, ProductBean>();
    private Map<Long, ProductBean> mapMore = new LinkedHashMap<Long, ProductBean>();

    private TextView tvCartCount;
    private TextView tvAmount;
    private ViewGroup mRootLayout;
    private RecyclerView recyclerView;
    private RecyclerView recyclerViewMore;
    private View ivBack;
    private TextView tvText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_main);
        initViews();
        hideActionBar();
        updateCartViews();
        PineServiceHelper.getInstance().connect(this);

        //Check Partial Payment Case
        if (CartHelper.getInstance().isPendingInvoice()) {
            startActivity(new Intent(this, PaymentModeActivity.class));
            finish();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        PineServiceHelper.getInstance().connect(this);
        updateCartViews();
    }

    private void initViews() {

        tvCartCount = findViewById(R.id.tv_cart_count);
        tvAmount = findViewById(R.id.tv_amount);
        ivBack = findViewById(R.id.iv_back);
        tvText = findViewById(R.id.tv_text);
        mRootLayout = findViewById(R.id.root_layout);

        TextView tvUserName = findViewById(R.id.tv_user_name);
        TextView tvScan = findViewById(R.id.tv_scan);
        TextView tvSearch = findViewById(R.id.tv_search);
        ViewGroup cart = findViewById(R.id.cart);
        View exit = findViewById(R.id.iv_exit);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionLogout();
            }
        });
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actionCheckOut();
            }
        });

        tvUserName.setText(String.format(getString(R.string.user_pinelabs), PreferenceHelper.getInstance().getUserID()));
        tvAmount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actionCheckOut();
            }
        });

        tvScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkCameraPermission();
            }
        });

        tvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SearchDialogFragment fragment = SearchDialogFragment.newInstance(MainActivity.this);
                fragment.show(getSupportFragmentManager(), null);
            }
        });

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionViewMoreBack();
            }
        });

        setUpRecyclerView();
    }

    private void setUpRecyclerView() {
        recyclerView = findViewById(R.id.rv);
        recyclerViewMore = findViewById(R.id.rv_more);

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(MainActivity.this, 2);
        RecyclerView.LayoutManager mLayoutManagerMore = new GridLayoutManager(MainActivity.this, 2);

        recyclerView.setLayoutManager(mLayoutManager);
        recyclerViewMore.setLayoutManager(mLayoutManagerMore);

        ProductRecyclerAdapter adapter = new ProductRecyclerAdapter(this, getProductList(), this, AppConfig.ITEM_RV);
        ProductRecyclerAdapter adapterMore = new ProductRecyclerAdapter(this, getProductListMore(), this, AppConfig.MORE_RV);

        recyclerView.setAdapter(adapter);
        recyclerViewMore.setAdapter(adapterMore);
    }

    /**
     * This is method adds products for the product selection Page
     *
     * @return Product list
     */
    private List<ProductBean> getProductList() {

        ProductBean bean = new ProductBean(212443554, 234000, 0, "Brand A");
        map.put(bean.getKey(), bean);
        bean = new ProductBean(54653554, 114000, 10, "Brand B");
        map.put(bean.getKey(), bean);
        bean = new ProductBean(4353554, 12000, 20, "Brand C");
        map.put(bean.getKey(), bean);
        bean = new ProductBean(11153554, 1400, 10, "Brand D");
        map.put(bean.getKey(), bean);
        return new ArrayList<>(map.values());
    }

    /**
     * This is method adds list more products for the product selection Page
     *
     * @return More Product list (Page 2)
     */
    private List<ProductBean> getProductListMore() {
        ProductBean bean = new ProductBean(1478, 234000, 0, "Brand G");
        mapMore.put(bean.getKey(), bean);
        bean = new ProductBean(8523, 114000, 10, "Brand H");
        mapMore.put(bean.getKey(), bean);
        bean = new ProductBean(3698, 12000, 20, "Brand I");
        mapMore.put(bean.getKey(), bean);
        bean = new ProductBean(8521, 1400, 10, "Brand J");
        mapMore.put(bean.getKey(), bean);
        bean = new ProductBean(2147, 4000, 10, "Brand K");
        mapMore.put(bean.getKey(), bean);
        bean = new ProductBean(7852, 123000, 30, "Brand L");
        mapMore.put(bean.getKey(), bean);
        return new ArrayList<>(mapMore.values());
    }

    private void actionLogout() {
        AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setMessage(R.string.alert_logout_msg);
        builder.setNegativeButton(R.string.no, null);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                PreferenceHelper.getInstance().logout();
                UIUtils.makeToast(MainActivity.this, getString(R.string.msg_logout));
                finish();
            }
        });
        builder.show();

    }

    private void actionCheckOut() {
        if (CartHelper.getInstance().getTotalCartQty() > 0) {
            Intent intent = new Intent(MainActivity.this, CheckoutActivity.class);
            startActivityForResult(intent, UPDATE_CART);
        } else {
            UIUtils.showSnackBar(mRootLayout, MainActivity.this, getString(R.string.bm_cart_is_empty));
        }
    }

    @Override
    public void onItemSelected(ProductBean bean, int position, int type) {
        if (type == AppConfig.ITEM_RV) {
            if (position == map.size() - AppConfig.POSITION_FROM_LAST) {
                actionViewMore();
            } else {
                addProductToCart(bean);
            }
        } else if (type == AppConfig.MORE_RV) {
            addProductToCart(bean);
        }
    }

    private void addProductToCart(ProductBean bean) {
        final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        tg.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT);
        tg.release();

        CartHelper.getInstance().addToCart(bean);
        UIUtils.makeToast(MainActivity.this, bean.getProductName() + " added to cart");
        updateCartViews();
    }

    private void actionViewMore() {
        recyclerViewMore.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        ivBack.setVisibility(View.VISIBLE);
        tvText.setText(R.string.tag_veg_oil);
    }

    private void actionViewMoreBack() {
        recyclerViewMore.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
        ivBack.setVisibility(View.INVISIBLE);
        tvText.setText(R.string.home);
    }

    /**
     * method use to update display count of the cart
     */
    private void updateCartViews() {
        long qty = CartHelper.getInstance().getTotalCartQty();
        if (qty > 0) {
            tvAmount.setVisibility(View.VISIBLE);
            tvCartCount.setVisibility(View.VISIBLE);
            tvCartCount.setText(String.format("%s", qty));
        } else {
            tvAmount.setVisibility(View.GONE);
            tvCartCount.setVisibility(View.GONE);
        }
    }

    private void openBarCodeReader() {
        Intent i = new Intent(MainActivity.this, QRCodeReaderActivity.class);
        startActivityForResult(i, PRODUCT_CODE);
    }

    private void checkCameraPermission() {
        final String permission = Manifest.permission.CAMERA;

        PermissionUtil.checkPermission(MainActivity.this, permission,
                new PermissionUtil.PermissionAskListener() {
                    @Override
                    public void onPermissionAsk() {
                        //ask permission for first time
                        requestPermissions(permission);
                    }

                    @Override
                    public void onPermissionPreviouslyDenied() {
                        //denied permission earlier
                        requestPermissions(permission);
                        //show a dialog explaining permission and then request permission
                    }

                    @Override
                    public void onPermissionDisabled() {
                        //clicked on 'Never ask again'
                        UIUtils.showSnackBar(mRootLayout, MainActivity.this, getString(R.string.bm_open_camera_permission_disabled_msg));
                    }

                    @Override
                    public void onPermissionGranted() {
                        // Android version is lesser than 6.0 or the permission is already granted.
                        openBarCodeReader();
                    }
                });
    }

    private void requestPermissions(String permission) {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{permission},
                RQS_OPEN_CAMERA
        );
    }

    /**
     * Callback for run time permission in API 23(Marshmallow) and above.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == RQS_OPEN_CAMERA) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission is granted
                openBarCodeReader();
            } else {
                UIUtils.showSnackBar(mRootLayout, MainActivity.this, getString(R.string.bm_open_camera_permission_disabled_msg));
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case PRODUCT_CODE:
                if (resultCode == RESULT_OK) {
                    if (data != null && data.hasExtra(IntentConstants.PRODUCT_KEY)) {
                        long key = data.getLongExtra(IntentConstants.PRODUCT_KEY, -1);
                        handleProductKey(key);
                    }
                }
                break;
            case UPDATE_CART:
                updateCartViews();
                break;
            case MORE_PRODUCTS:
                updateCartViews();
                break;
        }
    }

    @Override
    public void onDismiss(long key) {
        handleProductKey(key);
    }

    private void handleProductKey(long key) {
        ProductBean bean = map.get(key);
        if (bean == null) {
            bean = mapMore.get(key);
        }

        if (bean != null) {
            onItemSelected(bean, 0, 0);
        } else {
            UIUtils.showSnackBar(mRootLayout, MainActivity.this, getString(R.string.bm_product_not_found));
        }
    }

    @Override
    public void onBackPressed() {

        if (ivBack.getVisibility() == View.VISIBLE) {
            actionViewMoreBack();
        } else {
            super.onBackPressed();
        }

    }

    public void onRefundClick(View view) {
        startActivity(new Intent(this, RefundActivity.class));
    }

    public void onOtherTxnClick(View view) {
        PineServiceHelper.getInstance().launchApp();
    }

    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult(detailResponse);
        if (detailResponse != null && !detailResponse.getResponse().isSuccess()) {
            UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
        }
    }
}
