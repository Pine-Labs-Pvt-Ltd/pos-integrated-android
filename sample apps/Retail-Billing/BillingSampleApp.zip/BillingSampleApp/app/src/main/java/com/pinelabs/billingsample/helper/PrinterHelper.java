package com.pinelabs.billingsample.helper;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.pojo.PaymentMode;
import com.pinelabs.billingsample.beans.pojo.PrintData;
import com.pinelabs.billingsample.beans.pojo.PurchasedProductBean;
import com.pinelabs.billingsample.config.AppConfig;
import com.pinelabs.billingsample.config.MyApplication;
import com.pinelabs.billingsample.utility.AndroidUtils;
import com.pinelabs.billingsample.utility.DateUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Pinelabs Pvt Ltd on 2/8/2019.
 * <p>
 * This class use for Prepare Print data in required format.
 */
public class PrinterHelper {
    private static PrinterHelper INSTANCE;
    private ArrayList<PrintData> printDataList;
    private long dtInMs;

    private PrinterHelper() {
    }

    public static PrinterHelper getInstance() {
        if (INSTANCE == null) {
            synchronized (PrinterHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new PrinterHelper();
                }
            }
        }
        return INSTANCE;
    }

    public List<PrintData> getPrintData(long dtInMs) {
        this.dtInMs = dtInMs;
        printDataList = new ArrayList<>();
        addHeaders();

        for (PurchasedProductBean productBean : CartHelper.getInstance().getCart().values()) {
            PrintData printData = new PrintData(String.format("%s (%s)", productBean.getProductName(), productBean.getFormatedPrice()), " ");
            printDataList.add(printData);

            String priceQty = getString(R.string.tag_qty) + " " + productBean.getQty();
            String total = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(productBean.getTotalPrice()));

            printData = new PrintData(priceQty, total);
            printDataList.add(printData);
        }


        PrintData printDataSeparator = new PrintData(AppConfig.Separator);
        printDataList.add(printDataSeparator);

        PrintData printData5 = new PrintData(getString(R.string.tag_pay_mode));
        printDataList.add(printData5);

        for (PaymentMode paymentMode : CartHelper.getInstance().getPaymentModes()) {
            PrintData printDataPayMode = new PrintData(paymentMode.getPaymentMode(), paymentMode.getDisplayAmt());
            printDataList.add(printDataPayMode);
        }

        printDataList.add(printDataSeparator);

        String total = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(CartHelper.getInstance().getTotalCartAmount()));
        PrintData printDataTotal = new PrintData(getString(R.string.tag_total), total);
        printDataList.add(printDataTotal);

        String discount = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(-1 * CartHelper.getInstance().getTotalDiscount()));
        PrintData printDataDiscount = new PrintData(getString(R.string.tag_discount), discount);
        printDataList.add(printDataDiscount);

        String tax = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(CartHelper.getInstance().getTotalTax()));
        PrintData printDataTax = new PrintData(getString(R.string.tag_tax), tax);
        printDataList.add(printDataTax);

        printDataList.add(printDataSeparator);

        String netPay = AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(CartHelper.getInstance().getNetPayableAmount()));
        PrintData printDataNetPay = new PrintData(getString(R.string.tag_net_pay), netPay);
        printDataList.add(printDataNetPay);

        printDataList.add(printDataSeparator);

        PrintData printDataEmpty = new PrintData("\n");
        printDataList.add(printDataEmpty);
        printDataList.add(printDataEmpty);
        printDataList.add(printDataEmpty);
        printDataList.add(printDataEmpty);

        return printDataList;
    }

    /**
     * Add Basic Header in the receipt
     */
    private void addHeaders() {
        PrintData printData = new PrintData(getString(R.string.tag_invoice));
        printDataList.add(printData);

        PrintData name = new PrintData(getString(R.string.store_test_store), String.format(getString(R.string.user_pinelabs), PreferenceHelper.getInstance().getUserID()));
        printDataList.add(name);

        PrintData printData1 = new PrintData(getString(R.string.tag_inv_no), CartHelper.getInstance().getBillRefNo());
        printDataList.add(printData1);

        PrintData printData2 = new PrintData(getString(R.string.tag_amt), CartHelper.getInstance().getDisplayNetPayableAmount());
        printDataList.add(printData2);

        PrintData printData3 = new PrintData(getString(R.string.tag_dt), DateUtils.getDate(dtInMs));
        printDataList.add(printData3);

        PrintData printData4 = new PrintData(getString(R.string.tag_time), DateUtils.getTime(dtInMs));
        printDataList.add(printData4);

        PrintData printData7 = new PrintData(AppConfig.Separator);
        printDataList.add(printData7);

        PrintData printData6 = new PrintData(getString(R.string.tag_product_name), getString(R.string.tag_price));
        printDataList.add(printData6);

        printDataList.add(printData7);
    }

    private String getString(int resId) {
        return MyApplication.getAppContext().getString(resId);
    }

}
