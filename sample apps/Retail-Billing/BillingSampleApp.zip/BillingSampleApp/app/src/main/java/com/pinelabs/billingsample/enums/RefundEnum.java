package com.pinelabs.billingsample.enums;

import com.pinelabs.billingsample.beans.request.DoTransactionRequest;
import com.pinelabs.billingsample.beans.request.HeaderRequest;

public enum RefundEnum {

    Refund_Transaction("Refund Transaction", new DoTransactionRequest(4002L)),
    VoidTransaction("Void Transaction", new DoTransactionRequest(4006L)),
    Pine360PPC_GVLoad("Prepaid Load", new DoTransactionRequest(4202L)),
    Pine360GCLoad("Gift Card Load", new DoTransactionRequest(4211L)),
    RewardVoid("Reward Void", new DoTransactionRequest(4102L)),
    PaybackVoid("Payback Void", new DoTransactionRequest(4403L)),
    WalletLoad("Wallet Load", new DoTransactionRequest(5103L)),
    WalletVoid("Wallet Void", new DoTransactionRequest(5104L)),
    Void("UPI Void", new DoTransactionRequest(5121L));

    private final String name;
    private HeaderRequest<DoTransactionRequest> request;


    RefundEnum(String s, DoTransactionRequest doTransactionRequest) {
        this.name = s;
        request = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        request.setDetail(doTransactionRequest);
    }

    public HeaderRequest<DoTransactionRequest> getRequest() {
        return request;
    }

    public String getName() {
        return name;
    }
}
