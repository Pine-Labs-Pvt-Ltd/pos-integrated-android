package com.pinelabs.billingsample.enums;

/**
 * Created by Pinelabs Pvt Ltd on 5/9/2018.
 */

public enum ResponseStatus {
    SUCCESS(0), FAILED(1);

    private final int value;

    ResponseStatus(int i) {
        this.value = i;
    }

    public int getValue() {
        return value;
    }
}
