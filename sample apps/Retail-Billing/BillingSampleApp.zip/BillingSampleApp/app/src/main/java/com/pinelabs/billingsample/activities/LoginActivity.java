package com.pinelabs.billingsample.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.config.AppConfig;
import com.pinelabs.billingsample.helper.PreferenceHelper;
import com.pinelabs.billingsample.utility.UIUtils;

/**
 * Created by Pinelabs Pvt Ltd on 9/14/2017.
 *
 * Activity use for login
 */

public class LoginActivity extends BaseActivity {
    private EditText mETUserID;
    private EditText mETPassword;
    private View mRootLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_login);

        initViews();
    }

    private void initViews() {
        mETUserID = findViewById(R.id.et_user_id);
        mETPassword = findViewById(R.id.et_password);
        mRootLayout = findViewById(R.id.root_layout);
    }

    public void onLoginClick(View view) {
        if (isValid()) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
        }
    }

    /**
     * Check all user validations
     * @return true if user is valid
     */
    private boolean isValid() {
        String mUserID = mETUserID.getText().toString().trim();
        String mPassword = mETPassword.getText().toString().trim();

        if (TextUtils.isEmpty(mUserID)) {
            UIUtils.showSnackBar(mRootLayout, this, getString(R.string.bm_user_id_empty));
            return false;
        } else if (!mUserID.matches(AppConfig.UserMno)) {
            UIUtils.showSnackBar(mRootLayout, this, getString(R.string.bm_user_id_error));
            return false;
        } else if (TextUtils.isEmpty(mPassword)) {
            UIUtils.showSnackBar(mRootLayout, this, getString(R.string.bm_password_empty));
            return false;
        } else if (!mPassword.equals(AppConfig.UserPassword)) {
            UIUtils.showSnackBar(mRootLayout, this, getString(R.string.bm_password_error));
            return false;
        } else {
            PreferenceHelper.getInstance().saveUserID(mUserID);
            return true;
        }
    }


}
