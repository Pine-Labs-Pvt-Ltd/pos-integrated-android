package com.pinelabs.billingsample.beans.pojo;

import com.pinelabs.billingsample.utility.AndroidUtils;

/**
 * Created by Pinelabs Pvt Ltd on 1/30/2019.
 */
public class PaymentMode {
    private String paymentMode;
    private long amt;

    public PaymentMode(String paymentMode, long amt) {
        this.paymentMode = paymentMode;
        this.amt = amt;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public long getAmt() {
        return amt;
    }

    public void setAmt(long amt) {
        this.amt = amt;
    }

    public String getDisplayAmt() {
        return AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(amt));
    }
}
