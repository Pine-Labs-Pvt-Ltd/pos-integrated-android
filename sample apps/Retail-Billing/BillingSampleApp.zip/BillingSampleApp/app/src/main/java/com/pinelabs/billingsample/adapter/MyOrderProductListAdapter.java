package com.pinelabs.billingsample.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.pojo.PurchasedProductBean;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.utility.AndroidUtils;

import java.util.ArrayList;

/**
 * Created by Pinelabs Pvt Ltd on 11/27/2017.
 *
 * Adapter uses to show product list
 *
 * if editable trues - then product list editable
 * if false - then product list id read only
 */

public class MyOrderProductListAdapter
        extends RecyclerView.Adapter<MyOrderProductListAdapter.VH> {

    private final Context mContext;
    private final CallBack mCallBack;
    private final boolean mEditable;
    private ArrayList<PurchasedProductBean> mProductBeanArrayList;

    public MyOrderProductListAdapter(Context context, CallBack callBack, ArrayList<PurchasedProductBean> productBeanArrayList, boolean isEditable) {
        this.mContext = context;
        this.mCallBack = callBack;
        this.mProductBeanArrayList = productBeanArrayList;
        this.mEditable = isEditable;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(mContext).inflate(R.layout.bm_item_my_order, parent, false));
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        final PurchasedProductBean bean = mProductBeanArrayList.get(position);
        if (bean != null) {
            holder.tvProductName.setText(bean.getProductName());
            holder.tvQty.setText(String.valueOf(bean.getQty()));
            holder.tvPrice.setText(AndroidUtils.getCurrencyInIndianFormat(mContext, AndroidUtils.paiseToRupeeConversion(bean.getPrice())));
            holder.tvTotal.setText(AndroidUtils.getCurrencyInIndianFormat(mContext, AndroidUtils.paiseToRupeeConversion(bean.getTotalPrice())));
            holder.ivAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CartHelper.getInstance().incrementProductQty(bean.getKey());
                    if (mCallBack != null) {
                        mCallBack.OnRefresh();
                    }
                }
            });
            holder.ivMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CartHelper.getInstance().decrementProductQty(bean.getKey());
                    if (mCallBack != null) {
                        mCallBack.OnRefresh();
                    }
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return mProductBeanArrayList != null ? mProductBeanArrayList.size() : 0;
    }

    public void setList(ArrayList<PurchasedProductBean> list) {
        this.mProductBeanArrayList = list;
        notifyDataSetChanged();
    }

    public interface CallBack {
        void OnRefresh();
    }

    class VH extends RecyclerView.ViewHolder {
        private final TextView tvTotal;
        private final TextView tvProductName;
        private final TextView tvQty;
        private final TextView tvPrice;
        private final View ivAdd;
        private final View ivMinus;

        VH(View itemView) {
            super(itemView);
            tvProductName = itemView.findViewById(R.id.tv_product_name);
            tvQty = itemView.findViewById(R.id.tv_qty);
            tvPrice = itemView.findViewById(R.id.tv_price);
            tvTotal = itemView.findViewById(R.id.tv_total);


            ivAdd = itemView.findViewById(R.id.iv_plus);
            ivMinus = itemView.findViewById(R.id.iv_minus);
            if (mEditable) {
                ivMinus.setVisibility(View.VISIBLE);
                ivAdd.setVisibility(View.VISIBLE);
            } else {
                ivMinus.setVisibility(View.GONE);
                ivAdd.setVisibility(View.GONE);
            }
        }
    }
}
