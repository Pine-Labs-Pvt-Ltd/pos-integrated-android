package com.pinelabs.billingsample.utility;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.config.MyApplication;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Created by Pinelabs Pvt Ltd on 9/1/2017.
 */

public class AndroidUtils {

    public static double paiseToRupeeConversion(long amountInPaise) {
        Double amountInRs;
        try {
            amountInRs = (((double) amountInPaise / 100));
        } catch (Exception e) {
            Log.e("conversion", "" + e.getMessage());
            amountInRs = Double.valueOf("0");
        }
        return Double.parseDouble(fmt(String.valueOf(amountInRs)));
    }

    private static String fmt(String s) {
        double d = 0.0;
        try {
            d = Double.parseDouble(s);
        } catch (NumberFormatException e) {
            Log.e("format", "" + e.getMessage());
        }
        if (d == (long) d)
            return String.format("%d", (long) d);
        else
            return String.format("%s", d);
    }

    public static String getCurrencyInIndianFormat(Double n) {
        return getCurrencyInIndianFormat(MyApplication.getAppContext(), n);
    }

    public static String getCurrencyInIndianFormat(Context context, Double n) {
        boolean negFlag = n < 0;
        n = Math.abs(n);

        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        DecimalFormatSymbols dfs = new DecimalFormatSymbols();
        dfs.setCurrencySymbol(context.getString(R.string.bm_inr));
        ((DecimalFormat) numberFormat).setDecimalFormatSymbols(dfs);
        numberFormat.setMaximumFractionDigits(2);
        numberFormat.setMinimumFractionDigits(2);

        String returnValue = numberFormat.format(n).replaceAll("\\u00A0", " ");
//        if (returnValue.contains(".00")) {
//            returnValue = returnValue.replaceAll("0*$", "").replaceAll("\\.$", "");
//        }
        if (negFlag)
            return "-" + returnValue;
        else
            return returnValue;
    }


    public static int getDialogWidth(Activity activity) {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        return (int) (displaymetrics.widthPixels * 0.9);
    }

    public static String leftPadding(String value, int paddingValue) {
        StringBuilder paddingString = new StringBuilder();
        for (int i = 0; i < paddingValue; i++) {
            paddingString.append(" ");
        }
        return paddingString + value;
    }

    public static Long getAmtInPaisa(String s) {
        long l = -1L;
        try {
            l = Double.valueOf(Math.round(Double.parseDouble(s) * 100)).longValue();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return l;
    }
}
