package com.pinelabs.billingsample.constants;

/*
 * Created by Pinelabs Pvt Ltd on 9/15/2017.
 */

public interface IntentConstants {
    String PRODUCT_KEY = "PRODUCT_KEY";
    String IS_ORDER_EDITABLE = "IS_ORDER_EDITABLE";
}
