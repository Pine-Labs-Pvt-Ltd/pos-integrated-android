package com.pinelabs.billingsample.fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.utility.AndroidUtils;
import com.pinelabs.billingsample.utility.UIUtils;

/**
 * Created by Pinelabs Pvt Ltd on 31-03-2017.
 *
 * Fragment use to search the product
 */

public class SearchDialogFragment extends DialogFragment {

    private DismissListener mDismissListener;
    private ViewGroup mRootLayout;
    private EditText etKey;

    public static SearchDialogFragment newInstance(DismissListener listener) {
        SearchDialogFragment fragment = new SearchDialogFragment();
        fragment.setDismissListener(listener);
        return fragment;
    }

    public void setDismissListener(DismissListener listener) {
        mDismissListener = listener;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && dialog.getWindow() != null) {
            int width = AndroidUtils.getDialogWidth(getActivity());
            dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
            dialog.setTitle(R.string.search_products);
            dialog.setCanceledOnTouchOutside(false);
        } else {
            dismiss();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bm_frag_search_dialog, container);

        initViews(view);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    private void initViews(View view) {

        etKey = view.findViewById(R.id.et_code);
        mRootLayout = view.findViewById(R.id.root_layout);

        Button dismiss = view.findViewById(R.id.btn_done);
        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mDismissListener != null) {
                    long key = getProductKey(etKey.getText().toString());
                    if (key != -1) {
                        mDismissListener.onDismiss(key);
                    } else {
                        UIUtils.showSnackBar(mRootLayout, getActivity(), getString(R.string.bm_invalid_code));
                    }

                    dismiss();
                }
            }
        });

        UIUtils.showKeyboard(etKey,getContext());
    }

    private long getProductKey(String key) {
        try {
            return Long.parseLong(key);
        } catch (Exception e) {
        }
        return -1;
    }

    public interface DismissListener {
        void onDismiss(long key);
    }

}
