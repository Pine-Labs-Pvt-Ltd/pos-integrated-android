package com.pinelabs.billingsample.beans.pojo;

/*
 * Created by Pinelabs Pvt Ltd on 28-11-2017.
 */

public class PurchasedProductBean extends ProductBean {

    private int qty = 1;

    public PurchasedProductBean(long key, long price, float discount, String productName) {
        super(key, price, discount, productName);
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public long getTotalPrice(){
        return qty * getPrice();
    }

    public long getTotalDiscount(){
        return (long) (qty * getDiscount());
    }

    public void incrementQty() {
        ++qty;
    }

    public void decrementQty() {
        --qty;
    }
}
