package com.pinelabs.billingsample.helper;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.pinelabs.billingsample.config.MyApplication;
import com.pinelabs.billingsample.constants.PreferenceConstants;

/*
 * Created by Pinelabs Pvt Ltd on 15-09-2017.
 */

public class PreferenceHelper {
    private static PreferenceHelper sInstance;
    private final SharedPreferences mPreferences;

    private PreferenceHelper() {
        mPreferences = PreferenceManager.getDefaultSharedPreferences(MyApplication.getAppContext());
    }

    public static PreferenceHelper getInstance() {
        if (sInstance == null)
            sInstance = new PreferenceHelper();
        return sInstance;
    }

    /********
     * CART_PREF_KEY
     **********/
    public String getCart() {
        return mPreferences.getString(PreferenceConstants.CART_PREF_KEY, "");
    }

    void saveCart(String cart) {
        mPreferences.edit().putString(PreferenceConstants.CART_PREF_KEY, cart).apply();
    }

    void removeCart() {
        mPreferences.edit().remove(PreferenceConstants.CART_PREF_KEY).apply();
    }


    /********
     * USER ID
     **********/
    public String getUserID() {
        return mPreferences.getString(PreferenceConstants.USER_ID_PREF_KEY, "");
    }

    public void saveUserID(String userID) {
        mPreferences.edit().putString(PreferenceConstants.USER_ID_PREF_KEY, userID).apply();
    }


    public void firstTimeAskingPermission(String permission, boolean isFirstTime) {
        mPreferences.edit().putBoolean(permission, isFirstTime).apply();
    }

    public boolean isFirstTimeAskingPermission(String permission) {
        return mPreferences.getBoolean(permission, true);
    }

    public boolean isLoggedIn() {
        return !TextUtils.isEmpty(getUserID());
    }

    public void logout() {
        mPreferences.edit().clear().commit();
    }

}