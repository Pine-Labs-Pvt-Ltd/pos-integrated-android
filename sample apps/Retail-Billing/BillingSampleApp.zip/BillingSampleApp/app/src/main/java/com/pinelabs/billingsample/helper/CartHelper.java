package com.pinelabs.billingsample.helper;

import android.text.TextUtils;

import com.pinelabs.billingsample.beans.pojo.PaymentMode;
import com.pinelabs.billingsample.beans.pojo.ProductBean;
import com.pinelabs.billingsample.beans.pojo.PurchasedProductBean;
import com.pinelabs.billingsample.utility.AndroidUtils;
import com.pinelabs.billingsample.utility.GsonUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Pinelabs Pvt Ltd on 28-11-2017.
 * <p>
 * Class used to hold the cart data
 */

public class CartHelper {

    private static CartHelper mInstance;
    private Map<Long, PurchasedProductBean> cart;
    private List<PaymentMode> payMode;
    private String billRefNo;
    private long paidAmt;

    private CartHelper() {
        cart = new HashMap<>();
        payMode = new ArrayList<>();
    }

    public static CartHelper getInstance() {
        if (mInstance == null) {
            synchronized (CartHelper.class) {
                if (mInstance == null) {
                    String cartJson = PreferenceHelper.getInstance().getCart();
                    if (!TextUtils.isEmpty(cartJson)) {
                        mInstance = GsonUtils.fromStringToJson(cartJson, CartHelper.class);
                    }

                    if (mInstance == null || mInstance.getPendingAmt() == 0) {
                        mInstance = new CartHelper();
                    }
                }
            }
        }
        return mInstance;
    }

    public void saveCart() {
        String json = GsonUtils.fromJsonToString(mInstance);
        PreferenceHelper.getInstance().saveCart(json);
    }

    public Map<Long, PurchasedProductBean> getCart() {
        return cart;
    }

    public void addToCart(ProductBean bean) {

        PurchasedProductBean purchasedBean = cart.get(bean.getKey());
        if (purchasedBean == null) {
            purchasedBean = new PurchasedProductBean(bean.getKey(), bean.getPrice(), bean.getDiscountPercentage(), bean.getProductName());
            cart.put(bean.getKey(), purchasedBean);
        } else {
            purchasedBean.incrementQty();
        }
    }

    private void removeFromCart(long id) {
        cart.remove(id);
    }

    public void incrementProductQty(long id) {
        PurchasedProductBean purchasedBean = cart.get(id);
        if (purchasedBean != null) {
            purchasedBean.incrementQty();
        }
    }

    public void decrementProductQty(long id) {
        PurchasedProductBean purchasedBean = cart.get(id);
        if (purchasedBean != null) {
            purchasedBean.decrementQty();

            if (purchasedBean.getQty() < 1) {
                removeFromCart(id);
            }
        }
        /*for (Map.Entry<Long, PurchasedProductBean> entry : cart.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            // ...
        }*/

    }

    public long getTotalCartAmount() {
        long amount = 0;
        for (PurchasedProductBean bean : cart.values()) {
            amount += bean.getTotalPrice();
        }

        return amount;
    }

    public long getTotalCartQty() {
        long qty = 0;
        for (PurchasedProductBean bean : cart.values()) {
            qty += bean.getQty();
        }

        return qty;
    }

    public long getTotalDiscount() {
        long discount = 0;
        for (PurchasedProductBean bean : cart.values()) {
            discount += bean.getTotalDiscount();
        }

        return discount;
    }

    public long getTotalTax() {

        return Math.round(0.12 * getAmountAfterDiscount());
    }

    public long getAmountAfterDiscount() {
        return getTotalCartAmount() - getTotalDiscount();
    }

    public long getNetPayableAmount() {
        return getAmountAfterDiscount() + getTotalTax();
    }

    public void clearCart() {
        PreferenceHelper.getInstance().removeCart();
        mInstance = null;
    }

    public List<PaymentMode> getPaymentModes() {
        if (payMode == null) {
            payMode = new ArrayList<>();
        }
        return payMode;
    }

    public String getBillRefNo() {
        if (TextUtils.isEmpty(billRefNo)) {
            billRefNo = String.valueOf(System.currentTimeMillis());
        }
        return billRefNo;
    }

    public String getDisplayNetPayableAmount() {
        return AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(getNetPayableAmount()));
    }

    public boolean isPendingInvoice() {
        return payMode != null && !payMode.isEmpty() && getPendingAmt() != 0;
    }

    public void addPayment(String s, long l) {
        if (payMode == null) {
            payMode = new ArrayList<>();
        }

        paidAmt += l;
        payMode.add(new PaymentMode(s, l));
    }

    public boolean isBillComplete() {
        return getNetPayableAmount() != 0 && paidAmt == getNetPayableAmount();
    }

    public String getPendingDisplayAmt() {
        return AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(getNetPayableAmount() - paidAmt));
    }

    public String getPaidDisplayAmt() {
        return AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(paidAmt));
    }

    public long getPendingAmt() {
        return getNetPayableAmount() - paidAmt;
    }
}
