package com.pinelabs.billingsample.activities;

/**
 * Created by Pinelabs Pvt Ltd on 11/28/2017.
 * <p>
 * This activity used to show Invoice
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.TextView;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.beans.pojo.PrintData;
import com.pinelabs.billingsample.beans.response.DetailResponse;
import com.pinelabs.billingsample.fragments.MyOrderFragment;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.helper.PineServiceHelper;
import com.pinelabs.billingsample.helper.PrinterHelper;
import com.pinelabs.billingsample.utility.DateUtils;
import com.pinelabs.billingsample.utility.UIUtils;

import java.util.List;

public class InvoiceActivity extends BasePineActivity {
    private long dtInMs;
    private View btnPrint;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_invoice);
        initViews();
        hideActionBar();
        setOrderFragment();
    }

    /**
     * Using Fragment In ReadOnly Mode to show product list.
     */
    private void setOrderFragment() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.container, MyOrderFragment.getInstance(false, null));
        transaction.commit();
    }

    private void initViews() {
        TextView tvTxNo = findViewById(R.id.tv_tx_no);
        TextView tvTxDT = findViewById(R.id.tv_tx_dt);
        TextView tvTxTime = findViewById(R.id.tv_tx_time);
        TextView tvTxAmt = findViewById(R.id.tv_tx_amt);
        btnPrint = findViewById(R.id.btn_print);

        dtInMs = System.currentTimeMillis();
        tvTxDT.setText(DateUtils.getDate(dtInMs));
        tvTxTime.setText(DateUtils.getTime(dtInMs));
        tvTxNo.setText(CartHelper.getInstance().getBillRefNo());
        tvTxAmt.setText(CartHelper.getInstance().getDisplayNetPayableAmount());
    }

    /**
     * Printing invoice
     */
    public void onPrintClick(View view) {
        List<PrintData> printData = PrinterHelper.getInstance().getPrintData(dtInMs);
        PineServiceHelper.getInstance().connect(this);
        PineServiceHelper.getInstance().printData(printData);
    }


    @Override
    public void sendResult(DetailResponse detailResponse) {
        super.sendResult(detailResponse);
        if (detailResponse != null) {
            if (detailResponse.getResponse().isSuccess()) {
                btnPrint.setEnabled(false);
                btnPrint.setAlpha(.3f);
            } else {
                UIUtils.makeToast(this, detailResponse.getResponse().getResponseMsg());
            }
        }
    }

    /**
     * Method use to end transaction and clear all locally stored cart data.
     */
    private void endTxn() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        CartHelper.getInstance().clearCart();
    }

    /**
     * Skip Printing and Open MainActivity
     */
    public void onDoneClick(View view) {
        endTxn();
    }

    /**
     * Removing super call to disable back button
     */
    @Override
    public void onBackPressed() {

    }

    /**
     * If user destroy the activity without printing invoice or clicking done button
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        CartHelper.getInstance().clearCart();
    }

}
