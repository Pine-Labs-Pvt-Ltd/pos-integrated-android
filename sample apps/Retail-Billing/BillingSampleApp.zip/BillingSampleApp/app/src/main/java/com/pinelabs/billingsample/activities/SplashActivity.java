package com.pinelabs.billingsample.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.helper.PreferenceHelper;


/**
 * Created by Pinelabs Pvt Ltd on 9/14/2017.
 */
public class SplashActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_splash);
    }

    @Override
    protected void onResume() {
        super.onResume();
        proceedFurther();
    }

    /**
     * check auto login
     */
    private void proceedFurther() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (PreferenceHelper.getInstance().isLoggedIn()) {
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                } else {
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                }
                finish();
            }
        }, 3000);
    }
}
