package com.pinelabs.billingsample.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.google.zxing.Result;
import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.constants.IntentConstants;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

/**
 * Activity use to read Barcode
 */
public class QRCodeReaderActivity extends BaseActivity implements ZXingScannerView.ResultHandler {

    private ZXingScannerView mScannerView;
    private AlertDialog mDialog;
    private String productKey;
    private long result;
    private DialogInterface.OnDismissListener mDismissListener = new DialogInterface.OnDismissListener() {
        @Override
        public void onDismiss(DialogInterface dialogInterface) {
            if (mScannerView != null) {
                startCamera();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_qrcode_reader);
        setBackButton();

        mScannerView = findViewById(R.id.scanner_view);
    }

    private void startCamera() {
        if (mScannerView != null) {
            mScannerView.setResultHandler(this);
            mScannerView.startCamera();         // Start camera
        }
    }

    private void stopCamera() {
        if (mScannerView != null)
            mScannerView.stopCamera();
    }

    @Override
    public void onPause() {
        super.onPause();
        stopCamera();
        if (mDialog != null) {
            mDialog.setOnDismissListener(null);
        }
        closeDialog();
    }

    @Override
    public void onResume() {
        super.onResume();
        startCamera();
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here

        Log.e("handler", rawResult.getText()); // Prints scan results
        Log.e("handler", rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode)

        // show the scanner result into dialog box.
        productKey = rawResult.getText();
        handleResultString();

        // If you would like to resume scanning, call this method below:
        // mScannerView.resumeCameraPreview(this);
    }

    private void handleResultString() {
        if (isValidProductKey()) {
            openMainActivity();
        } else {
            showDialog(getString(R.string.bm_invalid_code), true);
        }
    }

    private boolean isValidProductKey() {
        try {
            result = Long.parseLong(productKey);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }

    private void openMainActivity() {
        Intent intent = new Intent();
        intent.putExtra(IntentConstants.PRODUCT_KEY, result);
        setResult(RESULT_OK, intent);
        finish();
    }

    private void showDialog(String s, boolean isPositive) {
        stopCamera();
        LayoutInflater factory = LayoutInflater.from(QRCodeReaderActivity.this);
        final View dialogView = factory.inflate(R.layout.bm_default_alert_dialog, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);

        mDialog = builder.create();
        mDialog.setView(dialogView);
        Window window = mDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView tvTitle =  dialogView.findViewById(R.id.tv_title);
        TextView tvDesc =  dialogView.findViewById(R.id.tv_desc);
        TextView buttonCancel =  dialogView.findViewById(R.id.button_cancel);
        TextView buttonOkay = dialogView.findViewById(R.id.button_okay);

        tvTitle.setText(R.string.tag_scan_result);
        tvDesc.setText(s);


        if (isPositive) {
            buttonCancel.setVisibility(View.GONE);
        } else {
            buttonCancel.setVisibility(View.VISIBLE);
            buttonCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    closeDialog();
                }
            });
        }

        buttonOkay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeDialog();
            }
        });

        mDialog.setOnDismissListener(mDismissListener);
        showDialog();
    }

    private void showDialog() {
        try {
            if (mDialog != null)
                mDialog.show();
        } catch (Exception e) {
        }
    }

    /**
     * close error dialog
     */
    private void closeDialog() {
        if (mDialog != null && mDialog.isShowing()) {
            mDialog.dismiss();
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(QRCodeReaderActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        super.onBackPressed();
    }

}
