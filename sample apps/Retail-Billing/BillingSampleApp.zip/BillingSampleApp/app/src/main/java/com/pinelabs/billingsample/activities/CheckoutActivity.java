package com.pinelabs.billingsample.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.pinelabs.billingsample.R;
import com.pinelabs.billingsample.fragments.MyOrderFragment;
import com.pinelabs.billingsample.helper.CartHelper;
import com.pinelabs.billingsample.utility.AndroidUtils;


/**
 * Created by Pinelabs Pvt Ltd on 11/27/2017.
 * <p>
 * This Activity use to display the Cart products
 */
public class CheckoutActivity extends BaseActivity implements MyOrderFragment.AmountCallBack {

    private Button btnPay;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bm_activity_check_out);
        initViews();
        setBackButton();
        setOrderFragment();
    }

    private void initViews() {
        btnPay = findViewById(R.id.btn_pay);
    }

    /**
     * This Fragment is showing the list of product(fetching product list from CartHelper)
     */
    private void setOrderFragment() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.container, MyOrderFragment.getInstance(true, this));
        transaction.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bm_menu_checkout, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void onPayClick(View view) {
        startActivity(new Intent(this, PaymentModeActivity.class));
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_clear) {
            AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
            builder.setMessage(R.string.clear_cart_msg);
            builder.setNegativeButton(R.string.no, null);
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    CartHelper.getInstance().clearCart();
                    onBackPressed();
                }
            });
            builder.show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onAmountChanged() {
        long amt = CartHelper.getInstance().getNetPayableAmount();
        if (amt <= 0) {
            btnPay.setVisibility(View.GONE);
        } else {
            btnPay.setVisibility(View.VISIBLE);
            btnPay.setText(getString(R.string.tag_pay_rs, AndroidUtils.getCurrencyInIndianFormat(AndroidUtils.paiseToRupeeConversion(amt))));
        }
    }
}
