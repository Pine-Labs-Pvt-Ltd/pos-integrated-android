package com.pinelabs.billingsample.enums;

/*
 * Created by Pinelabs Pvt Ltd on 5/9/2018.
 */

public enum BillingMethodId {
    DO_TRANSACTION("1001"),
    PRINT("1002"),
    SETTLEMENT("1003"),
    GET_TERMINAL_INFO("1004"),
    LAUNCH_APP("1005");


    private String value;

    BillingMethodId(String s) {
        value = s;
    }

    public String getValue() {
        return value;
    }
}
